import { access, readFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const checks = [];
async function check(name, fn) {
  try {
    const detail = await fn();
    checks.push({ name, ok: true, detail: detail ?? 'OK' });
  } catch (error) {
    checks.push({ name, ok: false, detail: error instanceof Error ? error.message : String(error) });
  }
}

await check('PDF الملزمة موجود في مجلد ملفات الواجهة العامة', async () => {
  const pdf = path.join(root, 'artifacts/barakat-chemistry/public/handouts/barakat-chemistry-2027.pdf');
  await access(pdf);
  const info = await stat(pdf);
  const handle = await import('node:fs/promises').then((m) => m.open(pdf, 'r'));
  const signature = Buffer.alloc(5);
  try { await handle.read(signature, 0, signature.length, 0); } finally { await handle.close(); }
  if (signature.toString('ascii') !== '%PDF-') throw new Error('توقيع PDF غير صالح');
  if (info.size < 1_000_000) throw new Error(`حجم PDF غير متوقع: ${info.size}`);
  const bytes = await readFile(pdf);
  return `${info.size} bytes; SHA-256 ${createHash('sha256').update(bytes).digest('hex')}`;
});

await check('روابط فتح وتنزيل الملزمة موجودة في مصدر الصفحة الرئيسية', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  for (const text of ['ملزمة أستاذ بركات للكيمياء — السادس الإعدادي', 'link-open-handout', 'link-download-handout', '175 صفحة', 'handouts/barakat-chemistry-2027.pdf']) {
    if (!app.includes(text)) throw new Error(`النص أو الرابط غير موجود: ${text}`);
  }
  return 'العنوان والوصف وعدد الصفحات ورابطا الفتح والتنزيل موجودة';
});

await check('مخطط قاعدة البيانات وترحيلاتها موجودة', async () => {
  const migrations = path.join(root, 'lib/db/migrations');
  await access(path.join(migrations, '0000_sloppy_hawkeye.sql'));
  await access(path.join(migrations, '0001_nifty_vampiro.sql'));
  await access(path.join(migrations, '0002_notification_outbox.sql'));
  return 'ثلاثة ترحيلات SQL موجودة، بما فيها ترحيل Outbox';
});

await check('المشروع يحتوي إعداد المصادقة وحماية الأدوار في الخادم', async () => {
  const auth = await readFile(path.join(root, 'artifacts/api-server/src/middlewares/auth.ts'), 'utf8');
  const setup = await readFile(path.join(root, 'artifacts/api-server/src/routes/auth.ts'), 'utf8');
  if (!auth.includes('requireTeacher') || !auth.includes('requireAcceptedStudent') || !setup.includes('TEACHER_SETUP_TOKEN')) {
    throw new Error('لم يتم العثور على جميع مؤشرات المصادقة/الأدوار المتوقعة');
  }
  return 'middleware للأدوار وإعداد أول أستاذ محمي موجودان';
});

await check('تبويبات الطالب والأستاذ تشير إلى صفحات فعلية', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  const paths = [
    '/student/assignments', '/student/submissions', '/student/notifications', '/student/profile',
    '/teacher/dashboard', '/teacher/assignments/new', '/teacher/assignments',
    '/teacher/students', '/teacher/submissions', '/teacher/notifications', '/teacher/settings',
  ];
  for (const route of paths) {
    if (!app.includes(`href: '${route}'`) || !app.includes(`path="${route}"`)) {
      throw new Error(`مسار تنقل غير مربوط برابط وصفحة: ${route}`);
    }
  }
  if (!app.includes('mobile-tabbar-${role}') || !app.includes("aria-current={active ? 'page' : undefined}")) {
    throw new Error('تنقل الهاتف أو حالة التبويب النشط غير موجودة');
  }
  return 'روابط التنقل وصفحاتها موجودة لكل من الطالب والأستاذ';
});

await check('مؤقت الطالب يزامن مع وقت الخادم ولا يعتمد ساعة الجهاز', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  const route = await readFile(path.join(root, 'artifacts/api-server/src/routes/student.ts'), 'utf8');
  const detailRoute = route.slice(route.indexOf('"/student/assignments/:assignmentId"'));
  const spec = await readFile(path.join(root, 'lib/api-spec/openapi.yaml'), 'utf8');
  if (!app.includes('assignment?.serverNow') || !app.includes('performance.now()') ||
      !detailRoute.includes('serverNow: new Date().toISOString()') ||
      !spec.includes('required: [attachments, submission, serverNow]')) {
    throw new Error('لم يكتمل تمرير توقيت الخادم من API إلى المؤقت');
  }
  return 'وقت الخادم محفوظ في استجابة الواجب ويُستكمل بساعة monotonic في المتصفح';
});

await check('الملفات الخاصة لا تُخزّن في ذاكرة المتصفح', async () => {
  const storage = await readFile(path.join(root, 'artifacts/api-server/src/lib/objectStorage.ts'), 'utf8');
  if (!storage.includes("'private, no-store'")) {
    throw new Error('استجابة تنزيل الملف الخاص لا تضبط Cache-Control إلى no-store');
  }
  return 'التخزين المؤقت للملفات الخاصة معطل؛ سياسة الملفات العامة منفصلة';
});

await check('الحساب الموقوف لا يستطيع إعادة طلب الانضمام', async () => {
  const student = await readFile(path.join(root, 'artifacts/api-server/src/routes/student.ts'), 'utf8');
  const enrollment = student.slice(student.indexOf('"/student/enrollment"'), student.indexOf('"/student/assignments"'));
  if (!enrollment.includes('existing?.status === "SUSPENDED"') || !enrollment.includes('result.blocked')) {
    throw new Error('لا يوجد رفض صريح لإعادة الطلب من حالة SUSPENDED');
  }
  return 'الحالة الموقوفة تُرفض قبل استهلاك رمز الدعوة';
});

await check('صور وملفات الطالب تظهر في حالة التسليم المكتمل', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  if (!app.includes('assignment.submission.attachments.map') || !app.includes('link-my-submission-attachment-')) {
    throw new Error('لا تعرض صفحة تفاصيل الواجب مرفقات التسليم');
  }
  return 'تُعرض المرفقات عبر روابط الملفات الخاصة التي يعيدها API';
});

await check('مراقبة الأستاذ تعيد جلب حالة التسليم دورياً', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  const monitor = app.slice(app.indexOf('function MonitorPage()'), app.indexOf('function ReviewPage()'));
  if (!monitor.includes('refetchInterval: 12000') || !monitor.includes('refetchIntervalInBackground: false')) {
    throw new Error('لا يوجد polling محدود للمراقبة أو لم يُعطل في الخلفية');
  }
  return 'شاشة المراقبة تحدّث بياناتها كل 12 ثانية أثناء وجودها في الواجهة';
});

await check('تعطل التخزين لا يحذف سجل طلب رفع منتهي', async () => {
  const notifications = await readFile(path.join(root, 'artifacts/api-server/src/lib/notifications.ts'), 'utf8');
  if (!notifications.includes('error instanceof ObjectNotFoundError') ||
      !notifications.includes('keeping its intent for retry') ||
      !notifications.includes('continue;')) {
    throw new Error('سجل طلب الرفع قد يُحذف رغم فشل التخزين المؤقت');
  }
  return 'يُحتفظ بسجل الطلب لإعادة المحاولة عند خطأ التخزين؛ المفقود المؤكد يُنظّف';
});

await check('preinstall لا يحذف ملفات القفل عند رفض مدير الحزم', async () => {
  const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
  const guard = await readFile(path.join(root, 'scripts/preinstall-check.mjs'), 'utf8');
  if (pkg.scripts.preinstall !== 'node scripts/preinstall-check.mjs') throw new Error('preinstall لا يستخدم فاحص مدير الحزم الآمن');
  if (/rm\s+-f|unlink|delete.*lock/i.test(guard)) throw new Error('فاحص التثبيت يحتوي على سلوك حذف ملفات');
  if (!guard.includes('npm_config_user_agent') || !guard.includes('pnpm/')) throw new Error('فاحص مدير الحزم لا يتحقق من pnpm');
  return 'يُرفض مدير الحزم غير المدعوم دون حذف package-lock.json أو yarn.lock';
});

await check('ملفات الأسرار مستثناة من Git مع السماح بملف المثال', async () => {
  const ignore = await readFile(path.join(root, '.gitignore'), 'utf8');
  for (const line of ['.env', '.env.*', '!.env.example', '!.env.*.example']) {
    if (!ignore.split(/\r?\n/).includes(line)) throw new Error(`قاعدة .gitignore مفقودة: ${line}`);
  }
  return 'ملفات البيئة والأسرار مستثناة وملفات الأمثلة مسموحة';
});

await check('مخطط Outbox وترحيله موجودان ومتوافقان مع الحالة', async () => {
  const schema = await readFile(path.join(root, 'lib/db/src/schema/notification-outbox.ts'), 'utf8');
  const migration = await readFile(path.join(root, 'lib/db/migrations/0002_notification_outbox.sql'), 'utf8');
  const journal = JSON.parse(await readFile(path.join(root, 'lib/db/migrations/meta/_journal.json'), 'utf8'));
  if (!schema.includes('uniqueIndex("notification_outbox_event_key_unique")') || !schema.includes('lockedAt') || !schema.includes('lockToken')) throw new Error('مخطط Outbox يفتقد منع التكرار أو قفل المعالجة');
  if (!migration.includes('notification_outbox_event_key_unique') || !migration.includes('notification_outbox_status_due_idx')) throw new Error('ترحيل Outbox لا ينشئ القيود والفهارس المطلوبة');
  if (!journal.entries.some(e => e.tag === '0002_notification_outbox')) throw new Error('ترحيل Outbox غير مسجل في journal');
  return 'مخطط وترحيل وفهرسة ومنع تكرار مسجلة';
});

await check('إشعار وصول الحل يُحفظ ضمن معاملة التسليم', async () => {
  const student = await readFile(path.join(root, 'artifacts/api-server/src/routes/student.ts'), 'utf8');
  const start = student.indexOf('const submission = await db.transaction');
  const end = student.indexOf('res.status(201).json', start);
  const transaction = student.slice(start, end);
  if (!transaction.includes('tx.insert(notificationOutboxTable)') || !transaction.includes('SUBMISSION_RECEIVED') || !transaction.includes('assignment.createdBy')) throw new Error('إشعار الأستاذ لا يُدرج ضمن معاملة التسليم');
  return 'إشعار الأستاذ مرتبط بمعاملة حفظ التسليم نفسها ومفتاحه فريد';
});

await check('عامل Outbox يعالج التكرار وإعادة المحاولة بأمان', async () => {
  const worker = await readFile(path.join(root, 'artifacts/api-server/src/lib/notifications.ts'), 'utf8');
  for (const token of ['processNotificationOutbox', 'skipLocked: true', 'DEAD_LETTER', 'notificationOutboxTable.lockToken', 'onConflictDoNothing']) {
    if (!worker.includes(token)) throw new Error(`عامل Outbox يفتقد: ${token}`);
  }
  return 'قفل الصفوف، رمز قفل، إعادة محاولة، وسجل إشعار idempotent موجودة';
});

await check('عقد API يدعم إشعار التسليم الجديد', async () => {
  const files = [
    'lib/db/src/schema/enums.ts',
    'lib/api-spec/openapi.yaml',
    'lib/api-zod/src/generated/types/notificationType.ts',
    'lib/api-zod/src/generated/api.ts',
    'lib/api-client-react/src/generated/api.schemas.ts',
  ];
  for (const rel of files) if (!(await readFile(path.join(root, rel), 'utf8')).includes('SUBMISSION_RECEIVED')) throw new Error(`القيمة الجديدة مفقودة من ${rel}`);
  return 'نوع الإشعار مضاف إلى مخطط قاعدة البيانات وعقود API المولدة';
});

await check('أزرار ترتيب وحذف مرفقات الواجب لا ترسل النموذج', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  const start = app.indexOf('function UploadQueue');
  const end = app.indexOf('function ', start + 20);
  const queue = app.slice(start, end > start ? end : start + 10000);
  if (!queue.includes('type="button"')) throw new Error('أزرار المرفقات تفتقد type="button"');
  if (!queue.includes('button-move-up-') || !queue.includes('button-move-down-') || !queue.includes('button-remove-file-')) throw new Error('أحد أزرار ترتيب/حذف المرفقات مفقود');
  const formStart = app.indexOf('className="glass-panel assignment-form"');
  const formEnd = app.indexOf('</form>', formStart);
  const form = app.slice(formStart, formEnd);
  if (/button[^>]*className="icon-button remove-file"(?![^>]*type="button")/.test(form)) throw new Error('زر الحذف قد يرسل النموذج');
  return 'أزرار الترتيب والحذف محددة كأزرار غير مرسلة للنموذج';
});

await check('إشعار التسليم ينقل الأستاذ إلى شاشة المتابعة الصحيحة', async () => {
  const app = await readFile(path.join(root, 'artifacts/barakat-chemistry/src/App.tsx'), 'utf8');
  if (!app.includes("n.type === 'SUBMISSION_RECEIVED'") || !app.includes('/teacher/assignments/${n.assignmentId}/monitor')) throw new Error('الإشعار لا يربط الأستاذ بصفحة متابعة الواجب');
  return 'زر عرض التسليمات ظاهر للإستاذ لإشعار التسليم الجديد';
});


await check('ملف القفل متزامن مع اعتماديات Clerk وExpress الحديثة', async () => {
  const lock = await readFile(path.join(root, 'pnpm-lock.yaml'), 'utf8');
  const frontend = JSON.parse(await readFile(path.join(root, 'artifacts/barakat-chemistry/package.json'), 'utf8'));
  const backend = JSON.parse(await readFile(path.join(root, 'artifacts/api-server/package.json'), 'utf8'));
  if (frontend.devDependencies?.['@clerk/localizations'] !== '^4.23.0') throw new Error('اعتماد Clerk localization غير معلن كما هو متوقع');
  if (!lock.includes("'@clerk/localizations':\n        specifier: ^4.23.0\n        version: 4.23.0")) throw new Error('Importer الخاص بـ @clerk/localizations مفقود من ملف القفل');
  if (backend.dependencies?.express !== '^5.3.0') throw new Error('إصدار Express لا يطابق الإصدار المعتمد');
  if (!lock.includes('express@5.3.0:') || !lock.includes('proxy-addr@2.0.8:') || !lock.includes('content-disposition@2.0.1:')) throw new Error('بيانات حل Express أو الاعتماديات المحدثة ناقصة من القفل');
  return 'تعريفات الاعتماديات وimporters وعقد Express 5.3.0 متزامنة نصياً؛ لم يُشغّل frozen install محلياً';
});

let failed = 0;
for (const result of checks) {
  console.log(`${result.ok ? 'OK' : 'FAIL'}  ${result.name}`);
  console.log(`     ${result.detail}`);
  if (!result.ok) failed++;
}
console.log(`\n${checks.length - failed}/${checks.length} static checks passed.`);
if (failed) process.exitCode = 1;
