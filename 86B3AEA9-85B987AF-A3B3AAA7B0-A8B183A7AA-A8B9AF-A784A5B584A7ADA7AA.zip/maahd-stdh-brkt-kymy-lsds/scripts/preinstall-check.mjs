const agent = process.env.npm_config_user_agent ?? "";

if (!agent.startsWith("pnpm/")) {
  console.error("This workspace must be installed with pnpm. No lock files were changed.");
  process.exit(1);
}

console.log(`Using supported package manager: ${agent.split(" ")[0]}`);
