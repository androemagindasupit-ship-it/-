import { spawn } from 'node:child_process';

const pnpm = process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm';
const tasks = [
  {
    name: 'api',
    args: ['--filter', '@workspace/api-server', 'run', 'dev'],
    env: { PORT: '5000', NODE_ENV: 'development' },
  },
  {
    name: 'web',
    args: ['--filter', '@workspace/barakat-chemistry', 'run', 'dev'],
    env: { PORT: '5173', BASE_PATH: '/', API_PROXY_TARGET: 'http://127.0.0.1:5000', NODE_ENV: 'development' },
  },
];

const children = [];
let shuttingDown = false;

for (const task of tasks) {
  const child = spawn(pnpm, task.args, {
    cwd: process.cwd(),
    env: { ...process.env, ...task.env },
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  child.on('error', (error) => {
    console.error(`[${task.name}] Could not start process: ${error.message}`);
    shutdown(1);
  });
  child.on('exit', (code, signal) => {
    if (!shuttingDown) {
      console.error(`[${task.name}] exited (${signal ?? code ?? 'unknown'})`);
      shutdown(typeof code === 'number' && code !== 0 ? code : 1);
    }
  });
  children.push(child);
}

function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const child of children) {
    if (!child.killed) child.kill('SIGTERM');
  }
  process.exitCode = code;
}

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
