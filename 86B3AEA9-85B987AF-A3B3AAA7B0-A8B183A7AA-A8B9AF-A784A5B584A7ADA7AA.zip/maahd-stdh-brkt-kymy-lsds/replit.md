# معهد أستاذ بركات — كيمياء السادس الإعدادي

منصة عربية RTL لمتابعة واجبات الكيمياء وتسليم صور الحل ومراجعتها للأستاذ، مع ملزمة PDF أصلية مضمّنة في الصفحة العامة.

## Run & Operate

- `pnpm install --frozen-lockfile` — تثبيت الاعتماديات.
- `pnpm run dev` — تشغيل Vite على 5173 وAPI على 5000 مع proxy `/api`.
- `pnpm run check:static` — فحص وجود الملزمة وروابطها وبعض ملفات الأمان الأساسية.
- `pnpm run typecheck` — فحص الأنواع بعد تثبيت الاعتماديات.
- `pnpm run build` — بناء الواجهة وAPI.
- `pnpm run start` — تشغيل API الذي يقدّم أيضاً ناتج الواجهة المبني في الإنتاج.
- `pnpm --filter @workspace/db run migrate` — تطبيق ترحيلات PostgreSQL بعد ضبط `DATABASE_URL`.

## Stack

- PNPM workspace, Node.js 24, TypeScript.
- Frontend: React 19 + Vite + Tailwind CSS.
- API: Express 5 + Clerk Express middleware.
- DB: PostgreSQL + Drizzle ORM.
- Private file storage: Replit Object Storage / Google Cloud Storage adapter.
- API contracts and client: OpenAPI, Zod, generated React Query hooks.

## Source of truth

- `artifacts/barakat-chemistry/src/App.tsx`: صفحات الواجهة ومساراتها.
- `artifacts/barakat-chemistry/src/index.css`: الهوية المرئية.
- `artifacts/api-server/src/routes/`: APIs.
- `lib/db/src/schema/`: مخطط قاعدة البيانات.
- `lib/db/migrations/`: تغييرات قاعدة البيانات المتتبعة.
- `lib/api-spec/openapi.yaml`: عقد API المصدر.
- `artifacts/barakat-chemistry/public/handouts/barakat-chemistry-2027.pdf`: الملزمة المنشورة للعامة.

## Important configuration

Required: `DATABASE_URL`, Clerk keys, `PORT`. Before enabling assignment uploads, configure `PRIVATE_OBJECT_DIR` and `PUBLIC_OBJECT_SEARCH_PATHS`. To initialize the first teacher, configure `TEACHER_SETUP_TOKEN`. Google/Facebook sign-in and email verification/password reset must be enabled in Clerk Dashboard. `AI_API_KEY` is optional and currently used to test provider connectivity, not to serve a full AI tutor.

## Verification caveat

The source has not been fully built or integration-tested in the current editing environment because dependency installation could not reach npm. Do not treat the source audit as proof that the production deployment, external OAuth, uploads, or database flows work. See `PROJECT_AUDIT.md`.
