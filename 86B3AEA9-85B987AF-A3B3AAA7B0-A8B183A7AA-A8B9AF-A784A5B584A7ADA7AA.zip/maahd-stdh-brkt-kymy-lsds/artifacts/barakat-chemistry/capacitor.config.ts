import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "iq.barakatchemistry.institute",
  appName: "معهد أستاذ بركات",
  webDir: "dist/public",
  server: { androidScheme: "https", cleartext: false },
};
export default config;
