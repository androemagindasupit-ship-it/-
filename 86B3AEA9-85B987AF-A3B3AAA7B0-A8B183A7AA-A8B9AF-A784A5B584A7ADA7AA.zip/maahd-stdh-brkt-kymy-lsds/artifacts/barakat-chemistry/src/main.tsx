import { createRoot } from 'react-dom/client';
import { setBaseUrl } from '@workspace/api-client-react';

// BARAKAT_API_ORIGIN_CONFIGURATION: web stays same-origin; Android can use a remote API.
const configuredApiOrigin = import.meta.env.VITE_API_BASE_URL?.trim();
if (configuredApiOrigin) {
  const parsedApiOrigin = new URL(configuredApiOrigin);
  const localhost = parsedApiOrigin.hostname === 'localhost' || parsedApiOrigin.hostname === '127.0.0.1';
  if (parsedApiOrigin.protocol !== 'https:' && !localhost) {
    throw new Error('VITE_API_BASE_URL must use HTTPS outside localhost development.');
  }
  if (parsedApiOrigin.pathname !== '/' || parsedApiOrigin.search || parsedApiOrigin.hash || parsedApiOrigin.username || parsedApiOrigin.password) {
    throw new Error('VITE_API_BASE_URL must be an origin only, without a path or credentials.');
  }
  setBaseUrl(parsedApiOrigin.origin);
}


import App from './App';
import { ErrorBoundary } from '@/components/error-boundary';

import './index.css';

createRoot(document.getElementById('root')!, {
  // Keeps caught errors off reportError(), which would raise the dev overlay.
  onCaughtError: (error, errorInfo) => {
    console.error(error, errorInfo.componentStack);
  },
}).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
