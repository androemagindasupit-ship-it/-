import { type ReactNode, type InputHTMLAttributes, type TextareaHTMLAttributes, useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import { Camera as NativeCamera, CameraResultType, CameraSource } from '@capacitor/camera';
import { LocalNotifications } from '@capacitor/local-notifications';
// BARAKAT_CAPACITOR_INTEGRATION
// BARAKAT_NATIVE_PHOTO_NOTIFICATIONS_V1
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { arSA } from '@clerk/localizations';
import { shadcn } from '@clerk/themes';
import {
  Activity, ArrowDownToLine, ArrowLeft, ArrowRight, Atom, Bell, BookOpen, Check, CheckCircle2,
  ChevronDown, ChevronLeft, Clock3, FileImage, FileText, FlaskConical, Home as HomeIcon, ImagePlus, LoaderCircle,
  LogOut, Menu, Plus, RefreshCw, Send, Settings, ShieldCheck, Upload, Users, X, CircleAlert, Eye,
  ClipboardList, Sparkles, ExternalLink, Trash2, Camera, Copy, CalendarClock, CheckCheck, UserRound,
} from 'lucide-react';
import {
  Route, Switch, Redirect, Link, useLocation, useParams, Router as WouterRouter,
} from 'wouter';
import {
  getGetCurrentUserQueryKey, getGetStudentEnrollmentQueryKey, getGetTeacherDashboardQueryKey,
  getListTeacherStudentsQueryKey, getListTeacherAssignmentsQueryKey, getGetAssignmentMonitorQueryKey,
  getListStudentAssignmentsQueryKey, getGetStudentAssignmentQueryKey, getGetTeacherSubmissionQueryKey,
  getListNotificationsQueryKey, getGetAiSettingsQueryKey,
  useGetCurrentUser, useSetupFirstTeacher, useGetStudentEnrollment, useRequestStudentEnrollment,
  useGetTeacherDashboard, useListTeacherStudents, useUpdateStudentStatus, useCreateEnrollmentCode,
  useRevokeEnrollmentCode, useListTeacherAssignments, useCreateTeacherAssignment,
  usePublishTeacherAssignment, useExtendAssignmentDeadline, useCancelTeacherAssignment,
  useGetAssignmentMonitor, useListStudentAssignments, useGetStudentAssignment,
  useRequestPrivateUploadUrl, useSubmitAssignment, useGetTeacherSubmission, useSaveTeacherReview,
  useListNotifications, useMarkNotificationRead, useGetAiSettings, useTestAiConnection,
} from '@workspace/api-client-react';
import type { AttachmentInput, UserProfile } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const handoutPdf = `${basePath}/handouts/barakat-chemistry-2027.pdf`;

const queryClient = new QueryClient();
const rawClerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY?.trim();
const clerkPubKey = rawClerkPubKey
  ? publishableKeyFromHost(window.location.hostname, rawClerkPubKey)
  : '';
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const authAppearance = {
  theme: shadcn,
  variables: {
    colorPrimary: '#A044FF', colorForeground: '#F4F7FF', colorMutedForeground: '#A7B5D0',
    colorBackground: '#08142C', colorInput: '#0B1935', colorInputForeground: '#F4F7FF',
    colorDanger: '#ff727a', colorNeutral: '#A7B5D0', fontFamily: 'IBM Plex Sans Arabic',
    borderRadius: '14px',
  },
  layout: {
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    logoPlacement: 'inside' as const, socialButtonsPlacement: 'top' as const,
    socialButtonsVariant: 'blockButton' as const,
  },
  elements: {
    cardBox: 'w-[440px] max-w-full !bg-[#0B1935] !border !border-[#28416b] !shadow-2xl',
    headerTitle: '!text-[#F4F7FF]', headerSubtitle: '!text-[#A7B5D0]',
    formFieldLabel: '!text-[#dce7ff]', formFieldInput: '!bg-[#08142C] !text-[#F4F7FF] !border-[#29436d]',
    socialButtonsBlockButton: '!bg-[#102449] !text-[#F4F7FF] !border-[#29436d]',
    footerActionText: '!text-[#A7B5D0]', footerActionLink: '!text-[#08B9F5]',
    dividerText: '!text-[#A7B5D0]', identityPreviewText: '!text-[#F4F7FF]',
  },
};

function IconMark({ small = false }: { small?: boolean }) {
  return <span className={`brand-mark ${small ? 'brand-mark-small' : ''}`} aria-hidden="true"><img src={basePath + '/logo.svg'} alt="" /></span>;
}

function Brand({ to = '/' }: { to?: string }) {
  return <Link href={to} className="brand-lockup" data-testid="link-brand"><IconMark small /><span><b>معهد أستاذ بركات</b><small>كيمياء السادس الإعدادي</small></span></Link>;
}

function Button({ children, onClick, href, variant = 'primary', disabled, testId, type = 'button' }: {
  children: ReactNode; onClick?: () => void; href?: string; variant?: 'primary' | 'quiet' | 'outline' | 'danger';
  disabled?: boolean; testId: string; type?: 'button' | 'submit';
}) {
  const classes = `button button-${variant}`;
  if (href) return <Link href={href} className={classes} data-testid={testId}>{children}</Link>;
  return <button type={type} className={classes} onClick={onClick} disabled={disabled} data-testid={testId}>{children}</button>;
}

function PageTitle({ eyebrow, title, detail, action }: { eyebrow?: string; title: string; detail?: string; action?: ReactNode }) {
  return <div className="page-title"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1>{title}</h1>{detail && <p>{detail}</p>}</div>{action && <div className="page-title-action">{action}</div>}</div>;
}

function Loading({ label = 'جارٍ تحميل البيانات' }: { label?: string }) {
  return <div className="state-card" role="status" data-testid="state-loading"><span className="skeleton skeleton-icon" /><span className="skeleton skeleton-copy" /><span className="sr-only">{label}</span></div>;
}
function ErrorState({ onRetry, message = 'تعذر تحميل البيانات. تحقق من الاتصال ثم أعد المحاولة.' }: { onRetry: () => void; message?: string }) {
  return <div className="state-card state-error" role="alert" data-testid="state-error"><CircleAlert /><div><b>لم تكتمل العملية</b><p>{message}</p><button className="text-button" onClick={onRetry} data-testid="button-retry"><RefreshCw size={15} /> إعادة المحاولة</button></div></div>;
}
function EmptyState({ title, detail, icon: Icon = BookOpen }: { title: string; detail?: string; icon?: typeof BookOpen }) {
  return <div className="empty-state" data-testid="state-empty"><span className="empty-icon"><Icon /></span><h3>{title}</h3>{detail && <p>{detail}</p>}</div>;
}
function StatusPill({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'cyan' | 'violet' | 'green' | 'amber' | 'red' }) {
  return <span className={`status-pill status-${tone}`} data-testid="status-pill">{children}</span>;
}
function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}
function TextInput({ 'data-testid': testId, ...props }: InputHTMLAttributes<HTMLInputElement> & { 'data-testid'?: string }) {
  return <input {...props} className={`text-input ${props.className ?? ''}`} data-testid={testId ?? 'input-field'} />;
}
function TextArea({ 'data-testid': testId, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement> & { 'data-testid'?: string }) {
  return <textarea {...props} className={`text-input text-area ${props.className ?? ''}`} data-testid={testId ?? 'input-field'} />;
}
function formatDate(value?: string | null) {
  return value ? new Intl.DateTimeFormat('ar-IQ', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'غير محدد';
}
function formatCountdown(deadline?: string | null, now = Date.now()) {
  if (!deadline) return '—:—';
  const seconds = Math.max(0, Math.ceil((new Date(deadline).getTime() - now) / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remaining = seconds % 60;
  return hours > 0
    ? `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remaining).padStart(2, '0')}`
    : `${String(minutes).padStart(2, '0')}:${String(remaining).padStart(2, '0')}`;
}
function errorMessage(error: unknown) {
  if (typeof error === 'object' && error && 'message' in error && typeof error.message === 'string') return error.message;
  return 'حدث خطأ أثناء تنفيذ الطلب. لم يتم تأكيد الحفظ.';
}

function HandoutSection() {
  const [availability, setAvailability] = useState<'checking' | 'ready' | 'unavailable'>('checking');

  useEffect(() => {
    const controller = new AbortController();
    fetch(handoutPdf, { method: 'HEAD', cache: 'no-store', signal: controller.signal })
      .then(response => {
        const contentType = (response.headers.get('content-type') || '').toLowerCase();
        setAvailability(response.ok && (!contentType || contentType.includes('application/pdf')) ? 'ready' : 'unavailable');
      })
      .catch(() => {
        if (!controller.signal.aborted) setAvailability('unavailable');
      });
    return () => controller.abort();
  }, []);

  return <section className="container handout-section" id="handout">
    <div className="handout-card glass-panel">
      <div className="handout-cover" aria-hidden="true">
        <div className="cover-grid" />
        <FlaskConical size={56} />
        <span>2027</span>
        <i>CHEMISTRY · GRADE 6</i>
      </div>
      <div className="handout-copy">
        <span className="eyebrow">ملزمة المعهد</span>
        <h2>ملزمة أستاذ بركات للكيمياء — السادس الإعدادي</h2>
        <p>هذه ملزمة الكيمياء المخصصة لطلاب السادس الإعدادي من الأستاذ بركات، ويمكنك فتحها للقراءة والمراجعة أثناء الدراسة أو تنزيل نسخة PDF للاحتفاظ بها على جهازك.</p>
        <div className="handout-actions">
          {availability === 'ready'
            ? <a className="button button-primary" href={handoutPdf} target="_blank" rel="noopener noreferrer" data-testid="link-open-handout"><Eye size={17} /> فتح الملزمة</a>
            : <button className="button button-primary" type="button" disabled data-testid="button-open-handout-disabled">{availability === 'checking' ? <><LoaderCircle size={16} className="spin" /> جارٍ التحقق من الملف</> : 'الملزمة غير متاحة حالياً'}</button>}
          {availability === 'ready'
            ? <a className="button button-outline" href={handoutPdf} download="ملزمة-أستاذ-بركات-كيمياء-السادس.pdf" data-testid="link-download-handout"><ArrowDownToLine size={17} /> تنزيل PDF</a>
            : <button className="button button-outline" type="button" disabled data-testid="button-download-handout-disabled"><ArrowDownToLine size={17} /> تنزيل PDF</button>}
        </div>
        {availability === 'unavailable' && <p className="inline-error handout-error" role="alert">تعذر تحميل ملف الملزمة حالياً. حدّث الصفحة لاحقاً أو تحقق من أن الملف موجود ضمن ملفات الموقع المنشورة.</p>}
        <small className="handout-note">PDF · 175 صفحة · كيمياء السادس الإعدادي · إصدار 2027</small>
      </div>
    </div>
  </section>;
}

function Home({ authAvailable = true }: { authAvailable?: boolean }) {
  return <main className="app-shell" dir="rtl">
    <header className="public-nav"><Brand /><nav><a href="#handout" data-testid="link-handout-nav">المذكرة</a><a href="#about" data-testid="link-about">عن المعهد</a></nav>{authAvailable ? <div className="nav-actions"><Button href="/sign-in" variant="quiet" testId="link-signin">تسجيل الدخول</Button><Button href="/sign-up" testId="link-signup">إنشاء حساب طالب <ArrowLeft size={16} /></Button></div> : <div className="nav-actions"><span className="inline-error" role="status" data-testid="status-preview-config">نسخة اختبار غير مرتبطة بالخادم</span></div>}</header>
    <section className="hero container">
      <div className="hero-copy motion-in"><div className="hero-kicker"><span className="pulse-dot" /> تعليم كيمياء السادس الإعدادي</div><h1>الفهم يبدأ من<br /><em>التفاعل الصحيح.</em></h1><p>مساحة تعليمية منظمة لمتابعة واجبات الكيمياء وتسليم الحلول ومراجعتها مع الأستاذ بركات.</p><div className="hero-actions">{authAvailable ? <><Button href="/sign-up" testId="link-join">ابدأ كطالب <ArrowLeft size={17} /></Button><Button href="/sign-in" variant="outline" testId="link-login-secondary">لدي حساب بالفعل</Button></> : <p className="inline-error" role="status" data-testid="status-preview-details">هذه نسخة اختبار للواجهة والملزمة فقط. لا تدخل بيانات حسابك؛ يلزم إعداد خادم HTTPS ومصادقة Clerk لتفعيل الواجبات.</p>}</div><div className="hero-proof"><ShieldCheck size={16} /><span>انضمام الطلاب ومتابعة الواجبات بإشراف المعهد</span></div></div>
      <div className="hero-art" aria-label="رسم علمي مجرد" data-testid="art-chemistry"><div className="art-halo hero-orb" /><div className="art-ring ring-one" /><div className="art-ring ring-two" /><div className="molecule"><span className="atom atom-a">C</span><span className="atom atom-b">O</span><span className="atom atom-c">H</span><i className="bond bond-a" /><i className="bond bond-b" /><i className="bond bond-c" /></div><div className="formula formula-top">H₂O</div><div className="formula formula-bottom">C₆H₁₂O₆</div><IconMark /></div>
    </section>
    <div className="shine-line" />
    <section className="container public-content" id="about"><div className="section-heading"><div><span className="eyebrow">منهج واضح ومتابعة مباشرة</span><h2>مسار دراسي يترك مساحة للتركيز</h2></div><p>أدوات عملية للطالب والأستاذ، من نشر الواجب حتى مراجعة الحل.</p></div><div className="feature-rail"><article className="feature-item"><span><ClipboardList /></span><h3>واجبات منظمة</h3><p>تعليمات وموعد تسليم واضحان لكل واجب منشور.</p></article><article className="feature-item"><span><ImagePlus /></span><h3>تسليم من الهاتف</h3><p>ارفع صور الحل أو ملفاته ضمن صفحة الواجب.</p></article><article className="feature-item"><span><CheckCircle2 /></span><h3>مراجعة الأستاذ</h3><p>تابع حالة التسليم وملاحظات المراجعة عند توفرها.</p></article></div></section>
    <HandoutSection />
    <section className="container public-bottom"><div><Atom /><div><b>معهد أستاذ بركات</b><span>كيمياء السادس الإعدادي</span></div></div><p>التعلم المنظم يبدأ بخطوة واضحة.</p></section>
  </main>;
}

function AuthPage({ signUp = false }: { signUp?: boolean }) {
  return <main className="app-shell auth-page" dir="rtl"><div className="auth-side chem-grid"><Brand /><div><IconMark /><h1>معادلات أوضح،<br />خطوات أثبت.</h1><p>منصة متابعة واجبات الكيمياء لطلاب السادس الإعدادي.</p></div><span className="auth-side-foot">معهد أستاذ بركات · العراق</span></div><div className="auth-main"><div className="auth-mobile-brand"><Brand /></div>{signUp ? <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} appearance={authAppearance} /> : <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} appearance={authAppearance} />}</div></main>;
}

function UserMenu({ name }: { name?: string }) {
  const clerk = useClerk();
  const [open, setOpen] = useState(false);
  return <div className="user-menu-wrap"><button className="user-menu" onClick={() => setOpen(!open)} data-testid="button-user-menu"><span className="user-avatar">{name?.trim().slice(0, 1) || 'ب'}</span><span className="user-menu-name">{name || 'الحساب'}</span><ChevronDown size={15} /></button>{open && <div className="user-popover"><div className="popover-name">{name || 'الحساب'}</div><button onClick={() => clerk.signOut({ redirectUrl: '/' })} data-testid="button-signout"><LogOut size={15} /> تسجيل الخروج</button></div>}</div>;
}
type PortalNavItem = {
  href: string;
  label: string;
  icon: typeof HomeIcon;
  isActive: (location: string) => boolean;
};
const studentNav: PortalNavItem[] = [
  { href: '/student', label: 'الرئيسية', icon: HomeIcon, isActive: path => path === '/student' },
  { href: '/student/assignments', label: 'الواجبات', icon: ClipboardList, isActive: path => path === '/student/assignments' || path.startsWith('/student/assignment/') },
  { href: '/student/submissions', label: 'التسليمات', icon: FileText, isActive: path => path === '/student/submissions' },
  { href: '/student/notifications', label: 'الإشعارات', icon: Bell, isActive: path => path === '/student/notifications' },
  { href: '/student/profile', label: 'حسابي', icon: UserRound, isActive: path => path === '/student/profile' },
];
const teacherNav: PortalNavItem[] = [
  { href: '/teacher/dashboard', label: 'الرئيسية', icon: HomeIcon, isActive: path => path === '/teacher/dashboard' },
  { href: '/teacher/assignments/new', label: 'إنشاء', icon: Plus, isActive: path => path === '/teacher/assignments/new' },
  { href: '/teacher/assignments', label: 'الواجبات', icon: ClipboardList, isActive: path => path === '/teacher/assignments' || (path.startsWith('/teacher/assignments/') && path !== '/teacher/assignments/new') },
  { href: '/teacher/students', label: 'الطلاب', icon: Users, isActive: path => path === '/teacher/students' },
  { href: '/teacher/submissions', label: 'التسليمات', icon: FileText, isActive: path => path === '/teacher/submissions' },
  { href: '/teacher/notifications', label: 'الإشعارات', icon: Bell, isActive: path => path === '/teacher/notifications' },
  { href: '/teacher/settings', label: 'الإعدادات', icon: Settings, isActive: path => path === '/teacher/settings' },
];
function PortalShell({ role, name, children }: { role: 'student' | 'teacher'; name: string; children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const nav = role === 'teacher' ? teacherNav : studentNav;
  const [location] = useLocation();
  return <div className="portal" dir="rtl">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="sidebar-brand"><Brand to={role === 'teacher' ? '/teacher/dashboard' : '/student'} /><button className="icon-button mobile-close" onClick={() => setMobileOpen(false)} aria-label="إغلاق القائمة" data-testid="button-close-menu"><X /></button></div>
      <div className="sidebar-label">{role === 'teacher' ? 'إدارة المعهد' : 'مساحة الطالب'}</div>
      <nav className="side-nav" aria-label={role === 'teacher' ? 'تنقل الأستاذ' : 'تنقل الطالب'}>
        {nav.map(item => {
          const active = item.isActive(location);
          return <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className={`side-link ${active ? 'side-active' : ''}`} aria-current={active ? 'page' : undefined} data-testid={`link-nav-${item.href.split('/').pop()}`}><item.icon size={18} /><span>{item.label}</span>{active && <ChevronLeft size={15} />}</Link>;
        })}
      </nav>
      <div className="sidebar-bottom"><div className="course-chip"><span className="course-icon"><Atom size={17} /></span><div><b>كيمياء السادس</b><small>العام الدراسي 2027</small></div></div><p>معهد أستاذ بركات</p></div>
    </aside>
    <div className={`sidebar-scrim ${mobileOpen ? 'scrim-visible' : ''}`} onClick={() => setMobileOpen(false)} role="presentation" />
    <div className="portal-main">
      <header className="portal-topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="فتح القائمة" data-testid="button-open-menu"><Menu /></button><div className="topbar-label"><span className="topbar-dot" />{role === 'teacher' ? 'لوحة الأستاذ' : 'بوابة الطالب'}</div><div className="topbar-user"><span className="topbar-course">كيمياء السادس الإعدادي</span><UserMenu name={name} /></div></header>
      <main className="portal-content">{children}</main>
      <footer className="portal-footer">معهد أستاذ بركات <span>•</span> كيمياء السادس الإعدادي</footer>
    </div>
    <nav className={`mobile-tabbar mobile-tabbar-${role}`} aria-label={role === 'teacher' ? 'تنقل الأستاذ' : 'تنقل الطالب'}>
      {nav.map(item => {
        const active = item.isActive(location);
        return <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className={`mobile-tab ${active ? 'mobile-tab-active' : ''}`} aria-current={active ? 'page' : undefined} data-testid={`link-mobile-nav-${item.href.split('/').pop()}`}><item.icon size={18} aria-hidden="true" /><span>{item.label}</span></Link>;
      })}
    </nav>
  </div>;
}

function Gate({ role, children }: { role: 'student' | 'teacher'; children: (user: UserProfile) => ReactNode }) {
  const { data: user, isLoading, isError, refetch } = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } });
  if (isLoading) return <div className="app-shell portal-loading" dir="rtl"><Loading /></div>;
  if (isError || !user) return <main className="app-shell gated" dir="rtl"><div className="glass-panel gated-card"><CircleAlert /><h1>تعذر التحقق من الحساب</h1><p>لم نتمكن من قراءة صلاحية الدخول. أعد المحاولة أو سجّل الدخول مجدداً.</p><Button onClick={() => refetch()} testId="button-auth-retry">إعادة المحاولة</Button><Button href="/sign-in" variant="quiet" testId="link-auth-again">الانتقال لتسجيل الدخول</Button></div></main>;
  if (role === 'teacher' && user.role !== 'TEACHER') return <Redirect to={user.enrollmentStatus === 'ACCEPTED' ? '/student' : '/student/enrollment'} />;
  if (role === 'student' && user.role !== 'STUDENT') return <Redirect to="/teacher/dashboard" />;
  if (role === 'student' && user.enrollmentStatus !== 'ACCEPTED') return <Redirect to="/student/enrollment" />;
  return <>{children(user)}</>;
}
function SignedInRoute({ children }: { children: ReactNode }) {
  return <><Show when="signed-in"><BrowserNotificationBridge />{children}</Show><Show when="signed-out"><Redirect to="/sign-in" /></Show></>;
}
function Enrollment() {
  const { data: user, isLoading, isError, refetch } = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } });
  const enrollment = useGetStudentEnrollment({ query: { enabled: user?.role === 'STUDENT', queryKey: getGetStudentEnrollmentQueryKey() } });
  const request = useRequestStudentEnrollment();
  const qc = useQueryClient();
  const [code, setCode] = useState('');
  if (isLoading) return <div className="app-shell" dir="rtl"><Loading /></div>;
  if (isError || !user) return <div className="app-shell gated" dir="rtl"><ErrorState onRetry={() => refetch()} /></div>;
  if (user.role === 'TEACHER') return <Redirect to="/teacher/dashboard" />;
  if (user.enrollmentStatus === 'ACCEPTED') return <Redirect to="/student" />;
  const status = enrollment.data?.status ?? user.enrollmentStatus;
  return <div className="app-shell enrollment-page" dir="rtl"><div className="enrollment-top"><Brand /><UserMenu name={user.displayName} /></div><section className="enrollment-card glass-panel"><span className="enrollment-emblem"><Users /></span><span className="eyebrow">بوابة الطالب</span><h1>{status === 'PENDING' ? 'طلبك قيد المراجعة' : status === 'REJECTED' || status === 'SUSPENDED' ? 'تعذر إكمال الانضمام' : 'انضم إلى المعهد'}</h1><p>{status === 'PENDING' ? 'تم تسجيل طلبك. ستتمكن من الوصول إلى الواجبات بعد موافقة الأستاذ.' : status === 'REJECTED' || status === 'SUSPENDED' ? 'حالة الحساب لا تسمح بالدخول إلى الواجبات. تواصل مع الأستاذ عبر القنوات المعتمدة في المعهد.' : 'أدخل رمز الانضمام الذي زودك به الأستاذ لطلب الوصول إلى واجبات الكيمياء.'}</p>
    {status === 'NOT_SUBMITTED' && <form onSubmit={e => { e.preventDefault(); request.mutate({ data: { code: code.trim() } }, { onSuccess: () => { void qc.invalidateQueries({ queryKey: getGetStudentEnrollmentQueryKey() }); void qc.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); } }); }} className="enrollment-form"><Field label="رمز الانضمام"><TextInput value={code} onChange={e => setCode(e.target.value)} minLength={4} maxLength={64} required placeholder="أدخل الرمز" data-testid="input-enrollment-code" /></Field>{request.isError && <p className="inline-error" role="alert">{errorMessage(request.error)}</p>}<Button type="submit" disabled={request.isPending || code.trim().length < 4} testId="button-request-enrollment">{request.isPending ? <><LoaderCircle className="spin" /> جارٍ إرسال الطلب</> : <>إرسال طلب الانضمام <ArrowLeft size={16} /></>}</Button></form>}
    {enrollment.isLoading && <p className="muted-line"><LoaderCircle className="spin" /> جارٍ تحديث حالة الانضمام</p>}
    {enrollment.isError && <ErrorState onRetry={() => void enrollment.refetch()} />}
    <div className="enrollment-status"><span>حالة الحساب</span><StatusPill tone={status === 'PENDING' ? 'amber' : status === 'ACCEPTED' ? 'green' : 'neutral'}>{status === 'PENDING' ? 'بانتظار الموافقة' : status === 'ACCEPTED' ? 'مقبول' : status === 'REJECTED' ? 'مرفوض' : status === 'SUSPENDED' ? 'موقوف' : 'لم يُرسل طلب'}</StatusPill></div><button className="text-button enrollment-refresh" onClick={() => { void refetch(); void enrollment.refetch(); }} data-testid="button-refresh-enrollment"><RefreshCw size={14} /> تحديث الحالة</button>
  </section></div>;
}

function StudentHome({ user }: { user: { displayName: string } }) {
  const q = useListStudentAssignments({ query: { queryKey: getListStudentAssignmentsQueryKey() } });
  const notifications = useListNotifications({ query: { queryKey: getListNotificationsQueryKey() } });
  const active = q.data?.filter(a => a.status === 'OPEN') ?? [];
  const recent = q.data?.slice(0, 3) ?? [];
  return <PortalShell role="student" name={user.displayName}><div className="welcome-band"><div><span className="eyebrow">مساحة الطالب</span><h1>أهلاً، {user.displayName}</h1><p>تابع واجبات الكيمياء ومواعيد التسليم من مكان واحد.</p></div><span className="welcome-symbol"><Atom /></span></div>
    <div className="content-section"><div className="section-title-row"><div><span className="eyebrow">المتاح الآن</span><h2>واجباتك</h2></div><Link href="/student/assignments" className="text-link" data-testid="link-all-assignments">عرض الكل <ArrowLeft size={15} /></Link></div>
      {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : active.length === 0 ? <EmptyState title="لا توجد واجبات متاحة حالياً" detail="ستظهر هنا الواجبات التي ينشرها الأستاذ." /> : <div className="assignment-list">{active.map(a => <Link href={`/student/assignment/${a.id}`} className="assignment-row glass-panel" key={a.id} data-testid={`card-student-assignment-${a.id}`}><span className="assignment-icon"><FileText /></span><span className="assignment-info"><b>{a.title}</b><small>{a.chapter} <i>·</i> موعد التسليم: {formatDate(a.deadlineAt)}</small></span><StatusPill tone={a.submissionStatus === 'SUBMITTED' || a.submissionStatus === 'REVIEWED' ? 'green' : 'cyan'}>{a.submissionStatus === 'SUBMITTED' ? 'تم التسليم' : a.submissionStatus === 'REVIEWED' ? 'تمت المراجعة' : 'بانتظار التسليم'}</StatusPill><ChevronLeft className="row-arrow" /></Link>)}</div>}
    </div>
    <div className="student-dashboard-grid"><section className="content-section"><div className="section-title-row"><div><span className="eyebrow">السجل</span><h2>آخر الواجبات</h2></div></div>{q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : recent.length === 0 ? <EmptyState title="لا يوجد سجل واجبات بعد" detail="ستظهر تسليماتك هنا بعد نشر أول واجب." icon={ClipboardList} /> : <div className="history-list">{recent.map(item => <div className="history-row" key={item.id} data-testid={`row-history-${item.id}`}><span className="history-mark"><Check size={15} /></span><div><b>{item.title}</b><small>{item.chapter}</small></div><StatusPill tone={item.submissionStatus === 'REVIEWED' ? 'green' : 'neutral'}>{item.submissionStatus === 'WAITING' ? 'بانتظار التسليم' : item.submissionStatus === 'SUBMITTED' ? 'تم التسليم' : item.submissionStatus === 'REVIEWED' ? 'تمت المراجعة' : item.submissionStatus === 'MISSING' ? 'لم يتم التسليم' : 'ملغى'}</StatusPill></div>)}</div>}</section>
      <section className="content-section notification-peek"><div className="section-title-row"><div><span className="eyebrow">التنبيهات</span><h2>الإشعارات</h2></div><Link href="/student/notifications" className="text-link" data-testid="link-notifications">الكل <ArrowLeft size={15} /></Link></div>{notifications.isLoading ? <Loading /> : notifications.isError ? <ErrorState onRetry={() => void notifications.refetch()} /> : (notifications.data?.length ?? 0) === 0 ? <EmptyState title="لا توجد إشعارات" detail="سيظهر هنا أي تنبيه جديد يخص واجباتك." icon={Bell} /> : notifications.data?.slice(0, 2).map(n => <div className="notice-mini" key={n.id}><span className={`notice-dot ${n.readAt ? '' : 'notice-unread'}`} /><div><b>{n.title}</b><small>{n.body}</small></div></div>)}</section></div>
  </PortalShell>;
}

function studentAssignmentBadge(assignment: { status: string; submissionStatus: string }) {
  if (assignment.status === 'CANCELLED' || assignment.submissionStatus === 'CANCELLED') return { label: 'ملغى', tone: 'neutral' as const };
  if (assignment.submissionStatus === 'REVIEWED') return { label: 'تمت المراجعة', tone: 'green' as const };
  if (assignment.submissionStatus === 'SUBMITTED') return { label: 'تم التسليم', tone: 'cyan' as const };
  if (assignment.submissionStatus === 'MISSING') return { label: 'لم يتم التسليم', tone: 'red' as const };
  if (assignment.status === 'OPEN') return { label: 'بانتظار التسليم', tone: 'amber' as const };
  return { label: 'مغلق', tone: 'neutral' as const };
}

function StudentAssignments() {
  const q = useListStudentAssignments({ query: { queryKey: getListStudentAssignmentsQueryKey() } });
  return <Gate role="student">{user => <PortalShell role="student" name={user.displayName}>
    <PageTitle eyebrow="مساحة الطالب" title="واجباتي" detail="الواجبات المنشورة لك وحالة كل موعد تسليم." />
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : <>
      <section className="content-section"><div className="section-title-row"><div><span className="eyebrow">مفتوحة</span><h2>تحتاج إلى متابعة</h2></div></div>
        {q.data?.filter(item => item.status === 'OPEN').length === 0
          ? <EmptyState title="لا توجد واجبات مفتوحة" detail="ستظهر هنا الواجبات المنشورة التي لم تغلق مواعيدها." />
          : <div className="assignment-list">{q.data?.filter(item => item.status === 'OPEN').map(item => {
            const badge = studentAssignmentBadge(item);
            return <Link href={`/student/assignment/${item.id}`} className="assignment-row glass-panel" key={item.id} data-testid={`card-student-open-${item.id}`}><span className="assignment-icon"><FileText /></span><span className="assignment-info"><b>{item.title}</b><small>{item.chapter} <i>·</i> موعد التسليم: {formatDate(item.deadlineAt)}</small></span><StatusPill tone={badge.tone}>{badge.label}</StatusPill><ChevronLeft className="row-arrow" /></Link>;
          })}</div>}
      </section>
      <section className="content-section"><div className="section-title-row"><div><span className="eyebrow">السجل</span><h2>الواجبات السابقة والمغلقة</h2></div></div>
        {q.data?.filter(item => item.status !== 'OPEN').length === 0
          ? <EmptyState title="لا توجد واجبات سابقة" detail="ستظهر الواجبات هنا بعد إغلاقها." icon={ClipboardList} />
          : <div className="assignment-list">{q.data?.filter(item => item.status !== 'OPEN').map(item => {
            const badge = studentAssignmentBadge(item);
            return <Link href={`/student/assignment/${item.id}`} className="assignment-row glass-panel" key={item.id} data-testid={`card-student-past-${item.id}`}><span className="assignment-icon"><FileText /></span><span className="assignment-info"><b>{item.title}</b><small>{item.chapter} <i>·</i> موعد التسليم: {formatDate(item.deadlineAt)}</small></span><StatusPill tone={badge.tone}>{badge.label}</StatusPill><ChevronLeft className="row-arrow" /></Link>;
          })}</div>}
      </section>
    </>}
  </PortalShell>}</Gate>;
}

function StudentSubmissions() {
  const q = useListStudentAssignments({ query: { queryKey: getListStudentAssignmentsQueryKey() } });
  const submitted = q.data?.filter(item => Boolean(item.submittedAt)) ?? [];
  return <Gate role="student">{user => <PortalShell role="student" name={user.displayName}>
    <PageTitle eyebrow="سجل الحلول" title="تسليماتي" detail="التسليمات المحفوظة ونتيجة مراجعة الأستاذ." />
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : submitted.length === 0
      ? <EmptyState title="لا توجد تسليمات بعد" detail="بعد إرسال حل واجب، سيظهر سجلّه هنا." icon={FileText} />
      : <div className="assignment-list">{submitted.map(item => {
        const badge = studentAssignmentBadge(item);
        return <Link href={`/student/assignment/${item.id}`} className="assignment-row glass-panel" key={item.id} data-testid={`card-student-submission-${item.id}`}><span className="assignment-icon"><CheckCircle2 /></span><span className="assignment-info"><b>{item.title}</b><small>{item.chapter} <i>·</i> وقت التسليم: {formatDate(item.submittedAt)}</small></span><StatusPill tone={badge.tone}>{badge.label}</StatusPill><ChevronLeft className="row-arrow" /></Link>;
      })}</div>}
  </PortalShell>}</Gate>;
}

function StudentProfile() {
  const clerk = useClerk();
  return <Gate role="student">{user => <PortalShell role="student" name={user.displayName}>
    <PageTitle eyebrow="الحساب" title="حسابي" detail="بيانات الحساب وحالة الانضمام المسجلة لدى المعهد." />
    <section className="glass-panel profile-card" data-testid="student-profile">
      <div className="profile-heading"><span className="user-avatar">{user.displayName.trim().slice(0, 1) || 'ط'}</span><div><h2>{user.displayName}</h2><p>{user.email}</p></div></div>
      <div className="profile-fields"><div><span>الدور</span><b>طالب</b></div><div><span>حالة الانضمام</span><b>{user.enrollmentStatus === 'ACCEPTED' ? 'مقبول' : user.enrollmentStatus === 'PENDING' ? 'بانتظار الموافقة' : user.enrollmentStatus === 'REJECTED' ? 'مرفوض' : user.enrollmentStatus === 'SUSPENDED' ? 'موقوف' : 'لم يُرسل طلب'}</b></div></div>
      <p className="muted-line">تُدار بيانات تسجيل الدخول والبريد من خلال مزود الحساب الآمن.</p>
      <Button variant="danger" onClick={() => void clerk.signOut({ redirectUrl: '/' })} testId="button-profile-signout"><LogOut size={16} /> تسجيل الخروج</Button>
    </section>
  </PortalShell>}</Gate>;
}

function UploadQueue({ files, setFiles, disabled }: { files: File[]; setFiles: (f: File[]) => void; disabled?: boolean }) {
  const [pickerBusy, setPickerBusy] = useState(false);
  const [pickerError, setPickerError] = useState('');
  const addFiles = (incoming: FileList | null) => {
    if (!incoming) return;
    const received = Array.from(incoming);
    const valid = received.filter(f => /^(image\/(jpeg|png|webp)|application\/pdf)$/.test(f.type) && f.size > 0 && f.size <= 10 * 1024 * 1024);
    const remaining = Math.max(0, 20 - files.length);
    setFiles([...files, ...valid.slice(0, remaining)]);
    if (received.length > 0 && valid.length === 0) setPickerError('الصورة أو الملف غير مدعوم أو أكبر من 10 ميغابايت.');
    else if (valid.length > remaining) setPickerError('الحد الأقصى 20 ملفاً للواجب.');
    else setPickerError('');
  };
  const convertPickedImage = async (webPath: string, format?: string) => {
    const response = await fetch(webPath);
    if (!response.ok) throw new Error('تعذر فتح الصورة المختارة من الهاتف.');
    const blob = await response.blob();
    const fallbackType = format === 'png' ? 'image/png' : format === 'webp' ? 'image/webp' : 'image/jpeg';
    const mime = blob.type || fallbackType;
    if (!/^(image\/jpeg|image\/png|image\/webp)$/.test(mime)) throw new Error('نوع الصورة غير مدعوم. اختر JPG أو PNG أو WEBP.');
    if (blob.size <= 0 || blob.size > 10 * 1024 * 1024) throw new Error('حجم الصورة يجب ألا يتجاوز 10 ميغابايت.');
    const extension = mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
    const fileName = 'solution-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7) + '.' + extension;
    return new File([blob], fileName, { type: mime, lastModified: Date.now() });
  };
  const pickFromGallery = async () => {
    if (disabled || pickerBusy || files.length >= 20) return;
    setPickerError('');
    setPickerBusy(true);
    try {
      const result = await NativeCamera.pickImages({ quality: 88, limit: Math.max(1, 20 - files.length) });
      const chosen: File[] = [];
      for (const photo of result.photos) {
        if (!photo.webPath) continue;
        chosen.push(await convertPickedImage(photo.webPath, photo.format));
      }
      const remaining = Math.max(0, 20 - files.length);
      setFiles([...files, ...chosen.slice(0, remaining)]);
      if (chosen.length > remaining) setPickerError('تمت إضافة 20 ملفاً فقط؛ أزل ملفاً لإضافة المزيد.');
    } catch (error) {
      const message = error instanceof Error ? error.message : '';
      if (!/cancel|cancelled|canceled|OS-PLUG-CAMR-0006/i.test(message)) setPickerError(message || 'تعذر فتح معرض الصور. جرّب اختيار صور أو PDF.');
    } finally {
      setPickerBusy(false);
    }
  };
  const takePhoto = async () => {
    if (disabled || pickerBusy || files.length >= 20) return;
    setPickerError('');
    setPickerBusy(true);
    try {
      const photo = await NativeCamera.getPhoto({ quality: 90, allowEditing: false, resultType: CameraResultType.Uri, source: CameraSource.Camera, correctOrientation: true });
      if (!photo.webPath) throw new Error('لم تُرجع الكاميرا صورة صالحة.');
      const file = await convertPickedImage(photo.webPath, photo.format);
      setFiles([...files, file].slice(0, 20));
    } catch (error) {
      const message = error instanceof Error ? error.message : '';
      if (!/cancel|cancelled|canceled|OS-PLUG-CAMR-0006/i.test(message)) setPickerError(message || 'تعذر تشغيل الكاميرا. يمكنك اختيار صورة من المعرض.');
    } finally {
      setPickerBusy(false);
    }
  };
  return <div className="upload-area">
    <div className="upload-controls">
      {Capacitor.isNativePlatform() && <button type="button" className="upload-pick native-upload-button" disabled={disabled || pickerBusy || files.length >= 20} onClick={() => void pickFromGallery()} data-testid="button-native-pick-photos"><ImagePlus size={17} /> {pickerBusy ? 'جارٍ تجهيز الصورة…' : 'اختيار من المعرض'}</button>}
      <label className={"upload-pick " + (disabled ? "disabled" : "")}><input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple disabled={disabled} onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} data-testid="input-solution-files" /><Upload size={17} /> اختيار صور أو PDF</label>
      {Capacitor.isNativePlatform()
        ? <button type="button" className="upload-pick native-upload-button" disabled={disabled || pickerBusy || files.length >= 20} onClick={() => void takePhoto()} data-testid="button-native-take-photo"><Camera size={17} /> التقاط صورة</button>
        : <label className={"upload-pick camera-pick " + (disabled ? "disabled" : "")}><input type="file" accept="image/*" capture="environment" disabled={disabled} onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} data-testid="input-camera-file" /><Camera size={17} /> التقاط صورة</label>}
    </div>
    {pickerError && <p className="inline-error upload-picker-error" role="alert">{pickerError}</p>}
    <small>اختر الصور من المعرض أو التقطها بالكاميرا أو أرفق PDF. الأنواع المسموحة JPG وPNG وWEBP وPDF، حتى 10 ميغابايت للملف، وبحد أقصى 20 ملفاً.</small>
    {files.length > 0 && <div className="file-preview-list">{files.map((file, i) => <div className="file-preview" key={file.name + '-' + file.lastModified + '-' + i} data-testid={'file-preview-' + i}><FileThumb file={file} /><div><b>{file.name}</b><small>{(file.size / 1024 / 1024).toFixed(1)} ميغابايت</small></div><div className="file-order"><button type="button" onClick={() => { if (i > 0) { const next = [...files]; [next[i - 1], next[i]] = [next[i], next[i - 1]]; setFiles(next); } }} disabled={i === 0} aria-label="رفع الملف للأعلى" data-testid={'button-move-up-' + i}><ArrowRight size={15} /></button><button type="button" onClick={() => { if (i < files.length - 1) { const next = [...files]; [next[i + 1], next[i]] = [next[i], next[i + 1]]; setFiles(next); } }} disabled={i === files.length - 1} aria-label="خفض الملف للأسفل" data-testid={'button-move-down-' + i}><ArrowLeft size={15} /></button></div><button type="button" className="icon-button remove-file" onClick={() => setFiles(files.filter((_, index) => index !== i))} aria-label="حذف الملف" data-testid={'button-remove-file-' + i}><X size={16} /></button></div>)}</div>}
  </div>;
}
function FileThumb({ file }: { file: File }) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    if (!file.type.startsWith('image/')) return;
    const objectUrl = URL.createObjectURL(file);
    setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);
  return url ? <img className="file-thumb" src={url} alt={`معاينة ${file.name}`} /> : <span className="file-preview-icon">{file.type.startsWith('image/') ? <FileImage /> : <FileText />}</span>;
}
function StudentAssignmentPage() {
  const { assignmentId = '' } = useParams<{ assignmentId: string }>();
  const q = useGetStudentAssignment(assignmentId, { query: { queryKey: getGetStudentAssignmentQueryKey(assignmentId), enabled: !!assignmentId, refetchInterval: 15000 } });
  const upload = useRequestPrivateUploadUrl();
  const submit = useSubmitAssignment();
  const qc = useQueryClient();
  const [files, setFiles] = useState<File[]>([]);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [uploadError, setUploadError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const assignment = q.data;
  const [serverClockNow, setServerClockNow] = useState<number | null>(null);
  useEffect(() => {
    if (!assignment?.serverNow) {
      setServerClockNow(null);
      return;
    }
    const serverAtResponse = new Date(assignment.serverNow).getTime();
    if (!Number.isFinite(serverAtResponse)) {
      setServerClockNow(null);
      return;
    }
    const monotonicAtResponse = performance.now();
    const tick = () => setServerClockNow(serverAtResponse + performance.now() - monotonicAtResponse);
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [assignment?.serverNow]);
  const remainingSeconds = assignment?.deadlineAt && serverClockNow !== null
    ? Math.max(0, Math.ceil((new Date(assignment.deadlineAt).getTime() - serverClockNow) / 1000))
    : 0;
  const locked = !assignment || serverClockNow === null || assignment.status !== 'OPEN' || assignment.submissionStatus !== 'WAITING' || !!assignment.submission || remainingSeconds <= 0;
  const handleSubmit = async () => {
    if (!assignment || files.length === 0 || upload.isPending || submit.isPending) return;
    setUploadError(''); setSubmitted(false); setProgress({ done: 0, total: files.length });
    const attachments: AttachmentInput[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const signed = await upload.mutateAsync({ data: { filename: file.name, contentType: file.type, sizeBytes: file.size, purpose: 'SUBMISSION', assignmentId } });
        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.open('PUT', signed.uploadUrl);
          xhr.setRequestHeader('Content-Type', file.type);
          xhr.upload.onprogress = e => { if (e.lengthComputable) setUploadError(`جارٍ رفع الملف ${i + 1} من ${files.length}: ${Math.round(e.loaded / e.total * 100)}٪`); };
          xhr.onload = () => xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`تعذر رفع ${file.name} (${xhr.status})`));
          xhr.onerror = () => reject(new Error(`انقطع الاتصال أثناء رفع ${file.name}`));
          xhr.onabort = () => reject(new Error(`تم إيقاف رفع ${file.name}`));
          xhr.send(file);
        });
        attachments.push({ objectPath: signed.objectPath, filename: file.name, contentType: file.type, sizeBytes: file.size, sortOrder: i });
        setProgress({ done: i + 1, total: files.length });
      }
      setUploadError('');
      const result = await submit.mutateAsync({ assignmentId, data: { idempotencyKey: crypto.randomUUID(), attachments } });
      if (!result?.id) throw new Error('لم يؤكد الخادم حفظ التسليم.');
      setSubmitted(true); setFiles([]);
      await Promise.all([qc.invalidateQueries({ queryKey: getGetStudentAssignmentQueryKey(assignmentId) }), qc.invalidateQueries({ queryKey: getListStudentAssignmentsQueryKey() }), qc.invalidateQueries({ queryKey: getListNotificationsQueryKey() })]);
    } catch (error) { setUploadError(errorMessage(error)); }
    finally { setProgress(null); }
  };
  return <Gate role="student">{profile => <PortalShell role="student" name={profile.displayName}><PageTitle eyebrow="واجب الكيمياء" title={assignment?.title ?? 'تفاصيل الواجب'} detail={assignment?.chapter} action={<Button href="/student" variant="quiet" testId="link-back-student"><ArrowRight size={16} /> العودة للبوابة</Button>} />
    {q.isLoading ? <Loading /> : q.isError || !assignment ? <ErrorState onRetry={() => void q.refetch()} /> : <div className="detail-grid"><section className="detail-main glass-panel"><div className="detail-meta"><StatusPill tone={assignment.status === 'OPEN' ? 'cyan' : 'neutral'}>{assignment.status === 'OPEN' ? 'مفتوح للتسليم' : assignment.status === 'CLOSED' ? 'مغلق' : 'ملغى'}</StatusPill><span><CalendarClock size={15} /> موعد التسليم: {formatDate(assignment.deadlineAt)}</span></div><h2>تعليمات الأستاذ</h2><p className="instructions">{assignment.instructions || 'لا توجد تعليمات إضافية لهذا الواجب.'}</p>{assignment.attachments.length > 0 && <div className="detail-attachments"><h3>ملفات الواجب</h3>{assignment.attachments.map((a, i) => <a href={a.viewUrl ?? undefined} target="_blank" rel="noreferrer" className={`attachment-link ${!a.viewUrl ? 'attachment-disabled' : ''}`} key={a.objectPath} data-testid={`link-assignment-file-${i}`}><FileText />{a.filename}<ExternalLink size={14} /></a>)}</div>}
      {assignment.submission ? <div className="submitted-state"><CheckCircle2 /><div><b>{assignment.submission.status === 'REVIEWED' ? 'تمت مراجعة الحل' : 'تم إرسال الحل'}</b><small>وقت التسليم: {formatDate(assignment.submission.submittedAt)}</small>{assignment.submission.reviewNote && <p className="review-note"><b>ملاحظة الأستاذ:</b> {assignment.submission.reviewNote}</p>}<div className="submission-attachments"><b>الملفات التي أرسلتها</b>{assignment.submission.attachments.length === 0 ? <small>لا توجد مرفقات مسجلة.</small> : <div className="submission-attachment-grid">{assignment.submission.attachments.map((attachment, index) => <a className={`submission-attachment ${!attachment.viewUrl ? 'attachment-disabled' : ''}`} href={attachment.viewUrl ?? undefined} target="_blank" rel="noreferrer" key={attachment.objectPath} data-testid={`link-my-submission-attachment-${index}`}>{attachment.contentType.startsWith('image/') && attachment.viewUrl ? <img src={attachment.viewUrl} alt={`صورة الحل ${index + 1}: ${attachment.filename}`} loading="lazy" /> : <span className="review-file-icon"><FileText /></span>}<span>{attachment.filename}</span><ExternalLink size={14} /></a>)}</div>}</div></div></div> : <><div className="upload-heading"><div><h3>إرفاق الحل</h3><p>اختر صور الحل أو التقطها مباشرة من هاتفك.</p></div><StatusPill>{files.length} ملفات</StatusPill></div><UploadQueue files={files} setFiles={setFiles} disabled={locked || !!progress} />{uploadError && <p className={progress ? 'inline-info' : 'inline-error'} role={progress ? 'status' : 'alert'}>{uploadError}</p>}{submitted && <p className="inline-success" role="status" data-testid="status-submission-confirmed">تم تأكيد إرسال الحل من الخادم.</p>}{submit.isError && <p className="inline-error" role="alert">{errorMessage(submit.error)}</p>}<Button onClick={() => void handleSubmit()} disabled={locked || files.length === 0 || !!progress || submit.isPending} testId="button-submit-assignment">{progress ? <><LoaderCircle className="spin" /> رفع الملفات {progress.done}/{progress.total}</> : submit.isPending ? <><LoaderCircle className="spin" /> جارٍ تأكيد التسليم</> : <><Send size={16} /> إرسال الحل للأستاذ</>}</Button>{locked && !assignment.submission && <p className="muted-line">لا يمكن التسليم في الحالة الحالية للواجب.</p>}</>}
      </section><aside className="detail-aside"><div className="glass-panel deadline-card"><span className="eyebrow">الوقت المتبقي</span><div className={`countdown-ring ${remainingSeconds <= 300 ? 'countdown-warning' : ''}`} aria-live="polite"><b>{serverClockNow === null ? '—:—' : formatCountdown(assignment.deadlineAt, serverClockNow)}</b><small>{serverClockNow === null ? 'جارٍ مزامنة وقت الخادم' : remainingSeconds === 0 ? 'انتهى الوقت' : 'حتى الإغلاق'}</small></div><span className="deadline-date">موعد التسليم: {formatDate(assignment.deadlineAt)}</span><small>الخادم وحده يقرر قبول التسليم أو رفضه.</small></div><div className="glass-panel detail-status"><span className="eyebrow">حالة تسليمك</span><StatusPill tone={assignment.submissionStatus === 'REVIEWED' ? 'green' : assignment.submissionStatus === 'SUBMITTED' ? 'cyan' : 'amber'}>{assignment.submissionStatus === 'WAITING' ? 'بانتظار التسليم' : assignment.submissionStatus === 'SUBMITTED' ? 'تم التسليم' : assignment.submissionStatus === 'REVIEWED' ? 'تمت المراجعة' : assignment.submissionStatus === 'MISSING' ? 'لم يتم التسليم' : 'ملغى'}</StatusPill></div></aside></div>}
  </PortalShell>}</Gate>;
}

function NotificationsPage({ role }: { role: 'student' | 'teacher' }) {
  const q = useListNotifications({ query: { queryKey: getListNotificationsQueryKey(), refetchInterval: 60000 } });
  const mark = useMarkNotificationRead();
  const qc = useQueryClient();
  const [permission, setPermission] = useState<string>(
    Capacitor.isNativePlatform() ? 'prompt' : (typeof Notification === 'undefined' ? 'unsupported' : Notification.permission),
  );
  const [permissionMessage, setPermissionMessage] = useState('');
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    void LocalNotifications.checkPermissions().then(status => setPermission(status.display)).catch(() => setPermission('prompt'));
  }, []);
  const enableNotifications = async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        const current = await LocalNotifications.checkPermissions();
        const result = current.display === 'granted' ? current : await LocalNotifications.requestPermissions();
        setPermission(result.display);
        if (result.display === 'granted') {
          await LocalNotifications.createChannel({ id: 'barakat-general', name: 'إشعارات المعهد', description: 'تنبيهات الواجبات وتحديثات المعهد', importance: 5, visibility: 1 });
          setPermissionMessage('تم تفعيل إذن إشعارات النظام. التنبيهات عند إغلاق التطبيق تحتاج ربط Firebase بخادم المعهد.');
        } else {
          setPermissionMessage('لم يُسمح بالإشعارات. افتح إعدادات الهاتف ثم التطبيقات ثم معهد بركات ثم الإشعارات.');
        }
      } catch {
        setPermissionMessage('تعذر طلب الإذن حالياً. راجع إعدادات إشعارات التطبيق من إعدادات الهاتف.');
      }
      return;
    }
    if (typeof Notification === 'undefined') {
      setPermission('unsupported');
      setPermissionMessage('هذا المتصفح لا يدعم إشعارات النظام؛ يبقى مركز الإشعارات داخل الموقع متاحاً.');
      return;
    }
    const result = await Notification.requestPermission();
    setPermission(result);
    setPermissionMessage(
      result === 'granted'
        ? 'ستظهر تنبيهات المتصفح أثناء استخدام الموقع. إشعارات Push عند إغلاقه تحتاج إعداد خدمة خارجية.'
        : 'لم يُسمح بالإشعارات. يمكنك تفعيلها من إعدادات المتصفح، وسيبقى مركز الإشعارات داخل الموقع متاحاً.',
    );
  };
  const title = role === 'teacher' ? 'إشعارات الأستاذ' : 'إشعاراتك';
  return <Gate role={role}>{user => <PortalShell role={role} name={user.displayName}><PageTitle eyebrow="التنبيهات" title={title} detail="تحديثات مرتبطة بواجباتك وتسليماتك." action={permission === 'granted' ? <span className="inline-info notification-permission">{Capacitor.isNativePlatform() ? 'إشعارات الهاتف مفعلة' : 'تنبيهات المتصفح مفعلة أثناء استخدام الموقع'}</span> : <Button variant="outline" onClick={() => void enableNotifications()} testId="button-enable-notifications"><Bell size={15} /> {Capacitor.isNativePlatform() ? 'تفعيل إشعارات الهاتف' : 'تفعيل تنبيهات المتصفح'}</Button>} />
    {permissionMessage && <p className="muted-line" role="status">{permissionMessage}</p>}
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : !q.data?.length ? <EmptyState title="لا توجد إشعارات حالياً" detail="ستظهر الإشعارات هنا عند ورود تحديث جديد." icon={Bell} /> : <div className="notifications-list">{q.data.map(n => <article className={`notification-card glass-panel ${n.readAt ? '' : 'notification-unread'}`} key={n.id} data-testid={`notification-${n.id}`}><span className="notification-icon"><Bell size={18} /></span><div className="notification-copy"><div className="notification-title"><h3>{n.title}</h3>{!n.readAt && <StatusPill tone="cyan">جديد</StatusPill>}</div><p>{n.body}</p><small>{formatDate(n.createdAt)}</small></div><div className="notification-actions">{n.assignmentId && role === 'student' && <Button href={`/student/assignment/${n.assignmentId}`} variant="quiet" testId={`link-notification-assignment-${n.id}`}>فتح الواجب <ArrowLeft size={14} /></Button>}{n.assignmentId && role === 'teacher' && n.type === 'SUBMISSION_RECEIVED' && <Button href={`/teacher/assignments/${n.assignmentId}/monitor`} variant="quiet" testId={`link-notification-monitor-${n.id}`}>عرض التسليمات <ArrowLeft size={14} /></Button>}{!n.readAt && <button className="text-button" disabled={mark.isPending} onClick={() => mark.mutate({ notificationId: n.id }, { onSuccess: () => void Promise.all([qc.invalidateQueries({ queryKey: getListNotificationsQueryKey() }), qc.invalidateQueries({ queryKey: getGetTeacherDashboardQueryKey() })]) })} data-testid={`button-mark-read-${n.id}`}><CheckCheck size={15} /> تحديد كمقروء</button>}</div></article>)}</div>}
  </PortalShell>}</Gate>;
}

function notificationNumericId(value: string) {
  let hash = 0;
  for (let i = 0; i < value.length; i++) hash = (Math.imul(hash, 31) + value.charCodeAt(i)) | 0;
  return (hash & 0x7fffffff) || 1;
}

function BrowserNotificationBridge() {
  const q = useListNotifications({
    query: {
      queryKey: getListNotificationsQueryKey(),
      refetchInterval: 60000,
    },
  });
  const seen = useRef(new Set<string>());
  const initialLoad = useRef(true);

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    let disposed = false;
    let listener: { remove: () => Promise<void> } | undefined;
    void LocalNotifications.addListener('localNotificationActionPerformed', action => {
      const target = action.notification.extra?.url;
      if (typeof target === 'string' && target.startsWith('/')) window.location.assign(basePath + target);
    }).then(handle => {
      if (disposed) void handle.remove();
      else listener = handle;
    }).catch(() => {});
    return () => {
      disposed = true;
      if (listener) void listener.remove();
    };
  }, []);

  useEffect(() => {
    if (!q.data) return;
    if (initialLoad.current) {
      q.data.forEach((item) => seen.current.add(item.id));
      initialLoad.current = false;
      return;
    }
    for (const item of q.data) {
      if (seen.current.has(item.id)) continue;
      seen.current.add(item.id);
      if (item.readAt) continue;
      const targetUrl = item.assignmentId ? '/student/assignment/' + item.assignmentId : '/';
      if (Capacitor.isNativePlatform()) {
        void LocalNotifications.checkPermissions().then(status => {
          if (status.display !== 'granted') return;
          return LocalNotifications.schedule({ notifications: [{
            id: notificationNumericId(item.id),
            title: item.title,
            body: item.body,
            schedule: { at: new Date(Date.now() + 1000) },
            channelId: 'barakat-general',
            extra: { url: targetUrl },
          }] });
        }).catch(() => {});
        continue;
      }
      if (typeof Notification === 'undefined' || Notification.permission !== 'granted') continue;
      const options: NotificationOptions = {
        body: item.body,
        tag: item.id,
        icon: basePath + '/logo.svg',
        data: { url: targetUrl },
      };
      void navigator.serviceWorker?.ready
        .then((registration) => registration.showNotification(item.title, options))
        .catch(() => {
          const notification = new Notification(item.title, options);
          notification.onclick = () => { window.location.assign(options.data?.url ?? '/'); };
        });
    }
  }, [q.data]);
  return null;
}

function TeacherDashboard({ user }: { user: { displayName: string } }) {
  const q = useGetTeacherDashboard({ query: { queryKey: getGetTeacherDashboardQueryKey() } });
  const assignments = useListTeacherAssignments({ query: { queryKey: getListTeacherAssignmentsQueryKey() } });
  const metrics = q.data ? [
    { label: 'الطلاب المقبولون', value: q.data.acceptedStudents, icon: Users, tone: 'violet' },
    { label: 'طلبات الانضمام', value: q.data.pendingRequests, icon: Activity, tone: 'amber' },
    { label: 'واجبات منشورة', value: q.data.publishedAssignments, icon: BookOpen, tone: 'cyan' },
    { label: 'تسليمات بانتظار المراجعة', value: q.data.openSubmissions, icon: ClipboardList, tone: 'green' },
  ] : [];
  return <PortalShell role="teacher" name={user.displayName}><div className="welcome-band teacher-welcome"><div><span className="eyebrow">لوحة المتابعة</span><h1>مرحباً، {user.displayName}</h1><p>إدارة الواجبات ومراجعة تسليمات الطلاب من هنا.</p></div><Button href="/teacher/assignments/new" testId="link-create-assignment"><Plus size={17} /> إنشاء واجب</Button></div>
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : <div className="metric-grid">{metrics.map(m => <div className="metric-card glass-panel" key={m.label} data-testid={`metric-${m.label}`}><span className={`metric-icon metric-${m.tone}`}><m.icon /></span><div><small>{m.label}</small><b>{m.value}</b></div></div>)}</div>}
    <div className="content-section"><div className="section-title-row"><div><span className="eyebrow">المتابعة الأكاديمية</span><h2>الواجبات الأخيرة</h2></div><Link href="/teacher/assignments" className="text-link" data-testid="link-teacher-assignments">كل الواجبات <ArrowLeft size={15} /></Link></div>{assignments.isLoading ? <Loading /> : assignments.isError ? <ErrorState onRetry={() => void assignments.refetch()} /> : !assignments.data?.length ? <EmptyState title="لا توجد واجبات بعد" detail="أنشئ أول واجب ليظهر هنا." icon={ClipboardList} /> : <div className="table-wrap"><table className="data-table"><thead><tr><th>الواجب</th><th>الحالة</th><th>التسليم</th><th>الموعد</th><th></th></tr></thead><tbody>{assignments.data.slice(0, 5).map(a => <tr key={a.id} data-testid={`row-assignment-${a.id}`}><td><b>{a.title}</b><small>{a.chapter}</small></td><td><StatusPill tone={a.status === 'OPEN' ? 'cyan' : a.status === 'DRAFT' ? 'amber' : 'neutral'}>{statusAssignment(a.status)}</StatusPill></td><td>{a.submittedCount} / {a.targetCount}</td><td>{formatDate(a.deadlineAt)}</td><td><Link href={`/teacher/assignments/${a.id}/monitor`} className="text-link" data-testid={`link-monitor-${a.id}`}>متابعة <ArrowLeft size={14} /></Link></td></tr>)}</tbody></table></div>}</div>
  </PortalShell>;
}
function statusAssignment(s: string) { return s === 'DRAFT' ? 'مسودة' : s === 'OPEN' ? 'مفتوح' : s === 'CLOSED' ? 'مغلق' : 'ملغى'; }

function TeacherAssignments() {
  const q = useListTeacherAssignments({ query: { queryKey: getListTeacherAssignmentsQueryKey() } });
  const publish = usePublishTeacherAssignment();
  const cancel = useCancelTeacherAssignment();
  const extend = useExtendAssignmentDeadline();
  const qc = useQueryClient();
  const refresh = () => Promise.all([qc.invalidateQueries({ queryKey: getListTeacherAssignmentsQueryKey() }), qc.invalidateQueries({ queryKey: getGetTeacherDashboardQueryKey() })]);
  const [extendId, setExtendId] = useState('');
  const [deadline, setDeadline] = useState('');
  const [reason, setReason] = useState('');
  const perform = (mutation: typeof publish | typeof cancel | typeof extend, args: any) => mutation.mutate(args, { onSuccess: () => { void refresh(); setExtendId(''); } });
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}><PageTitle eyebrow="إدارة المحتوى" title="الواجبات" detail="إنشاء الواجبات ونشرها ومتابعة مواعيد التسليم." action={<Button href="/teacher/assignments/new" testId="link-new-assignment"><Plus size={17} /> واجب جديد</Button>} />
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : !q.data?.length ? <EmptyState title="لا توجد واجبات مسجلة" detail="أنشئ واجباً جديداً لبدء متابعة التسليمات." icon={ClipboardList} /> : <div className="assignment-list teacher-assignment-list">{q.data.map(a => <article className="teacher-assignment-card glass-panel" key={a.id} data-testid={`teacher-assignment-${a.id}`}><div className="teacher-assignment-head"><span className="assignment-icon"><FileText /></span><div className="assignment-info"><b>{a.title}</b><small>{a.chapter} <i>·</i> {a.durationMinutes} دقيقة</small></div><StatusPill tone={a.status === 'OPEN' ? 'cyan' : a.status === 'DRAFT' ? 'amber' : 'neutral'}>{statusAssignment(a.status)}</StatusPill></div><p>{a.instructions || 'لا توجد تعليمات إضافية.'}</p><div className="assignment-stats"><span><Users size={15} /> المستهدفون: {a.targetCount}</span><span><CheckCircle2 size={15} /> تم التسليم: {a.submittedCount}</span><span><Clock3 size={15} /> بانتظار: {a.waitingCount}</span><span><CalendarClock size={15} /> {formatDate(a.deadlineAt)}</span></div><div className="card-actions"><Button href={`/teacher/assignments/${a.id}/monitor`} variant="outline" testId={`link-open-monitor-${a.id}`}>متابعة الطلاب <ArrowLeft size={15} /></Button>{a.status === 'DRAFT' && <Button onClick={() => { if (window.confirm('هل تريد نشر هذا الواجب وبدء المهلة؟')) perform(publish, { assignmentId: a.id }); }} disabled={publish.isPending} testId={`button-publish-${a.id}`}>نشر الواجب</Button>}{a.status === 'OPEN' && <><button className="text-button" onClick={() => { setExtendId(extendId === a.id ? '' : a.id); setDeadline(''); setReason(''); }} data-testid={`button-extend-${a.id}`}><CalendarClock size={15} /> تمديد المهلة</button><button className="text-button danger-link" onClick={() => { if (window.confirm('هل تريد إلغاء هذا الواجب؟')) perform(cancel, { assignmentId: a.id }); }} data-testid={`button-cancel-${a.id}`}><X size={15} /> إلغاء</button></>}</div>{extendId === a.id && <form className="extend-form" onSubmit={e => { e.preventDefault(); perform(extend, { assignmentId: a.id, data: { deadlineAt: new Date(deadline).toISOString(), reason: reason.trim() } }); }}><Field label="الموعد الجديد"><TextInput type="datetime-local" required value={deadline} onChange={e => setDeadline(e.target.value)} data-testid={`input-deadline-${a.id}`} /></Field><Field label="سبب التمديد"><TextInput minLength={3} maxLength={1000} required value={reason} onChange={e => setReason(e.target.value)} data-testid={`input-reason-${a.id}`} /></Field><Button type="submit" disabled={extend.isPending} testId={`button-save-extension-${a.id}`}>حفظ الموعد</Button></form>}{(publish.isError || extend.isError || cancel.isError) && <p className="inline-error" role="alert">{errorMessage(publish.error ?? extend.error ?? cancel.error)}</p>}</article>)}</div>}
  </PortalShell>}</Gate>;
}

function NewAssignment() {
  const [, setLocation] = useLocation();
  const create = useCreateTeacherAssignment();
  const publish = usePublishTeacherAssignment();
  const students = useListTeacherStudents({ query: { queryKey: getListTeacherStudentsQueryKey() } });
  const uploadUrl = useRequestPrivateUploadUrl();
  const qc = useQueryClient();
  const [title, setTitle] = useState(''); const [chapter, setChapter] = useState(''); const [instructions, setInstructions] = useState('');
  const [minutes, setMinutes] = useState(50); const [targets, setTargets] = useState<string[]>([]); const [files, setFiles] = useState<File[]>([]);
  const [saveError, setSaveError] = useState(''); const [busy, setBusy] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0); const [uploadStatus, setUploadStatus] = useState(''); const [savedDraftId, setSavedDraftId] = useState('');
  const createAssignment = async (publishAfter: boolean) => {
    if (!title.trim() || !chapter.trim()) return;
    setBusy(true); setSaveError(''); setUploadProgress(0); setUploadStatus(files.length ? 'تهيئة رفع الملفات' : 'حفظ الواجب');
    let assignmentId = savedDraftId;
    try {
      if (!assignmentId) {
        const attachments: AttachmentInput[] = [];
        const totalSize = files.reduce((sum, file) => sum + file.size, 0);
        let uploadedSize = 0;
        for (let i = 0; i < files.length; i++) {
          const f = files[i];
          const url = await uploadUrl.mutateAsync({ data: { filename: f.name, contentType: f.type, sizeBytes: f.size, purpose: 'ASSIGNMENT', assignmentId: null } });
          setUploadStatus(`رفع ${f.name}`);
          await new Promise<void>((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('PUT', url.uploadUrl);
            xhr.setRequestHeader('Content-Type', f.type);
            xhr.upload.onprogress = event => {
              if (event.lengthComputable && totalSize > 0) {
                setUploadProgress(Math.min(100, Math.floor(((uploadedSize + event.loaded) / totalSize) * 100)));
              }
            };
            xhr.onload = () => xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`فشل رفع ${f.name}`));
            xhr.onerror = () => reject(new Error(`تعذر رفع ${f.name}; تحقق من الاتصال ثم أعد المحاولة.`));
            xhr.send(f);
          });
          uploadedSize += f.size;
          setUploadProgress(totalSize ? Math.floor((uploadedSize / totalSize) * 100) : 100);
          attachments.push({ objectPath: url.objectPath, filename: f.name, contentType: f.type, sizeBytes: f.size, sortOrder: i });
        }
        setUploadStatus('حفظ المسودة على الخادم');
        const result = await create.mutateAsync({ data: { title: title.trim(), chapter: chapter.trim(), instructions: instructions.trim(), durationMinutes: Number(minutes), targetStudentIds: targets, attachmentPaths: attachments } });
        assignmentId = result.id;
        setSavedDraftId(result.id);
      }
      if (publishAfter) {
        setUploadStatus('نشر الواجب وبدء المهلة من توقيت الخادم');
        await publish.mutateAsync({ assignmentId });
      }
      await Promise.all([qc.invalidateQueries({ queryKey: getListTeacherAssignmentsQueryKey() }), qc.invalidateQueries({ queryKey: getGetTeacherDashboardQueryKey() })]);
      setLocation('/teacher/assignments');
    } catch (e) {
      setSaveError(assignmentId
        ? `حُفظت المسودة، لكن لم يتأكد النشر. أعد المحاولة لنشر المسودة نفسها دون إنشاء نسخة جديدة. ${errorMessage(e)}`
        : errorMessage(e));
      setBusy(false);
    }
  };
  const accepted = students.data?.students.filter(s => s.status === 'ACCEPTED') ?? [];
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}><PageTitle eyebrow="إدارة الواجبات" title="إنشاء واجب" detail="أدخل التفاصيل، ثم احفظ كمسودة أو انشر لبدء المهلة." action={<Button href="/teacher/assignments" variant="quiet" testId="link-cancel-create"><ArrowRight size={16} /> العودة</Button>} />
     <div className="form-layout"><form className="glass-panel assignment-form" onSubmit={e => { e.preventDefault(); void createAssignment(false); }}><Field label="عنوان الواجب"><TextInput required maxLength={160} value={title} onChange={e => setTitle(e.target.value)} placeholder="مثال: مسائل الفصل" data-testid="input-assignment-title" /></Field><Field label="الفصل أو الموضوع"><TextInput required maxLength={160} value={chapter} onChange={e => setChapter(e.target.value)} placeholder="موضوع الكيمياء" data-testid="input-assignment-chapter" /></Field><Field label="تعليمات الواجب"><TextArea maxLength={10000} rows={5} value={instructions} onChange={e => setInstructions(e.target.value)} placeholder="اكتب تفاصيل الحل المطلوبة..." data-testid="input-assignment-instructions" /></Field><div className="form-columns"><Field label="مدة التسليم بالدقائق"><TextInput type="number" min={1} max={1440} required value={minutes} onChange={e => setMinutes(Number(e.target.value))} data-testid="input-assignment-duration" /></Field><div className="field"><span>المستهدفون</span>{students.isLoading ? <div className="skeleton skeleton-copy" /> : students.isError ? <ErrorState onRetry={() => void students.refetch()} /> : accepted.length === 0 ? <p className="muted-line">لا يوجد طلاب مقبولون حالياً. اقبل طلبات الانضمام قبل توجيه الواجب.</p> : <div className="target-actions"><button type="button" className="text-button" onClick={() => setTargets(targets.length === accepted.length ? [] : accepted.map(s => s.id))} data-testid="button-select-all-students">{targets.length === accepted.length ? 'إلغاء تحديد الكل' : 'اختيار جميع الطلاب المقبولين'}</button><small>{targets.length} طالباً مستهدفاً</small><div className="target-list">{accepted.map(s => <label key={s.id} className="target-row"><input type="checkbox" checked={targets.includes(s.id)} onChange={e => setTargets(e.target.checked ? [...targets, s.id] : targets.filter(id => id !== s.id))} data-testid={`checkbox-target-${s.id}`} /><span>{s.displayName}</span><small>{s.email}</small></label>)}</div></div>}</div></div><Field label="ملفات السؤال" hint="اختياري · صور وPDF حتى 10 ميغابايت"><UploadQueue files={files} setFiles={setFiles} disabled={busy} /></Field>
      <div className="form-actions"><Button type="submit" disabled={busy || !title.trim() || !chapter.trim()} variant="outline" testId="button-save-draft">{busy ? <><LoaderCircle className="spin" /> جارٍ الحفظ</> : 'حفظ كمسودة'}</Button><Button onClick={() => void createAssignment(true)} disabled={busy || !title.trim() || !chapter.trim() || targets.length === 0} testId="button-publish-assignment">{busy ? <><LoaderCircle className="spin" /> جارٍ النشر</> : <><Send size={16} /> نشر الواجب</>}</Button></div>
       {busy && <div className="upload-progress" role="status"><span>{uploadStatus}</span>{files.length > 0 && <><progress max={100} value={uploadProgress} /><b>{uploadProgress}%</b></>}</div>}{saveError && <p className="inline-error" role="alert">{saveError}</p>}
     </form><aside className="glass-panel summary-panel"><span className="eyebrow">مراجعة قبل الحفظ</span><h2>{title || 'عنوان الواجب'}</h2><p>{chapter || 'الفصل أو الموضوع'}</p><div className="summary-line"><span>المدة</span><b>{minutes || 0} دقيقة</b></div><div className="summary-line"><span>الطلاب المستهدفون</span><b>{targets.length}</b></div><div className="summary-line"><span>ملفات السؤال</span><b>{files.length}</b></div><p className="muted-line"><ShieldCheck size={15} /> تبدأ المهلة بعد تأكيد النشر من الخادم.</p></aside></div>
  </PortalShell>}</Gate>;
}

function MonitorPage() {
  const { assignmentId = '' } = useParams<{ assignmentId: string }>();
  const q = useGetAssignmentMonitor(assignmentId, { query: { queryKey: getGetAssignmentMonitorQueryKey(assignmentId), enabled: !!assignmentId, refetchInterval: 12000, refetchIntervalInBackground: false } });
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}>{q.isLoading ? <Loading /> : q.isError || !q.data ? <ErrorState onRetry={() => void q.refetch()} /> : <><PageTitle eyebrow="متابعة الواجب" title={q.data.assignment.title} detail={q.data.assignment.chapter} action={<Button href="/teacher/assignments" variant="quiet" testId="link-back-assignments"><ArrowRight size={16} /> قائمة الواجبات</Button>} /><div className="monitor-summary"><div><span>الطلاب المستهدفون</span><b>{q.data.assignment.targetCount}</b></div><div><span>تم التسليم</span><b>{q.data.assignment.submittedCount}</b></div><div><span>بانتظار التسليم</span><b>{q.data.assignment.waitingCount}</b></div><div><span>لم يسلّموا</span><b>{q.data.assignment.missingCount}</b></div></div>{!q.data.students.length ? <EmptyState title="لا توجد أسماء مستهدفة لهذا الواجب" detail="قائمة الطلاب المستهدفين خالية." icon={Users} /> : <div className="table-wrap monitor-table"><table className="data-table"><thead><tr><th>الطالب</th><th>البريد الإلكتروني</th><th>الحالة</th><th>وقت التسليم</th><th>الحل</th></tr></thead><tbody>{q.data.students.map(s => <tr key={s.studentId} data-testid={`row-monitor-${s.studentId}`}><td><b>{s.displayName}</b></td><td>{s.email}</td><td><StatusPill tone={s.status === 'REVIEWED' ? 'green' : s.status === 'SUBMITTED' ? 'cyan' : s.status === 'MISSING' ? 'red' : 'amber'}>{s.status === 'WAITING' ? 'بانتظار' : s.status === 'SUBMITTED' ? 'تم التسليم' : s.status === 'REVIEWED' ? 'تمت المراجعة' : s.status === 'MISSING' ? 'لم يسلّم' : 'ملغى'}</StatusPill></td><td>{formatDate(s.submittedAt)}</td><td>{s.submissionId ? <Link href={`/teacher/submissions/${s.submissionId}/review`} className="text-link" data-testid={`link-review-${s.submissionId}`}>فتح الحل <ArrowLeft size={14} /></Link> : '—'}</td></tr>)}</tbody></table></div>}</>}</PortalShell>}</Gate>;
}

function ReviewPage() {
  const { submissionId = '' } = useParams<{ submissionId: string }>();
  const q = useGetTeacherSubmission(submissionId, { query: { queryKey: getGetTeacherSubmissionQueryKey(submissionId), enabled: !!submissionId } });
  const save = useSaveTeacherReview();
  const qc = useQueryClient();
  const [note, setNote] = useState<string | null>(null);
  const s = q.data; const reviewText = note ?? s?.reviewNote ?? '';
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}>{q.isLoading ? <Loading /> : q.isError || !s ? <ErrorState onRetry={() => void q.refetch()} /> : <><PageTitle eyebrow="مراجعة التسليم" title={s.assignmentTitle} detail={`${s.studentName} · ${formatDate(s.submittedAt)}`} action={<Button href={`/teacher/assignments/${s.assignmentId}/monitor`} variant="quiet" testId="link-back-monitor"><ArrowRight size={16} /> متابعة الطلاب</Button>} /><div className="review-layout"><section className="glass-panel review-files"><div className="section-title-row"><div><span className="eyebrow">المرفقات</span><h2>حل الطالب</h2></div><StatusPill tone={s.status === 'REVIEWED' ? 'green' : 'cyan'}>{s.status === 'REVIEWED' ? 'تمت المراجعة' : 'بانتظار المراجعة'}</StatusPill></div>{s.attachments.length === 0 ? <EmptyState title="لا توجد مرفقات" /> : <div className="review-attachment-list">{s.attachments.map((a, i) => <a href={a.viewUrl ?? undefined} target="_blank" rel="noreferrer" key={a.objectPath} className={`review-attachment ${!a.viewUrl ? 'attachment-disabled' : ''}`} data-testid={`link-submission-attachment-${i}`}>{a.contentType.startsWith('image/') && a.viewUrl ? <img src={a.viewUrl} alt={a.filename} /> : <span className="review-file-icon">{a.contentType.startsWith('image/') ? <FileImage /> : <FileText />}</span>}<span>{a.filename}</span><ExternalLink size={15} /></a>)}</div>}</section><form className="glass-panel review-form" onSubmit={e => { e.preventDefault(); save.mutate({ submissionId, data: { note: reviewText } }, { onSuccess: () => { void qc.invalidateQueries({ queryKey: getGetTeacherSubmissionQueryKey(submissionId) }); void qc.invalidateQueries({ queryKey: getGetAssignmentMonitorQueryKey(s.assignmentId) }); void qc.invalidateQueries({ queryKey: getGetTeacherDashboardQueryKey() }); setNote(null); } }); }}><span className="eyebrow">ملاحظة المراجعة</span><h2>اكتب ملاحظاتك</h2><TextArea rows={9} maxLength={5000} value={reviewText} onChange={e => setNote(e.target.value)} placeholder="ملاحظات واضحة ومباشرة للطالب..." data-testid="input-review-note" /><small className="muted-line">تظهر الملاحظة للطالب بعد الحفظ.</small>{save.isError && <p className="inline-error" role="alert">{errorMessage(save.error)}</p>}{save.isSuccess && <p className="inline-success" role="status">تم حفظ المراجعة من الخادم.</p>}<Button type="submit" disabled={save.isPending} testId="button-save-review">{save.isPending ? <><LoaderCircle className="spin" /> جارٍ الحفظ</> : <><Check size={16} /> حفظ المراجعة</>}</Button></form></div></>}</PortalShell>}</Gate>;
}

function TeacherSubmissions() {
  const q = useListTeacherAssignments({ query: { queryKey: getListTeacherAssignmentsQueryKey(), refetchInterval: 30000 } });
  const submittedAssignments = q.data?.filter(assignment => assignment.submittedCount > 0) ?? [];
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}>
    <PageTitle eyebrow="متابعة الحلول" title="التسليمات" detail="اختر واجباً لعرض الطلاب الذين سلّموا وفتح الحلول للمراجعة." />
    {q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : submittedAssignments.length === 0
      ? <EmptyState title="لا توجد تسليمات بعد" detail={q.data?.length ? 'ستظهر الواجبات هنا عند وصول أول تسليم.' : 'أنشئ واجباً وانشره ليتمكن الطلاب من التسليم.'} icon={FileText} />
      : <div className="assignment-list">{submittedAssignments.map(assignment => <article className="teacher-assignment-card glass-panel submission-summary-card" key={assignment.id} data-testid={`teacher-submission-assignment-${assignment.id}`}>
        <div className="teacher-assignment-head"><span className="assignment-icon"><FileText /></span><div className="assignment-info"><b>{assignment.title}</b><small>{assignment.chapter}</small></div><StatusPill tone={assignment.status === 'OPEN' ? 'cyan' : 'neutral'}>{statusAssignment(assignment.status)}</StatusPill></div>
        <div className="assignment-stats"><span><CheckCircle2 size={15} /> التسليمات: {assignment.submittedCount} / {assignment.targetCount}</span><span><CalendarClock size={15} /> {formatDate(assignment.deadlineAt)}</span></div>
        <div className="card-actions"><Button href={`/teacher/assignments/${assignment.id}/monitor`} variant="outline" testId={`link-review-assignment-${assignment.id}`}>عرض الطلاب ومراجعة الحلول <ArrowLeft size={15} /></Button></div>
      </article>)}</div>}
  </PortalShell>}</Gate>;
}

function TeacherStudents() {
  const q = useListTeacherStudents({ query: { queryKey: getListTeacherStudentsQueryKey() } });
  const update = useUpdateStudentStatus(); const createCode = useCreateEnrollmentCode(); const revoke = useRevokeEnrollmentCode(); const qc = useQueryClient();
  const [maxUses, setMaxUses] = useState(1); const [copied, setCopied] = useState(''); const [newCode, setNewCode] = useState('');
  const refresh = () => Promise.all([qc.invalidateQueries({ queryKey: getListTeacherStudentsQueryKey() }), qc.invalidateQueries({ queryKey: getGetTeacherDashboardQueryKey() })]);
  const act = (studentId: string, status: 'ACCEPTED' | 'REJECTED' | 'SUSPENDED') => update.mutate({ studentId, data: { status } }, { onSuccess: () => void refresh() });
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}><PageTitle eyebrow="إدارة الوصول" title="الطلاب وطلبات الانضمام" detail="اقبل طلبات الطلاب وأدر رموز الانضمام." />
    {q.isLoading ? <Loading /> : q.isError || !q.data ? <ErrorState onRetry={() => void q.refetch()} /> : <>
      <section className="content-section"><div className="section-title-row"><div><span className="eyebrow">طلبات الوصول</span><h2>طلبات الانضمام <span className="count-badge">{q.data.requests.length}</span></h2></div></div>{q.data.requests.length === 0 ? <EmptyState title="لا توجد طلبات انضمام" detail="ستظهر هنا الطلبات الجديدة من الطلاب." icon={Users} /> : <div className="student-list">{q.data.requests.map(s => <article className="student-row glass-panel" key={s.id} data-testid={`row-enrollment-${s.id}`}><span className="user-avatar">{s.displayName.slice(0, 1) || 'ط'}</span><div className="student-details"><b>{s.displayName}</b><small>{s.email} · {formatDate(s.joinedAt)}</small></div><StatusPill tone={s.status === 'PENDING' ? 'amber' : s.status === 'ACCEPTED' ? 'green' : 'neutral'}>{s.status === 'PENDING' ? 'بانتظار الموافقة' : s.status}</StatusPill><div className="student-actions">{s.status === 'PENDING' && <><button className="text-button success-link" onClick={() => act(s.id, 'ACCEPTED')} disabled={update.isPending} data-testid={`button-accept-${s.id}`}><Check size={15} /> قبول</button><button className="text-button danger-link" onClick={() => act(s.id, 'REJECTED')} disabled={update.isPending} data-testid={`button-reject-${s.id}`}><X size={15} /> رفض</button></>}{(s.status === 'ACCEPTED' || s.status === 'SUSPENDED') && <button className="text-button" onClick={() => act(s.id, s.status === 'ACCEPTED' ? 'SUSPENDED' : 'ACCEPTED')} disabled={update.isPending} data-testid={`button-toggle-student-${s.id}`}>{s.status === 'ACCEPTED' ? 'إيقاف' : 'إعادة تفعيل'}</button>}</div></article>)}</div>}{update.isError && <p className="inline-error" role="alert">{errorMessage(update.error)}</p>}</section>
      <section className="content-section"><div className="section-title-row"><div><span className="eyebrow">الوصول للمعهد</span><h2>رموز الانضمام</h2></div><form className="code-create" onSubmit={e => { e.preventDefault(); createCode.mutate({ data: { maxUses: Number(maxUses) } }, { onSuccess: created => { setNewCode(created.code ?? ''); setCopied(''); void refresh(); } }); }}><TextInput type="number" min={1} max={500} value={maxUses} onChange={e => setMaxUses(Number(e.target.value))} aria-label="عدد الاستخدامات" data-testid="input-code-uses" /><Button type="submit" disabled={createCode.isPending} testId="button-create-code"><Plus size={15} /> إنشاء رمز</Button></form></div>{createCode.isError && <p className="inline-error">{errorMessage(createCode.error)}</p>}{newCode && <div className="one-time-code glass-panel" role="status" data-testid="status-new-enrollment-code"><div><span className="eyebrow">رمز جديد — يظهر الآن مرة واحدة</span><code>{newCode}</code><small>انسخه وشاركه مع الطلاب. لا يحفظ الموقع الرمز بصيغته المقروءة.</small></div><button className="button button-outline" onClick={() => { if (navigator.clipboard) void navigator.clipboard.writeText(newCode).then(() => setCopied('new')).catch(() => setCopied('')); }} data-testid="button-copy-new-code">{copied === 'new' ? <Check size={15} /> : <Copy size={15} />}{copied === 'new' ? 'نُسخ' : 'نسخ الرمز'}</button><button className="icon-button" onClick={() => setNewCode('')} aria-label="إخفاء الرمز" data-testid="button-hide-new-code"><X size={16} /></button></div>}{q.data.activeCodes.length === 0 ? <EmptyState title="لا توجد رموز نشطة" detail="أنشئ رمزاً وشاركه مع الطلاب الذين تريد دعوتهم." icon={ShieldCheck} /> : <div className="codes-list">{q.data.activeCodes.map(code => <div className="code-row glass-panel" key={code.id} data-testid={`row-code-${code.id}`}><span className="masked-code">الرمز مخفي بعد الإنشاء</span><span>الاستخدامات: {code.usedCount} / {code.maxUses}</span><span>ينتهي: {formatDate(code.expiresAt)}</span><button className="text-button danger-link" onClick={() => revoke.mutate({ codeId: code.id }, { onSuccess: () => void refresh() })} disabled={revoke.isPending} data-testid={`button-revoke-code-${code.id}`}><Trash2 size={15} /> إلغاء</button></div>)}</div>}</section>
      <section className="content-section"><div className="section-title-row"><div><span className="eyebrow">قائمة المعهد</span><h2>الطلاب المقبولون</h2></div></div>{q.data.students.length === 0 ? <EmptyState title="لا يوجد طلاب مقبولون بعد" detail="بعد قبول طلب الطالب سيظهر هنا." icon={Users} /> : <div className="student-list">{q.data.students.map(s => <article className="student-row glass-panel" key={s.id} data-testid={`row-student-${s.id}`}><span className="user-avatar">{s.displayName.slice(0, 1) || 'ط'}</span><div className="student-details"><b>{s.displayName}</b><small>{s.email} · انضم {formatDate(s.joinedAt)}</small></div><StatusPill tone={s.status === 'ACCEPTED' ? 'green' : 'amber'}>{s.status === 'ACCEPTED' ? 'مقبول' : s.status === 'PENDING' ? 'بانتظار الموافقة' : s.status === 'REJECTED' ? 'مرفوض' : 'موقوف'}</StatusPill><button className="text-button danger-link" onClick={() => act(s.id, 'SUSPENDED')} disabled={update.isPending} data-testid={`button-suspend-${s.id}`}><ShieldCheck size={15} /> إيقاف</button></article>)}</div>}</section>
    </>}
  </PortalShell>}</Gate>;
}

function TeacherSettings() {
  const q = useGetAiSettings({ query: { queryKey: getGetAiSettingsQueryKey() } }); const test = useTestAiConnection(); const qc = useQueryClient();
  return <Gate role="teacher">{user => <PortalShell role="teacher" name={user.displayName}><PageTitle eyebrow="إعدادات المعهد" title="إعداد الذكاء الاصطناعي" detail="يعرض هذا القسم حالة إعداد المزود فقط. لا تُدخل مفاتيح سرية في الواجهة." />
    <div className="ai-settings-layout"><section className="glass-panel ai-status"><span className="ai-emblem"><Sparkles /></span><span className="eyebrow">إعداد الخادم</span><h2>{q.data?.configured ? 'المزود مُعدّ' : 'لم يتم إعداد مزود'}</h2>{q.isLoading ? <Loading /> : q.isError ? <ErrorState onRetry={() => void q.refetch()} /> : <><p>{q.data?.message}</p><div className="ai-facts"><div><span>المزود</span><b>{q.data?.provider || 'غير محدد'}</b></div><div><span>النموذج</span><b>{q.data?.model || 'غير محدد'}</b></div><div><span>مصدر المفتاح</span><b>{q.data?.keySource || 'غير معروف'}</b></div></div><div className="secret-instructions"><ShieldCheck /><p>أضف مفتاح المزود إلى <b>Replit Secrets</b> في إعدادات المشروع. المفتاح لا يُعرض ولا يُرسل من المتصفح.</p></div><Button onClick={() => test.mutate(undefined, { onSuccess: () => void qc.invalidateQueries({ queryKey: getGetAiSettingsQueryKey() }) })} disabled={!q.data?.configured || test.isPending} testId="button-test-ai">{test.isPending ? <><LoaderCircle className="spin" /> جارٍ الاختبار</> : <><Activity size={16} /> اختبار اتصال الخادم</>}</Button>{test.isError && <p className="inline-error" role="alert">{errorMessage(test.error)}</p>}{test.data && <div className={test.data.success ? 'inline-success test-result' : 'inline-error test-result'} role="status" data-testid="status-ai-test-result"><b>{test.data.success ? 'نجح اختبار الاتصال' : 'لم ينجح الاتصال'}</b><span>{test.data.message}</span><small>{test.data.provider} · {test.data.model}</small></div>}</>}</section><aside className="glass-panel ai-note"><span className="note-icon"><ShieldCheck /></span><h3>مفاتيح آمنة</h3><p>لا توجد حقول إدخال لمفاتيح API هنا. تتم إدارة الأسرار والتحقق من الاتصال من الخادم.</p><div className="shine-line" /><p>هذه الشاشة تعرض نتيجة الاختبار الفعلية التي يعيدها الخادم فقط؛ لا توفر إجابات مولدة للطلاب.</p></aside></div>
  </PortalShell>}</Gate>;
}

function TeacherSetup() {
  const q = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } }); const setup = useSetupFirstTeacher(); const qc = useQueryClient(); const [token, setToken] = useState('');
  if (q.isLoading) return <div className="app-shell gated" dir="rtl"><Loading /></div>;
  if (q.isError || !q.data) return <div className="app-shell gated" dir="rtl"><ErrorState onRetry={() => void q.refetch()} message="سجّل الدخول بحساب الأستاذ أولاً لإكمال الإعداد المحمي." /></div>;
  if (q.data.teacherConfigured) return <Redirect to={q.data.role === 'TEACHER' ? '/teacher/dashboard' : q.data.enrollmentStatus === 'ACCEPTED' ? '/student' : '/student/enrollment'} />;
  return <div className="app-shell enrollment-page" dir="rtl"><div className="enrollment-top"><Brand /><UserMenu name={q.data.displayName} /></div><form className="glass-panel setup-card" onSubmit={e => { e.preventDefault(); setup.mutate({ data: { setupToken: token } }, { onSuccess: () => { void qc.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); } }); }}><span className="enrollment-emblem"><ShieldCheck /></span><span className="eyebrow">إعداد محمي</span><h1>إعداد حساب الأستاذ</h1><p>هذه الخطوة متاحة فقط عند تهيئة حساب الأستاذ لأول مرة. استخدم رمز الإعداد الآمن من Replit Secrets.</p><Field label="رمز الإعداد"><TextInput type="password" required minLength={24} value={token} onChange={e => setToken(e.target.value)} data-testid="input-teacher-setup-token" /></Field>{setup.isError && <p className="inline-error" role="alert">{errorMessage(setup.error)}</p>}<Button type="submit" disabled={setup.isPending || token.length < 24} testId="button-setup-teacher">{setup.isPending ? <><LoaderCircle className="spin" /> جارٍ الإعداد</> : 'تأكيد إعداد الحساب'}</Button></form></div>;
}

function AuthenticatedRoot() {
  const { data: user, isLoading, isError, refetch } = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey(), retry: false } });
  if (isLoading) return <div className="app-shell portal-loading" dir="rtl"><Loading /></div>;
  if (isError || !user) return <main className="app-shell gated" dir="rtl"><div className="glass-panel gated-card"><CircleAlert /><h1>تعذر تحميل حسابك</h1><p>تعذر قراءة دور الحساب من الخادم. لم نغيّر حالة الدخول أو الصلاحيات.</p><Button onClick={() => void refetch()} testId="button-root-profile-retry">إعادة المحاولة</Button></div></main>;
  if (user.role === 'TEACHER') return <Redirect to={user.teacherConfigured ? '/teacher/dashboard' : '/teacher/setup'} />;
  return <Redirect to={user.enrollmentStatus === 'ACCEPTED' ? '/student' : '/student/enrollment'} />;
}
function RootRedirect() {
  return <><Show when="signed-in"><AuthenticatedRoot /></Show><Show when="signed-out"><Home /></Show></>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={RootRedirect} />
    <Route path="/sign-in/*?" component={() => <AuthPage />} />
    <Route path="/sign-up/*?" component={() => <AuthPage signUp />} />
    <Route path="/student/enrollment" component={() => <SignedInRoute><Enrollment /></SignedInRoute>} />
    <Route path="/student/assignments" component={() => <SignedInRoute><StudentAssignments /></SignedInRoute>} />
    <Route path="/student/submissions" component={() => <SignedInRoute><StudentSubmissions /></SignedInRoute>} />
    <Route path="/student/profile" component={() => <SignedInRoute><StudentProfile /></SignedInRoute>} />
    <Route path="/student" component={() => <SignedInRoute><Gate role="student">{u => <StudentHome user={u} />}</Gate></SignedInRoute>} />
    <Route path="/student/assignment/:assignmentId" component={() => <SignedInRoute><Gate role="student">{() => <StudentAssignmentPage />}</Gate></SignedInRoute>} />
    <Route path="/student/notifications" component={() => <SignedInRoute><Gate role="student">{() => <NotificationsPage role="student" />}</Gate></SignedInRoute>} />
    <Route path="/teacher/setup" component={() => <SignedInRoute><TeacherSetup /></SignedInRoute>} />
    <Route path="/teacher/dashboard" component={() => <SignedInRoute><Gate role="teacher">{u => <TeacherDashboard user={u} />}</Gate></SignedInRoute>} />
    <Route path="/teacher/assignments" component={() => <SignedInRoute><Gate role="teacher">{() => <TeacherAssignments />}</Gate></SignedInRoute>} />
    <Route path="/teacher/assignments/new" component={() => <SignedInRoute><Gate role="teacher">{() => <NewAssignment />}</Gate></SignedInRoute>} />
    <Route path="/teacher/assignments/:assignmentId/monitor" component={() => <SignedInRoute><Gate role="teacher">{() => <MonitorPage />}</Gate></SignedInRoute>} />
    <Route path="/teacher/submissions" component={() => <SignedInRoute><TeacherSubmissions /></SignedInRoute>} />
    <Route path="/teacher/submissions/:submissionId/review" component={() => <SignedInRoute><Gate role="teacher">{() => <ReviewPage />}</Gate></SignedInRoute>} />
    <Route path="/teacher/students" component={() => <SignedInRoute><Gate role="teacher">{() => <TeacherStudents />}</Gate></SignedInRoute>} />
    <Route path="/teacher/notifications" component={() => <SignedInRoute><Gate role="teacher">{() => <NotificationsPage role="teacher" />}</Gate></SignedInRoute>} />
    <Route path="/teacher/settings" component={() => <SignedInRoute><Gate role="teacher">{() => <TeacherSettings />}</Gate></SignedInRoute>} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}
function NativeNotificationPermissionPrompt() {
  const [permission, setPermission] = useState('checking');
  const [message, setMessage] = useState('');
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) { setPermission('unsupported'); return; }
    let cancelled = false;
    void LocalNotifications.checkPermissions().then(status => {
      if (cancelled) return;
      setPermission(status.display);
      if (status.display === 'granted') void LocalNotifications.createChannel({ id: 'barakat-general', name: 'إشعارات المعهد', description: 'تنبيهات الواجبات وتحديثات المعهد', importance: 5, visibility: 1 }).catch(() => {});
    }).catch(() => { if (!cancelled) setPermission('prompt'); });
    return () => { cancelled = true; };
  }, []);
  const requestPermission = async () => {
    setMessage('');
    try {
      const current = await LocalNotifications.checkPermissions();
      const result = current.display === 'granted' ? current : await LocalNotifications.requestPermissions();
      setPermission(result.display);
      if (result.display === 'granted') {
        await LocalNotifications.createChannel({ id: 'barakat-general', name: 'إشعارات المعهد', description: 'تنبيهات الواجبات وتحديثات المعهد', importance: 5, visibility: 1 });
        setMessage('تم تفعيل إذن إشعارات النظام. وصول التنبيهات والجهاز مغلق يحتاج أيضاً ربط Firebase بخادم المعهد.');
      } else {
        setMessage('الإذن غير مفعّل. افتح إعدادات الهاتف ثم التطبيقات ثم معهد بركات ثم الإشعارات وفعّلها.');
      }
    } catch {
      setMessage('تعذر طلب الإذن الآن. راجع إعدادات إشعارات التطبيق من إعدادات الهاتف.');
    }
  };
  if (!Capacitor.isNativePlatform() || permission === 'checking' || permission === 'unsupported' || permission === 'granted' || dismissed) return null;
  return <aside className="native-notification-permission" dir="rtl" role="region" aria-label="إذن إشعارات المعهد" data-testid="native-notification-permission">
    <span className="native-permission-icon"><Bell size={20} /></span>
    <div className="native-permission-copy"><b>فعّل إشعارات المعهد</b><p>حتى تصلك تنبيهات الواجبات والتحديثات على جهازك.</p>{message && <small role="status">{message}</small>}</div>
    <button type="button" className="native-permission-button" onClick={() => void requestPermission()} data-testid="button-native-notification-permission">السماح بالإشعارات</button>
    <button type="button" className="native-permission-later" onClick={() => setDismissed(true)} aria-label="لاحقاً">لاحقاً</button>
  </aside>;
}

const authConfigAvailable =
  import.meta.env.VITE_MOBILE_PREVIEW !== 'true' &&
  Boolean(clerkPubKey) &&
  (!Capacitor.isNativePlatform() || Boolean(import.meta.env.VITE_API_BASE_URL?.trim()));

function MissingConfigurationPage() {
  return <main className="app-shell gated" dir="rtl"><div className="glass-panel gated-card"><CircleAlert /><h1>خدمات المعهد غير مهيأة لهذه النسخة</h1><p>تسجيل الدخول والواجبات تحتاج عنوان خادم HTTPS ومفاتيح Clerk وإعدادات قاعدة البيانات والتخزين. لم يتم إنشاء بيانات تجريبية أو تأكيد أي عملية.</p><Button href="/" testId="link-preview-home">العودة إلى الصفحة العامة</Button></div></main>;
}

function App() {
  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      let listener: { remove: () => Promise<void> } | undefined;
      let cancelled = false;
      void CapacitorApp.addListener('backButton', ({ canGoBack }) => {
        if (canGoBack && window.history.length > 1) window.history.back();
        else void CapacitorApp.exitApp();
      }).then((registered) => {
        if (cancelled) void registered.remove();
        else listener = registered;
      }).catch(() => {
        // Keep the web UI usable if the native back event is unavailable.
      });
      return () => {
        cancelled = true;
        if (listener) void listener.remove();
      };
    }
    if (!('serviceWorker' in navigator)) return undefined;
    const workerUrl = `${basePath}/sw.js`;
    void navigator.serviceWorker.register(workerUrl, { scope: `${basePath}/` }).catch(() => {
      // The app remains usable without PWA or browser notification support.
    });
    return undefined;
  }, []);
  if (!authConfigAvailable) {
    return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><Switch><Route path="/" component={() => <Home authAvailable={false} />} /><Route component={MissingConfigurationPage} /></Switch></WouterRouter><NativeNotificationPermissionPrompt /><Toaster /></TooltipProvider></QueryClientProvider>;
  }
  return <QueryClientProvider client={queryClient}><ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} localization={arSA} appearance={authAppearance}><TooltipProvider><WouterRouter base={basePath}><Router /></WouterRouter><NativeNotificationPermissionPrompt /><Toaster /></TooltipProvider></ClerkProvider></QueryClientProvider>;
}

export default App;
