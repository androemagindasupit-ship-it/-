package iq.barakatchemistry.institute;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
