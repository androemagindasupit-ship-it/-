const CACHE_NAME = 'barakat-public-v1';
const SCOPE_URL = self.registration.scope;
const APP_SHELL_URL = new URL('./', SCOPE_URL).href;

function isProtectedRequest(url) {
  return url.pathname === '/api' ||
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/__clerk') ||
    url.pathname.startsWith('/clerk/') ||
    url.pathname.endsWith('.pdf');
}

function isStaticResponse(response) {
  if (!response.ok || response.type !== 'basic') return false;
  const contentType = (response.headers.get('content-type') || '').toLowerCase();
  return contentType.startsWith('text/css') ||
    contentType.includes('javascript') ||
    contentType.startsWith('image/') ||
    contentType.startsWith('font/') ||
    contentType.includes('manifest+json') ||
    contentType.includes('text/html');
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll([
        APP_SHELL_URL,
        new URL('manifest.webmanifest', SCOPE_URL).href,
        new URL('logo.svg', SCOPE_URL).href,
        new URL('favicon.svg', SCOPE_URL).href,
      ]).catch(() => undefined))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys
        .filter((key) => key.startsWith('barakat-public-') && key !== CACHE_NAME)
        .map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin || isProtectedRequest(url)) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).then(async (response) => {
        if (response.ok && response.headers.get('content-type')?.includes('text/html')) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(APP_SHELL_URL, response.clone());
        }
        return response;
      }).catch(async () => (await caches.match(APP_SHELL_URL)) || Response.error()),
    );
    return;
  }

  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      const cached = await cache.match(request);
      if (cached) return cached;

      const response = await fetch(request);
      if (isStaticResponse(response)) {
        await cache.put(request, response.clone());
      }
      return response;
    }),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = event.notification.data?.url || self.registration.scope;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      const existing = clients.find((client) => 'focus' in client);
      if (existing) {
        existing.navigate(target);
        return existing.focus();
      }
      return self.clients.openWindow(target);
    }),
  );
});
