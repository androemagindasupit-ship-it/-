import { clerkClient, getAuth } from "@clerk/express";
import { and, eq } from "drizzle-orm";
import type { NextFunction, Request, Response } from "express";
import {
  db,
  studentEnrollmentRequestsTable,
  usersTable,
} from "@workspace/db";

export async function requireAuthenticatedUser(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }

  try {
    const [existing] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.clerkUserId, userId))
      .limit(1);

    if (existing) {
      req.currentUser = existing;
      next();
      return;
    }

    const clerkUser = await clerkClient.users.getUser(userId);
    const primaryEmail = clerkUser.emailAddresses.find(
      (email) => email.id === clerkUser.primaryEmailAddressId,
    );
    const email = primaryEmail?.emailAddress.trim().toLowerCase();
    const verified =
      primaryEmail?.verification?.status === "verified" && Boolean(email);

    if (!email || !verified) {
      res.status(403).json({
        error: "تحقق من بريدك الإلكتروني في صفحة تسجيل الدخول قبل استخدام المعهد.",
      });
      return;
    }

    const displayName =
      [clerkUser.firstName, clerkUser.lastName]
        .filter((part): part is string => Boolean(part?.trim()))
        .join(" ")
        .trim() ||
      clerkUser.username?.trim() ||
      email.split("@")[0];

    const [created] = await db
      .insert(usersTable)
      .values({
        clerkUserId: userId,
        email,
        displayName,
        role: "STUDENT",
        emailVerified: true,
      })
      .onConflictDoNothing()
      .returning();

    if (created) {
      req.currentUser = created;
      next();
      return;
    }

    const [racedUser] = await db
      .select()
      .from(usersTable)
      .where(
        and(
          eq(usersTable.clerkUserId, userId),
          eq(usersTable.emailVerified, true),
        ),
      )
      .limit(1);

    if (!racedUser) {
      res.status(409).json({
        error: "تعذر ربط هذا الحساب ببريد مستخدم. تواصل مع الأستاذ.",
      });
      return;
    }

    req.currentUser = racedUser;
    next();
  } catch {
    req.log.error("Could not resolve the authenticated account");
    res.status(503).json({
      error: "تعذر التحقق من الحساب الآن. أعد المحاولة بعد قليل.",
    });
  }
}

export function requireTeacher(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (!req.currentUser) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  if (req.currentUser.role !== "TEACHER") {
    res.status(403).json({ error: "هذه الصفحة مخصصة للأستاذ." });
    return;
  }
  next();
}

export async function requireAcceptedStudent(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  if (!req.currentUser) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  if (req.currentUser.role !== "STUDENT") {
    res.status(403).json({ error: "هذه العملية مخصصة للطالب." });
    return;
  }

  const [enrollment] = await db
    .select({ status: studentEnrollmentRequestsTable.status })
    .from(studentEnrollmentRequestsTable)
    .where(eq(studentEnrollmentRequestsTable.studentId, req.currentUser.id))
    .limit(1);

  if (enrollment?.status !== "ACCEPTED") {
    res.status(403).json({
      error: "يجب قبول طلب انضمامك إلى المعهد قبل الوصول إلى الواجبات.",
    });
    return;
  }
  next();
}
