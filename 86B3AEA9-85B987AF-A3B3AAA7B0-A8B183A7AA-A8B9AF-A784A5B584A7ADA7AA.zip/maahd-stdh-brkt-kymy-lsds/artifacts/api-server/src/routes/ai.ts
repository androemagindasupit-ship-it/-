import { Router, type IRouter } from "express";
import {
  GetAiSettingsResponse,
  TestAiConnectionResponse,
} from "@workspace/api-zod";
import { requireAuthenticatedUser, requireTeacher } from "../middlewares/auth";

const router: IRouter = Router();
const lastTestByTeacher = new Map<string, number>();
const SUPPORTED_PROVIDER = "openai";

router.use(requireAuthenticatedUser, requireTeacher);

function getConfig() {
  const provider = (process.env.AI_PROVIDER ?? SUPPORTED_PROVIDER)
    .trim()
    .toLowerCase();
  const model = (process.env.AI_MODEL ?? "gpt-4o-mini").trim();
  const key = process.env.AI_API_KEY;
  return {
    provider,
    model,
    key,
    configured: Boolean(key?.trim()),
  };
}

router.get("/teacher/settings/ai", (_req, res): void => {
  const config = getConfig();
  res.json(
    GetAiSettingsResponse.parse({
      configured: config.configured,
      provider: config.provider,
      model: config.model,
      keySource: "Replit Secrets",
      message: config.configured
        ? config.provider === SUPPORTED_PROVIDER
          ? "تم إعداد المفتاح على الخادم. اختبر الاتصال قبل تفعيل ميزات الذكاء الاصطناعي."
          : "اسم المزود غير مدعوم حالياً؛ المزود المدعوم هو OpenAI."
        : "الذكاء الاصطناعي غير مهيأ. أضف AI_API_KEY إلى Replit Secrets. لا ترسل المفتاح في المحادثة.",
    }),
  );
});

router.post(
  "/teacher/settings/ai/test",
  async (req, res): Promise<void> => {
    const teacherId = req.currentUser?.id;
    const config = getConfig();
    if (!teacherId) {
      res.status(401).json({ error: "سجّل الدخول للمتابعة." });
      return;
    }
    if (!config.configured || !config.key) {
      res.status(412).json(
        TestAiConnectionResponse.parse({
          success: false,
          message:
            "الذكاء الاصطناعي غير مهيأ. أضف AI_API_KEY إلى Replit Secrets أولاً.",
          provider: config.provider,
          model: config.model,
        }),
      );
      return;
    }
    if (config.provider !== SUPPORTED_PROVIDER) {
      res.json({
        success: false,
        message: "المزود المدعوم حالياً هو OpenAI فقط.",
        provider: config.provider,
        model: config.model,
      });
      return;
    }
    const now = Date.now();
    const priorTest = lastTestByTeacher.get(teacherId) ?? 0;
    if (now - priorTest < 20_000) {
      res.status(429).json({
        error: "انتظر قليلاً قبل اختبار الاتصال مرة أخرى.",
      });
      return;
    }
    lastTestByTeacher.set(teacherId, now);

    try {
      const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${config.key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: config.model,
          input: "Reply with the single word OK.",
          max_output_tokens: 8,
          store: false,
        }),
        signal: AbortSignal.timeout(10_000),
      });

      let hasOutput = false;
      if (response.ok) {
        const result = (await response.json()) as {
          output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
        };
        hasOutput = Boolean(
          result.output?.some((item) =>
            item.content?.some(
              (content) => content.type === "output_text" && Boolean(content.text),
            ),
          ),
        );
      }
      res.json(
        TestAiConnectionResponse.parse({
          success: response.ok && hasOutput,
          message:
            response.ok && hasOutput
              ? "استجاب مزود OpenAI فعلياً للاختبار. لم يُحفظ المفتاح أو يُرسل للمتصفح."
              : response.status === 401
                ? "رفض المزود المفتاح. تحقق من AI_API_KEY في Replit Secrets."
                : response.status === 429
                  ? "وصل المزود إلى حد الاستخدام أو الرصيد. راجع حساب المزود."
                  : response.status === 404 || response.status === 400
                    ? "تعذر استخدام النموذج المحدد. تحقق من AI_MODEL وصلاحية المفتاح."
                    : "لم ينجح اختبار المزود. لم يتم تفعيل أي ميزة ذكاء اصطناعي.",
          provider: config.provider,
          model: config.model,
        }),
      );
    } catch {
      req.log.error("AI provider connection test failed");
      res.json(
        TestAiConnectionResponse.parse({
          success: false,
          message:
            "تعذر الوصول إلى المزود خلال المهلة. لم يتم تفعيل أي ميزة ذكاء اصطناعي.",
          provider: config.provider,
          model: config.model,
        }),
      );
    }
  },
);

export default router;
