import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import studentRouter from "./student";
import teacherManagementRouter from "./teacher-management";
import teacherAssignmentsRouter from "./teacher-assignments";
import notificationsRouter from "./notifications";
import aiRouter from "./ai";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(studentRouter);
router.use(teacherManagementRouter);
router.use(teacherAssignmentsRouter);
router.use(notificationsRouter);
router.use(aiRouter);
router.use(storageRouter);

export default router;
