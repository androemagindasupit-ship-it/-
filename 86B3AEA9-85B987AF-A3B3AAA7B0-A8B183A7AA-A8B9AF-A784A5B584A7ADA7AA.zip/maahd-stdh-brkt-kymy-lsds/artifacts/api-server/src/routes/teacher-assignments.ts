import { randomUUID } from "node:crypto";
import {
  and,
  desc,
  eq,
  gt,
  inArray,
  isNull,
  sql,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateTeacherAssignmentBody,
  ExtendAssignmentDeadlineBody,
  SaveTeacherReviewBody,
} from "@workspace/api-zod";
import {
  assignmentAttachmentsTable,
  assignmentTargetsTable,
  assignmentsTable,
  auditLogsTable,
  db,
  pendingUploadsTable,
  studentEnrollmentRequestsTable,
  submissionImagesTable,
  submissionsTable,
  teacherFeedbackTable,
  usersTable,
} from "@workspace/db";
import { requireAuthenticatedUser, requireTeacher } from "../middlewares/auth";
import { getAssignmentSummary, privateFileUrl } from "../lib/assignmentViews";
import {
  applyObjectAcl,
  teacherAndTargetsAcl,
  verifyPendingAttachments,
} from "../lib/uploads";
import {
  closeExpiredAssignments,
  createNotifications,
  notifyAssignmentTargets,
} from "../lib/notifications";

const router: IRouter = Router();
router.use(requireAuthenticatedUser, requireTeacher);

function isUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
    value,
  );
}

async function loadOwnedAssignment(
  assignmentId: string,
  teacherId: string,
) {
  const [assignment] = await db
    .select()
    .from(assignmentsTable)
    .where(
      and(
        eq(assignmentsTable.id, assignmentId),
        eq(assignmentsTable.createdBy, teacherId),
      ),
    )
    .limit(1);
  return assignment;
}

router.get("/teacher/assignments", async (req, res): Promise<void> => {
  const user = req.currentUser;
  if (!user) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  await closeExpiredAssignments();
  const assignments = await db
    .select()
    .from(assignmentsTable)
    .where(eq(assignmentsTable.createdBy, user.id))
    .orderBy(desc(assignmentsTable.createdAt));
  res.json(await Promise.all(assignments.map(getAssignmentSummary)));
});

router.post("/teacher/assignments", async (req, res): Promise<void> => {
  const user = req.currentUser;
  const parsed = CreateTeacherAssignmentBody.safeParse(req.body);
  if (!user || !parsed.success) {
    res.status(user ? 400 : 401).json({
      error: user ? "بيانات الواجب غير صالحة." : "سجّل الدخول للمتابعة.",
    });
    return;
  }
  const targetStudentIds = [...new Set(parsed.data.targetStudentIds)];
  if (
    targetStudentIds.length !== parsed.data.targetStudentIds.length ||
    targetStudentIds.some((id) => !isUuid(id))
  ) {
    res.status(400).json({ error: "قائمة الطلاب المختارة غير صالحة." });
    return;
  }

  if (targetStudentIds.length) {
    const accepted = await db
      .select({ id: studentEnrollmentRequestsTable.studentId })
      .from(studentEnrollmentRequestsTable)
      .where(
        and(
          inArray(studentEnrollmentRequestsTable.studentId, targetStudentIds),
          eq(studentEnrollmentRequestsTable.status, "ACCEPTED"),
        ),
      );
    if (accepted.length !== targetStudentIds.length) {
      res.status(400).json({
        error: "اختر فقط الطلاب الذين وافقت على طلب انضمامهم.",
      });
      return;
    }
  }

  let attachments;
  try {
    attachments = await verifyPendingAttachments({
      userId: user.id,
      purpose: "ASSIGNMENT",
      assignmentId: null,
      attachments: parsed.data.attachmentPaths,
    });
  } catch (error) {
    res.status(400).json({
      error:
        error instanceof Error
          ? error.message
          : "تعذر التحقق من مرفقات الواجب.",
    });
    return;
  }

  try {
    const assignment = await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(assignmentsTable)
        .values({
          title: parsed.data.title.trim(),
          chapter: parsed.data.chapter.trim(),
          instructions: parsed.data.instructions,
          durationMinutes: parsed.data.durationMinutes,
          createdBy: user.id,
          status: "DRAFT",
        })
        .returning();

      if (targetStudentIds.length) {
        await tx.insert(assignmentTargetsTable).values(
          targetStudentIds.map((studentId) => ({
            assignmentId: created.id,
            studentId,
          })),
        );
      }
      if (attachments.length) {
        await tx.insert(assignmentAttachmentsTable).values(
          attachments.map((attachment) => ({
            assignmentId: created.id,
            uploadedBy: user.id,
            objectPath: attachment.objectPath,
            filename: attachment.filename,
            contentType: attachment.contentType,
            sizeBytes: attachment.sizeBytes,
            sortOrder: attachment.sortOrder,
          })),
        );
        for (const attachment of attachments) {
          await applyObjectAcl(
            attachment.objectPath,
            teacherAndTargetsAcl(user.clerkUserId, created.id),
          );
        }
        const consumed = await tx
          .update(pendingUploadsTable)
          .set({ consumedAt: new Date() })
          .where(
            and(
              inArray(
                pendingUploadsTable.id,
                attachments.map((attachment) => attachment.intent.id),
              ),
              eq(pendingUploadsTable.userId, user.id),
              eq(pendingUploadsTable.purpose, "ASSIGNMENT"),
              isNull(pendingUploadsTable.assignmentId),
              isNull(pendingUploadsTable.consumedAt),
            ),
          )
          .returning({ id: pendingUploadsTable.id });
        if (consumed.length !== attachments.length) {
          throw new Error("UPLOAD_INTENT_USED");
        }
      }

      await tx.insert(auditLogsTable).values({
        actorId: user.id,
        action: "assignment.draft_created",
        targetType: "assignment",
        targetId: created.id,
        metadata: {
          targetCount: targetStudentIds.length,
          attachmentCount: attachments.length,
          durationMinutes: created.durationMinutes,
        },
      });
      return created;
    });

    res.status(201).json(await getAssignmentSummary(assignment));
  } catch {
    req.log.error("Could not save an assignment draft");
    res.status(503).json({
      error: "لم يتم تأكيد حفظ الواجب. تحقق من القائمة قبل إعادة المحاولة.",
    });
  }
});

router.post(
  "/teacher/assignments/:assignmentId/publish",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const assignmentId = req.params.assignmentId;
    if (!teacher || !isUuid(assignmentId)) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }

    type PublishResult =
      | { kind: "published"; assignment: typeof assignmentsTable.$inferSelect }
      | { kind: "missing" }
      | { kind: "already" }
      | { kind: "no-targets" };
    const result = await db.transaction<PublishResult>(async (tx) => {
      const [assignment] = await tx
        .select()
        .from(assignmentsTable)
        .where(
          and(
            eq(assignmentsTable.id, assignmentId),
            eq(assignmentsTable.createdBy, teacher.id),
          ),
        )
        .for("update")
        .limit(1);
      if (!assignment) {
        return { kind: "missing" };
      }
      if (assignment.status !== "DRAFT") {
        return { kind: "already" };
      }
      const [target] = await tx
        .select({ id: assignmentTargetsTable.id })
        .from(assignmentTargetsTable)
        .innerJoin(
          studentEnrollmentRequestsTable,
          eq(studentEnrollmentRequestsTable.studentId, assignmentTargetsTable.studentId),
        )
        .where(
          and(
            eq(assignmentTargetsTable.assignmentId, assignment.id),
            eq(studentEnrollmentRequestsTable.status, "ACCEPTED"),
          ),
        )
        .limit(1);
      if (!target) {
        return { kind: "no-targets" };
      }
      const now = new Date();
      const [published] = await tx
        .update(assignmentsTable)
        .set({
          status: "OPEN",
          publishedAt: now,
          deadlineAt: new Date(
            now.getTime() + assignment.durationMinutes * 60_000,
          ),
          updatedAt: now,
        })
        .where(
          and(
            eq(assignmentsTable.id, assignment.id),
            eq(assignmentsTable.status, "DRAFT"),
          ),
        )
        .returning();
      await tx.insert(auditLogsTable).values({
        actorId: teacher.id,
        action: "assignment.published",
        targetType: "assignment",
        targetId: assignment.id,
        metadata: {
          publishedAt: now.toISOString(),
          deadlineAt: published.deadlineAt?.toISOString() ?? null,
          durationMinutes: assignment.durationMinutes,
        },
      });
      return { kind: "published", assignment: published };
    });

    if (result.kind === "missing") {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    if (result.kind === "already") {
      res.status(409).json({
        error: "نُشر الواجب أو تغيرت حالته مسبقاً؛ لا يمكن بدء مؤقته مرة أخرى.",
      });
      return;
    }
    if (result.kind === "no-targets") {
      res.status(409).json({
        error: "لا يوجد طلاب مقبولون لهذا الواجب. أضف الطلاب المقبولين أولاً.",
      });
      return;
    }

    await notifyAssignmentTargets({
      assignmentId,
      type: "ASSIGNMENT_NEW",
      title: "واجب كيمياء جديد",
      body: `نشر الأستاذ واجب «${result.assignment.title}».`,
      eventKey: `published:${assignmentId}`,
    });
    res.json(await getAssignmentSummary(result.assignment));
  },
);

router.patch(
  "/teacher/assignments/:assignmentId/deadline",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const assignmentId = req.params.assignmentId;
    const parsed = ExtendAssignmentDeadlineBody.safeParse(req.body);
    if (!teacher || !isUuid(assignmentId)) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: "سبب تغيير الموعد أو التاريخ غير صالح." });
      return;
    }

    const requestedDeadline = new Date(parsed.data.deadlineAt);
    const changed = await db.transaction(async (tx) => {
      const [assignment] = await tx
        .select()
        .from(assignmentsTable)
        .where(
          and(
            eq(assignmentsTable.id, assignmentId),
            eq(assignmentsTable.createdBy, teacher.id),
          ),
        )
        .for("update")
        .limit(1);
      if (!assignment) return { kind: "missing" as const };
      if (
        assignment.status !== "OPEN" ||
        !assignment.deadlineAt ||
        assignment.deadlineAt.getTime() <= Date.now()
      ) {
        return { kind: "closed" as const };
      }
      if (requestedDeadline.getTime() <= assignment.deadlineAt.getTime()) {
        return { kind: "not-extended" as const };
      }
      const priorDeadline = assignment.deadlineAt.toISOString();
      const [updated] = await tx
        .update(assignmentsTable)
        .set({ deadlineAt: requestedDeadline, updatedAt: new Date() })
        .where(eq(assignmentsTable.id, assignment.id))
        .returning();
      await tx.insert(auditLogsTable).values({
        actorId: teacher.id,
        action: "assignment.deadline_changed",
        targetType: "assignment",
        targetId: assignment.id,
        metadata: {
          previousDeadlineAt: priorDeadline,
          deadlineAt: requestedDeadline.toISOString(),
          reason: parsed.data.reason,
        },
      });
      return { kind: "updated" as const, assignment: updated };
    });

    if (changed.kind === "missing") {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    if (changed.kind === "closed") {
      res.status(409).json({ error: "لا يمكن تغيير موعد واجب مغلق أو منتهٍ." });
      return;
    }
    if (changed.kind === "not-extended") {
      res.status(400).json({ error: "يجب أن يكون الموعد الجديد بعد الموعد الحالي." });
      return;
    }
    await notifyAssignmentTargets({
      assignmentId,
      type: "DEADLINE_CHANGED",
      title: "تغير موعد تسليم الواجب",
      body: `تم تمديد الموعد إلى ${requestedDeadline.toLocaleString("ar-IQ")}. السبب: ${parsed.data.reason}`,
      eventKey: `deadline-changed:${assignmentId}:${requestedDeadline.getTime()}`,
    });
    res.json(await getAssignmentSummary(changed.assignment));
  },
);

router.post(
  "/teacher/assignments/:assignmentId/cancel",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const assignmentId = req.params.assignmentId;
    if (!teacher || !isUuid(assignmentId)) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    const [cancelled] = await db
      .update(assignmentsTable)
      .set({ status: "CANCELLED", cancelledAt: new Date(), updatedAt: new Date() })
      .where(
        and(
          eq(assignmentsTable.id, assignmentId),
          eq(assignmentsTable.createdBy, teacher.id),
          inArray(assignmentsTable.status, ["OPEN", "CLOSED"]),
        ),
      )
      .returning();
    if (!cancelled) {
      const existing = await loadOwnedAssignment(assignmentId, teacher.id);
      res.status(existing ? 409 : 404).json({
        error: existing
          ? "لا يمكن إلغاء هذا الواجب في حالته الحالية."
          : "الواجب غير موجود.",
      });
      return;
    }
    await db.insert(auditLogsTable).values({
      actorId: teacher.id,
      action: "assignment.cancelled",
      targetType: "assignment",
      targetId: assignmentId,
      metadata: {},
    });
    await notifyAssignmentTargets({
      assignmentId,
      type: "ASSIGNMENT_CLOSED",
      title: "أُلغي الواجب",
      body: `ألغى الأستاذ واجب «${cancelled.title}».`,
      eventKey: `cancelled:${assignmentId}`,
    });
    res.json(await getAssignmentSummary(cancelled));
  },
);

router.get(
  "/teacher/assignments/:assignmentId/monitor",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const assignmentId = req.params.assignmentId;
    if (!teacher || !isUuid(assignmentId)) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    await closeExpiredAssignments();
    const assignment = await loadOwnedAssignment(assignmentId, teacher.id);
    if (!assignment) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    const students = await db
      .select({
        studentId: usersTable.id,
        displayName: usersTable.displayName,
        email: usersTable.email,
        submissionId: submissionsTable.id,
        submittedAt: submissionsTable.submittedAt,
        submissionStatus: submissionsTable.status,
      })
      .from(assignmentTargetsTable)
      .innerJoin(usersTable, eq(usersTable.id, assignmentTargetsTable.studentId))
      .leftJoin(
        submissionsTable,
        and(
          eq(submissionsTable.assignmentId, assignmentId),
          eq(submissionsTable.studentId, assignmentTargetsTable.studentId),
        ),
      )
      .where(eq(assignmentTargetsTable.assignmentId, assignmentId))
      .orderBy(usersTable.displayName);

    const now = Date.now();
    res.json({
      assignment: await getAssignmentSummary(assignment),
      students: students.map((student) => {
        const status =
          assignment.status === "CANCELLED"
            ? "CANCELLED"
            : student.submissionStatus === "REVIEWED"
              ? "REVIEWED"
              : student.submissionStatus === "SUBMITTED"
                ? "SUBMITTED"
                : assignment.status === "CLOSED" ||
                    Boolean(
                      assignment.deadlineAt &&
                        assignment.deadlineAt.getTime() <= now,
                    )
                  ? "MISSING"
                  : "WAITING";
        return {
          studentId: student.studentId,
          displayName: student.displayName,
          email: student.email,
          status,
          submissionId: student.submissionId ?? null,
          submittedAt: student.submittedAt?.toISOString() ?? null,
        };
      }),
    });
  },
);

async function getSubmissionView(submissionId: string, teacherId: string) {
  const [row] = await db
    .select({
      id: submissionsTable.id,
      assignmentId: submissionsTable.assignmentId,
      studentId: submissionsTable.studentId,
      studentName: usersTable.displayName,
      assignmentTitle: assignmentsTable.title,
      submittedAt: submissionsTable.submittedAt,
      status: submissionsTable.status,
      reviewNote: teacherFeedbackTable.note,
      reviewedAt: teacherFeedbackTable.reviewedAt,
    })
    .from(submissionsTable)
    .innerJoin(assignmentsTable, eq(assignmentsTable.id, submissionsTable.assignmentId))
    .innerJoin(usersTable, eq(usersTable.id, submissionsTable.studentId))
    .leftJoin(teacherFeedbackTable, eq(teacherFeedbackTable.submissionId, submissionsTable.id))
    .where(
      and(
        eq(submissionsTable.id, submissionId),
        eq(assignmentsTable.createdBy, teacherId),
      ),
    )
    .limit(1);
  if (!row) return null;

  const attachments = await db
    .select({
      objectPath: submissionImagesTable.objectPath,
      filename: submissionImagesTable.filename,
      contentType: submissionImagesTable.contentType,
      sizeBytes: submissionImagesTable.sizeBytes,
      sortOrder: submissionImagesTable.sortOrder,
    })
    .from(submissionImagesTable)
    .where(eq(submissionImagesTable.submissionId, submissionId))
    .orderBy(submissionImagesTable.sortOrder);
  return {
    id: row.id,
    assignmentId: row.assignmentId,
    studentId: row.studentId,
    studentName: row.studentName,
    assignmentTitle: row.assignmentTitle,
    submittedAt: row.submittedAt.toISOString(),
    status: row.status,
    reviewNote: row.reviewNote ?? null,
    reviewedAt: row.reviewedAt?.toISOString() ?? null,
    attachments: attachments.map((attachment) => ({
      ...attachment,
      viewUrl: privateFileUrl(attachment.objectPath),
    })),
  };
}

router.get(
  "/teacher/submissions/:submissionId",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const submissionId = req.params.submissionId;
    if (!teacher || !isUuid(submissionId)) {
      res.status(404).json({ error: "التسليم غير موجود." });
      return;
    }
    const submission = await getSubmissionView(submissionId, teacher.id);
    if (!submission) {
      res.status(404).json({ error: "التسليم غير موجود." });
      return;
    }
    res.json(submission);
  },
);

router.put(
  "/teacher/submissions/:submissionId/review",
  async (req, res): Promise<void> => {
    const teacher = req.currentUser;
    const submissionId = req.params.submissionId;
    const parsed = SaveTeacherReviewBody.safeParse(req.body);
    if (!teacher || !isUuid(submissionId)) {
      res.status(404).json({ error: "التسليم غير موجود." });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: "الملاحظة غير صالحة." });
      return;
    }
    const [submission] = await db
      .select({
        id: submissionsTable.id,
        assignmentId: submissionsTable.assignmentId,
        studentId: submissionsTable.studentId,
      })
      .from(submissionsTable)
      .innerJoin(assignmentsTable, eq(assignmentsTable.id, submissionsTable.assignmentId))
      .where(
        and(
          eq(submissionsTable.id, submissionId),
          eq(assignmentsTable.createdBy, teacher.id),
        ),
      )
      .limit(1);
    if (!submission) {
      res.status(404).json({ error: "التسليم غير موجود." });
      return;
    }
    const now = new Date();
    await db.transaction(async (tx) => {
      await tx
        .insert(teacherFeedbackTable)
        .values({
          submissionId,
          teacherId: teacher.id,
          note: parsed.data.note.trim(),
          reviewedAt: now,
          updatedAt: now,
        })
        .onConflictDoUpdate({
          target: teacherFeedbackTable.submissionId,
          set: {
            teacherId: teacher.id,
            note: parsed.data.note.trim(),
            reviewedAt: now,
            updatedAt: now,
          },
        });
      await tx
        .update(submissionsTable)
        .set({ status: "REVIEWED" })
        .where(eq(submissionsTable.id, submissionId));
      await tx.insert(auditLogsTable).values({
        actorId: teacher.id,
        action: "submission.review_saved",
        targetType: "submission",
        targetId: submissionId,
        metadata: { noteLength: parsed.data.note.trim().length },
      });
    });
    await createNotifications([
      {
        userId: submission.studentId,
        type: "REVIEW_AVAILABLE",
        title: "نشر الأستاذ ملاحظة على الحل",
        body: "يمكنك الآن الاطلاع على ملاحظة مراجعة واجبك.",
        assignmentId: submission.assignmentId,
        eventKey: `review:${submissionId}:${randomUUID()}`,
      },
    ]);
    const updated = await getSubmissionView(submissionId, teacher.id);
    res.json(updated);
  },
);

export default router;
