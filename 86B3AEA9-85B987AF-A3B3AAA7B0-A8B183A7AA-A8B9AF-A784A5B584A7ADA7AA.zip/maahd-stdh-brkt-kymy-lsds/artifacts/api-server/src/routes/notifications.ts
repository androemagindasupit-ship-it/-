import { and, desc, eq, isNull } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { MarkNotificationReadParams } from "@workspace/api-zod";
import { db, notificationsTable } from "@workspace/db";
import { requireAuthenticatedUser } from "../middlewares/auth";

const router: IRouter = Router();

router.get(
  "/notifications",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    if (!user) {
      res.status(401).json({ error: "سجّل الدخول للمتابعة." });
      return;
    }
    const rows = await db
      .select()
      .from(notificationsTable)
      .where(eq(notificationsTable.userId, user.id))
      .orderBy(desc(notificationsTable.createdAt))
      .limit(100);
    res.json(
      rows.map((row) => ({
        id: row.id,
        type: row.type,
        title: row.title,
        body: row.body,
        assignmentId: row.assignmentId,
        createdAt: row.createdAt.toISOString(),
        readAt: row.readAt?.toISOString() ?? null,
      })),
    );
  },
);

router.post(
  "/notifications/:notificationId/read",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const parsed = MarkNotificationReadParams.safeParse(req.params);
    if (!user || !parsed.success) {
      res.status(404).json({ error: "الإشعار غير موجود." });
      return;
    }
    const [row] = await db
      .update(notificationsTable)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(notificationsTable.id, parsed.data.notificationId),
          eq(notificationsTable.userId, user.id),
          isNull(notificationsTable.readAt),
        ),
      )
      .returning();

    const [notification] = row
      ? [row]
      : await db
          .select()
          .from(notificationsTable)
          .where(
            and(
              eq(notificationsTable.id, parsed.data.notificationId),
              eq(notificationsTable.userId, user.id),
            ),
          )
          .limit(1);
    if (!notification) {
      res.status(404).json({ error: "الإشعار غير موجود." });
      return;
    }
    res.json({
      id: notification.id,
      type: notification.type,
      title: notification.title,
      body: notification.body,
      assignmentId: notification.assignmentId,
      createdAt: notification.createdAt.toISOString(),
      readAt: notification.readAt?.toISOString() ?? null,
    });
  },
);

export default router;
