import { Readable } from "node:stream";
import { and, eq, gt } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import { RequestPrivateUploadUrlBody } from "@workspace/api-zod";
import {
  assignmentsTable,
  assignmentTargetsTable,
  db,
  pendingUploadsTable,
  studentEnrollmentRequestsTable,
} from "@workspace/db";
import { requireAuthenticatedUser } from "../middlewares/auth";
import { ObjectNotFoundError } from "../lib/objectStorage";
import {
  MAX_UPLOAD_BYTES,
  objectStorageService,
} from "../lib/uploads";
import { ObjectPermission } from "../lib/objectAcl";

const router: IRouter = Router();
const requestsByUser = new Map<string, number[]>();

function checkUploadRateLimit(userId: string): boolean {
  const now = Date.now();
  const recent = (requestsByUser.get(userId) ?? []).filter(
    (time) => now - time < 10 * 60_000,
  );
  if (recent.length >= 60) {
    requestsByUser.set(userId, recent);
    return false;
  }
  recent.push(now);
  requestsByUser.set(userId, recent);
  return true;
}

router.post(
  "/storage/uploads/request-url",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const parsed = RequestPrivateUploadUrlBody.safeParse(req.body);
    if (!user || !parsed.success) {
      res.status(user ? 400 : 401).json({
        error: user ? "بيانات طلب الرفع غير صالحة." : "سجّل الدخول للمتابعة.",
      });
      return;
    }
    if (!checkUploadRateLimit(user.id)) {
      res.status(429).json({ error: "تجاوزت عدد طلبات الرفع المسموح. حاول لاحقاً." });
      return;
    }

    const { filename, contentType, sizeBytes, purpose, assignmentId } =
      parsed.data;
    const normalizedType = contentType.toLowerCase().split(";")[0].trim();
    if (
      !filename.trim() ||
      !["image/jpeg", "image/png", "image/webp", "application/pdf"].includes(
        normalizedType,
      ) ||
      sizeBytes < 1 ||
      sizeBytes > MAX_UPLOAD_BYTES
    ) {
      res.status(400).json({
        error: "يسمح بصور JPG وPNG وWebP وملفات PDF حتى 10 ميغابايت للملف.",
      });
      return;
    }

    if (purpose === "ASSIGNMENT") {
      if (user.role !== "TEACHER" || assignmentId !== null) {
        res.status(403).json({ error: "مرفقات الواجب متاحة للأستاذ فقط." });
        return;
      }
    } else {
      if (
        user.role !== "STUDENT" ||
        typeof assignmentId !== "string"
      ) {
        res.status(403).json({ error: "رفع الحل متاح للطالب المسجل فقط." });
        return;
      }
      const now = new Date();
      const [target] = await db
        .select({ id: assignmentTargetsTable.id })
        .from(assignmentTargetsTable)
        .innerJoin(
          studentEnrollmentRequestsTable,
          eq(studentEnrollmentRequestsTable.studentId, assignmentTargetsTable.studentId),
        )
        .innerJoin(
          assignmentsTable,
          eq(assignmentsTable.id, assignmentTargetsTable.assignmentId),
        )
        .where(
          and(
            eq(assignmentTargetsTable.assignmentId, assignmentId),
            eq(assignmentTargetsTable.studentId, user.id),
            eq(studentEnrollmentRequestsTable.status, "ACCEPTED"),
            eq(assignmentsTable.status, "OPEN"),
            gt(assignmentsTable.deadlineAt, now),
          ),
        )
        .limit(1);
      if (!target) {
        res.status(403).json({
          error: "الواجب غير مفتوح لك أو انتهت مهلة التسليم.",
        });
        return;
      }
    }

    try {
      const uploadUrl = await objectStorageService.getObjectEntityUploadURL();
      const objectPath =
        objectStorageService.normalizeObjectEntityPath(uploadUrl);
      const expiresAt = new Date(Date.now() + 15 * 60_000);
      await db.insert(pendingUploadsTable).values({
        userId: user.id,
        purpose,
        assignmentId: purpose === "SUBMISSION" ? assignmentId : null,
        objectPath,
        filename: filename.trim().slice(0, 255),
        contentType: normalizedType,
        sizeBytes,
        expiresAt,
      });

      res.json({ uploadUrl, objectPath, expiresAt: expiresAt.toISOString() });
    } catch {
      req.log.error("Could not create a private upload URL");
      res.status(503).json({
        error: "تعذر تهيئة التخزين الآن. لم يتم تأكيد طلب الرفع.",
      });
    }
  },
);

async function sendObject(
  filePath: string,
  isPublic: boolean,
  req: Request,
  res: Response,
): Promise<void> {
  const file = isPublic
    ? await objectStorageService.searchPublicObject(filePath)
    : await objectStorageService.getObjectEntityFile(`/objects/${filePath}`);
  if (!file) {
    res.status(404).json({ error: "الملف غير موجود." });
    return;
  }

  if (!isPublic) {
    const user = req.currentUser;
    const allowed = user
      ? await objectStorageService.canAccessObjectEntity({
          userId: user.clerkUserId,
          objectFile: file,
          requestedPermission: ObjectPermission.READ,
        })
      : false;
    if (!allowed) {
      res.status(user ? 403 : 401).json({
        error: user ? "لا تملك صلاحية عرض هذا الملف." : "سجّل الدخول للمتابعة.",
      });
      return;
    }
  }

  const response = await objectStorageService.downloadObject(file, 60);
  res.status(response.status);
  response.headers.forEach((value, key) => res.setHeader(key, value));
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Security-Policy", "default-src 'none'; sandbox");
  if (response.body) {
    const stream = Readable.fromWeb(
      response.body as ReadableStream<Uint8Array>,
    );
    stream.on("error", () => {
      if (res.headersSent) {
        res.destroy();
      } else {
        res.status(500).end();
      }
    });
    stream.pipe(res);
  } else {
    res.end();
  }
}

router.get(
  "/storage/public-objects/*filePath",
  async (req, res): Promise<void> => {
    try {
      const raw = req.params.filePath;
      const filePath = Array.isArray(raw) ? raw.join("/") : raw;
      await sendObject(filePath, true, req, res);
    } catch {
      req.log.error("Could not serve a public object");
      res.status(500).json({ error: "تعذر عرض الملف." });
    }
  },
);

router.get(
  "/storage/objects/*path",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    try {
      const raw = req.params.path;
      const filePath = Array.isArray(raw) ? raw.join("/") : raw;
      await sendObject(filePath, false, req, res);
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(404).json({ error: "الملف غير موجود." });
        return;
      }
      req.log.error("Could not serve a private object");
      res.status(500).json({ error: "تعذر عرض الملف." });
    }
  },
);

export default router;
