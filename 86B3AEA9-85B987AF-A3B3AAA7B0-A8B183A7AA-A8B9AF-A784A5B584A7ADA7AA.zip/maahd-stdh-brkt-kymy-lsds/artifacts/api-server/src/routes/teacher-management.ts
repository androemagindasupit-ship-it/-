import { randomBytes, createHash } from "node:crypto";
import {
  and,
  count,
  eq,
  gt,
  isNotNull,
  isNull,
  lt,
  or,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateEnrollmentCodeBody,
  UpdateStudentStatusBody,
} from "@workspace/api-zod";
import {
  auditLogsTable,
  db,
  enrollmentCodesTable,
  notificationsTable,
  studentEnrollmentRequestsTable,
  submissionsTable,
  usersTable,
  assignmentsTable,
} from "@workspace/db";
import { requireAuthenticatedUser, requireTeacher } from "../middlewares/auth";

const router: IRouter = Router();
router.use(requireAuthenticatedUser, requireTeacher);

router.get("/teacher/dashboard", async (req, res): Promise<void> => {
  const user = req.currentUser;
  if (!user) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  const now = new Date();
  const [
    accepted,
    pending,
    published,
    open,
    unreviewed,
    unread,
  ] = await Promise.all([
    db
      .select({ value: count() })
      .from(studentEnrollmentRequestsTable)
      .where(eq(studentEnrollmentRequestsTable.status, "ACCEPTED")),
    db
      .select({ value: count() })
      .from(studentEnrollmentRequestsTable)
      .where(eq(studentEnrollmentRequestsTable.status, "PENDING")),
    db
      .select({ value: count() })
      .from(assignmentsTable)
      .where(
        and(
          eq(assignmentsTable.createdBy, user.id),
          isNotNull(assignmentsTable.publishedAt),
        ),
      ),
    db
      .select({ value: count() })
      .from(assignmentsTable)
      .where(
        and(
          eq(assignmentsTable.createdBy, user.id),
          eq(assignmentsTable.status, "OPEN"),
          gt(assignmentsTable.deadlineAt, now),
        ),
      ),
    db
      .select({ value: count() })
      .from(submissionsTable)
      .innerJoin(assignmentsTable, eq(assignmentsTable.id, submissionsTable.assignmentId))
      .where(
        and(
          eq(assignmentsTable.createdBy, user.id),
          eq(submissionsTable.status, "SUBMITTED"),
        ),
      ),
    db
      .select({ value: count() })
      .from(notificationsTable)
      .where(and(eq(notificationsTable.userId, user.id), isNull(notificationsTable.readAt))),
  ]);

  res.json({
    acceptedStudents: Number(accepted[0]?.value ?? 0),
    pendingRequests: Number(pending[0]?.value ?? 0),
    publishedAssignments: Number(published[0]?.value ?? 0),
    openAssignments: Number(open[0]?.value ?? 0),
    openSubmissions: Number(unreviewed[0]?.value ?? 0),
    unreadNotifications: Number(unread[0]?.value ?? 0),
  });
});

router.get("/teacher/students", async (req, res): Promise<void> => {
  const user = req.currentUser;
  if (!user) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  const rows = await db
    .select({
      id: usersTable.id,
      displayName: usersTable.displayName,
      email: usersTable.email,
      status: studentEnrollmentRequestsTable.status,
      joinedAt: studentEnrollmentRequestsTable.joinedAt,
      requestedAt: studentEnrollmentRequestsTable.requestedAt,
    })
    .from(studentEnrollmentRequestsTable)
    .innerJoin(usersTable, eq(usersTable.id, studentEnrollmentRequestsTable.studentId))
    .orderBy(studentEnrollmentRequestsTable.requestedAt);

  const activeCodes = await db
    .select()
    .from(enrollmentCodesTable)
    .where(
      and(
        eq(enrollmentCodesTable.createdBy, user.id),
        isNull(enrollmentCodesTable.revokedAt),
        or(isNull(enrollmentCodesTable.expiresAt), gt(enrollmentCodesTable.expiresAt, new Date())),
        lt(enrollmentCodesTable.usedCount, enrollmentCodesTable.maxUses),
      ),
    );

  res.json({
    students: rows
      .filter((row) => row.status !== "PENDING")
      .map(({ id, displayName, email, status, joinedAt }) => ({
        id,
        displayName,
        email,
        status,
        joinedAt: joinedAt?.toISOString() ?? null,
      })),
    requests: rows
      .filter((row) => row.status === "PENDING")
      .map(({ id, displayName, email, status, joinedAt }) => ({
        id,
        displayName,
        email,
        status,
        joinedAt: joinedAt?.toISOString() ?? null,
      })),
    activeCodes: activeCodes.map((code) => ({
      id: code.id,
      code: null,
      expiresAt: code.expiresAt?.toISOString() ?? null,
      maxUses: code.maxUses,
      usedCount: code.usedCount,
      active: code.usedCount < code.maxUses,
    })),
  });
});

router.patch(
  "/teacher/students/:studentId/status",
  async (req, res): Promise<void> => {
    const parsed = UpdateStudentStatusBody.safeParse(req.body);
    const studentId = req.params.studentId;
    if (!parsed.success || !/^[0-9a-f-]{36}$/i.test(studentId)) {
      res.status(400).json({ error: "بيانات الطالب غير صالحة." });
      return;
    }
    const [existing] = await db
      .select({ id: studentEnrollmentRequestsTable.id, status: studentEnrollmentRequestsTable.status })
      .from(studentEnrollmentRequestsTable)
      .where(eq(studentEnrollmentRequestsTable.studentId, studentId))
      .limit(1);
    if (!existing) {
      res.status(404).json({ error: "لم يتم العثور على طلب الطالب." });
      return;
    }
    const joinedAt =
      parsed.data.status === "ACCEPTED"
        ? new Date()
        : parsed.data.status === "SUSPENDED"
          ? undefined
          : null;

    const [updated] = await db
      .update(studentEnrollmentRequestsTable)
      .set({
        status: parsed.data.status,
        ...(joinedAt === undefined ? {} : { joinedAt }),
        updatedAt: new Date(),
      })
      .where(eq(studentEnrollmentRequestsTable.id, existing.id))
      .returning();

    const user = req.currentUser;
    if (user) {
      await db.insert(auditLogsTable).values({
        actorId: user.id,
        action: "student.enrollment_status_changed",
        targetType: "student",
        targetId: studentId,
        metadata: { from: existing.status, to: updated.status },
      });
    }

    const [student] = await db
      .select({
        id: usersTable.id,
        displayName: usersTable.displayName,
        email: usersTable.email,
      })
      .from(usersTable)
      .where(eq(usersTable.id, studentId))
      .limit(1);
    if (!student) {
      res.status(404).json({ error: "لم يتم العثور على الطالب." });
      return;
    }
    res.json({
      ...student,
      status: updated.status,
      joinedAt: updated.joinedAt?.toISOString() ?? null,
    });
  },
);

router.post(
  "/teacher/enrollment-codes",
  async (req, res): Promise<void> => {
    const parsed = CreateEnrollmentCodeBody.safeParse(req.body);
    const user = req.currentUser;
    if (!parsed.success || !user) {
      res.status(400).json({ error: "إعدادات رمز الدعوة غير صالحة." });
      return;
    }
    const code = `BRK-${randomBytes(5).toString("hex").toUpperCase()}`;
    const codeHash = createHash("sha256").update(code).digest("hex");
    const expiresAt = parsed.data.expiresAt
      ? new Date(parsed.data.expiresAt)
      : null;
    if (expiresAt && expiresAt.getTime() <= Date.now()) {
      res.status(400).json({ error: "يجب أن يكون تاريخ انتهاء الرمز في المستقبل." });
      return;
    }

    try {
      const [created] = await db
        .insert(enrollmentCodesTable)
        .values({
          codeHash,
          expiresAt,
          maxUses: parsed.data.maxUses,
          createdBy: user.id,
        })
        .returning();
      await db.insert(auditLogsTable).values({
        actorId: user.id,
        action: "enrollment_code.created",
        targetType: "enrollment_code",
        targetId: created.id,
        metadata: { maxUses: created.maxUses, expiresAt },
      });

      res.status(201).json({
        id: created.id,
        code,
        expiresAt: created.expiresAt?.toISOString() ?? null,
        maxUses: created.maxUses,
        usedCount: created.usedCount,
        active: true,
      });
    } catch {
      req.log.error("Could not create an enrollment code");
      res.status(503).json({ error: "تعذر إنشاء رمز الدعوة. أعد المحاولة." });
    }
  },
);

router.delete(
  "/teacher/enrollment-codes/:codeId",
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const codeId = req.params.codeId;
    if (!user || !/^[0-9a-f-]{36}$/i.test(codeId)) {
      res.status(404).json({ error: "رمز الدعوة غير موجود." });
      return;
    }
    const [revoked] = await db
      .update(enrollmentCodesTable)
      .set({ revokedAt: new Date() })
      .where(
        and(
          eq(enrollmentCodesTable.id, codeId),
          eq(enrollmentCodesTable.createdBy, user.id),
          isNull(enrollmentCodesTable.revokedAt),
        ),
      )
      .returning({ id: enrollmentCodesTable.id });
    if (!revoked) {
      res.status(404).json({ error: "رمز الدعوة غير موجود أو سبق إلغاؤه." });
      return;
    }
    await db.insert(auditLogsTable).values({
      actorId: user.id,
      action: "enrollment_code.revoked",
      targetType: "enrollment_code",
      targetId: codeId,
      metadata: {},
    });
    res.status(204).end();
  },
);

export default router;
