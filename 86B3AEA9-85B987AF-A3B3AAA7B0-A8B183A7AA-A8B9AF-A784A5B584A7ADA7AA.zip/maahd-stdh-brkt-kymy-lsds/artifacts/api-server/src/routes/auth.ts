import { createHash, timingSafeEqual } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  auditLogsTable,
  db,
  studentEnrollmentRequestsTable,
  usersTable,
} from "@workspace/db";
import {
  GetCurrentUserResponse,
  SetupFirstTeacherBody,
  SetupFirstTeacherResponse,
} from "@workspace/api-zod";
import { requireAuthenticatedUser } from "../middlewares/auth";

const router: IRouter = Router();

router.get(
  "/auth/me",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    if (!user) {
      res.status(401).json({ error: "سجّل الدخول للمتابعة." });
      return;
    }

    let enrollmentStatus:
      | "NOT_REQUIRED"
      | "NEW"
      | "PENDING"
      | "ACCEPTED"
      | "REJECTED"
      | "SUSPENDED" = "NOT_REQUIRED";

    if (user.role === "STUDENT") {
      const [enrollment] = await db
        .select({ status: studentEnrollmentRequestsTable.status })
        .from(studentEnrollmentRequestsTable)
        .where(eq(studentEnrollmentRequestsTable.studentId, user.id))
        .limit(1);
      enrollmentStatus = enrollment?.status ?? "NEW";
    }

    const [teacher] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.role, "TEACHER"))
      .limit(1);

    res.json(
      GetCurrentUserResponse.parse({
        id: user.id,
        clerkUserId: user.clerkUserId,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
        enrollmentStatus,
        teacherConfigured: Boolean(teacher),
      }),
    );
  },
);

router.post(
  "/auth/teacher/setup",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const parsed = SetupFirstTeacherBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "رمز الإعداد غير صالح." });
      return;
    }

    const setupToken = process.env.TEACHER_SETUP_TOKEN;
    const user = req.currentUser;
    if (!setupToken || setupToken.length < 24 || !user?.emailVerified) {
      res.status(403).json({
        error:
          "إعداد حساب الأستاذ غير مهيأ. أضف رمزاً عشوائياً بطول 24 حرفاً على الأقل باسم TEACHER_SETUP_TOKEN في Replit Secrets.",
      });
      return;
    }

    const expected = createHash("sha256").update(setupToken).digest();
    const supplied = createHash("sha256")
      .update(parsed.data.setupToken)
      .digest();
    if (!timingSafeEqual(expected, supplied)) {
      res.status(403).json({ error: "رمز الإعداد غير صحيح." });
      return;
    }

    try {
      const teacher = await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(748203119)`);
        const [existingTeacher] = await tx
          .select({ id: usersTable.id })
          .from(usersTable)
          .where(eq(usersTable.role, "TEACHER"))
          .limit(1);
        if (existingTeacher) {
          return null;
        }

        const [updated] = await tx
          .update(usersTable)
          .set({ role: "TEACHER" })
          .where(
            and(
              eq(usersTable.id, user.id),
              eq(usersTable.emailVerified, true),
            ),
          )
          .returning();
        if (updated) {
          await tx.insert(auditLogsTable).values({
            actorId: user.id,
            action: "teacher.initialized",
            targetType: "user",
            targetId: user.id,
            metadata: { method: "one-time-setup-token" },
          });
        }
        return updated ?? null;
      });

      if (!teacher) {
        res.status(409).json({ error: "تم إعداد حساب الأستاذ مسبقاً." });
        return;
      }

      res.status(201).json(
        SetupFirstTeacherResponse.parse({
          id: teacher.id,
          clerkUserId: teacher.clerkUserId,
          email: teacher.email,
          displayName: teacher.displayName,
          role: teacher.role,
          enrollmentStatus: "NOT_REQUIRED",
          teacherConfigured: true,
        }),
      );
    } catch {
      req.log.error("Could not initialize the first teacher account");
      res.status(503).json({
        error: "تعذر إعداد الحساب الآن. أعد المحاولة بعد قليل.",
      });
    }
  },
);

export default router;
