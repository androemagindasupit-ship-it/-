import { createHash } from "node:crypto";
import { and, desc, eq, gt, isNull, not, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  RequestStudentEnrollmentBody,
  SubmitAssignmentBody,
} from "@workspace/api-zod";
import {
  assignmentAttachmentsTable,
  assignmentTargetsTable,
  assignmentsTable,
  auditLogsTable,
  db,
  enrollmentCodesTable,
  notificationOutboxTable,
  pendingUploadsTable,
  studentEnrollmentRequestsTable,
  submissionImagesTable,
  submissionsTable,
  teacherFeedbackTable,
} from "@workspace/db";
import {
  requireAcceptedStudent,
  requireAuthenticatedUser,
} from "../middlewares/auth";
import { closeExpiredAssignments } from "../lib/notifications";
import { privateFileUrl } from "../lib/assignmentViews";
import {
  applyObjectAcl,
  teacherOnlyAcl,
  verifyPendingAttachments,
} from "../lib/uploads";

const router: IRouter = Router();

router.get(
  "/student/enrollment",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    if (!user || user.role !== "STUDENT") {
      res.status(403).json({ error: "هذه الصفحة مخصصة للطالب." });
      return;
    }
    const [enrollment] = await db
      .select({ status: studentEnrollmentRequestsTable.status })
      .from(studentEnrollmentRequestsTable)
      .where(eq(studentEnrollmentRequestsTable.studentId, user.id))
      .limit(1);

    const status = enrollment?.status ?? "NOT_SUBMITTED";
    const message = {
      NOT_SUBMITTED: "أدخل رمز الدعوة الذي زودك به الأستاذ لطلب الانضمام.",
      PENDING: "وصل طلبك إلى الأستاذ وبانتظار مراجعته.",
      ACCEPTED: "تم قبولك في المعهد. يمكنك متابعة الواجبات.",
      REJECTED: "لم يُقبل طلب الانضمام. تواصل مع الأستاذ.",
      SUSPENDED: "حسابك موقوف مؤقتاً. تواصل مع الأستاذ.",
    }[status];
    res.json({ status, message });
  },
);

router.post(
  "/student/enrollment",
  requireAuthenticatedUser,
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const parsed = RequestStudentEnrollmentBody.safeParse(req.body);
    if (!user || user.role !== "STUDENT") {
      res.status(403).json({ error: "هذه العملية مخصصة للطالب." });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: "رمز الدعوة غير صالح." });
      return;
    }

    const submittedCode = parsed.data.code.trim().toUpperCase();
    const codeHash = createHash("sha256").update(submittedCode).digest("hex");
    const result = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(studentEnrollmentRequestsTable)
        .where(eq(studentEnrollmentRequestsTable.studentId, user.id))
        .for("update")
        .limit(1);
      if (existing?.status === "SUSPENDED") {
        return {
          status: existing.status,
          requestId: existing.id,
          blocked: true,
        };
      }
      if (existing?.status === "PENDING" || existing?.status === "ACCEPTED") {
        return {
          status: existing.status,
          requestId: existing.id,
          blocked: false,
        };
      }

      const now = new Date();
      const [invitation] = await tx
        .select()
        .from(enrollmentCodesTable)
        .where(
          and(
            eq(enrollmentCodesTable.codeHash, codeHash),
            isNull(enrollmentCodesTable.revokedAt),
            sql`${enrollmentCodesTable.usedCount} < ${enrollmentCodesTable.maxUses}`,
            sql`(${enrollmentCodesTable.expiresAt} IS NULL OR ${enrollmentCodesTable.expiresAt} > ${now})`,
          ),
        )
        .for("update")
        .limit(1);
      if (!invitation) return null;

      await tx
        .update(enrollmentCodesTable)
        .set({ usedCount: sql`${enrollmentCodesTable.usedCount} + 1` })
        .where(eq(enrollmentCodesTable.id, invitation.id));

      const [request] = existing
        ? await tx
            .update(studentEnrollmentRequestsTable)
            .set({
              status: "PENDING",
              requestedAt: now,
              joinedAt: null,
              updatedAt: now,
            })
            .where(eq(studentEnrollmentRequestsTable.id, existing.id))
            .returning()
        : await tx
            .insert(studentEnrollmentRequestsTable)
            .values({ studentId: user.id, status: "PENDING" })
            .returning();

      await tx.insert(auditLogsTable).values({
        actorId: user.id,
        action: "student.enrollment_requested",
        targetType: "enrollment_request",
        targetId: request.id,
        metadata: { invitationId: invitation.id },
      });
      return { status: request.status, requestId: request.id, blocked: false };
    });

    if (!result) {
      res.status(400).json({
        error: "رمز الدعوة غير صالح أو منتهي أو سبق إيقافه.",
      });
      return;
    }
    if (result.blocked) {
      res.status(403).json({
        error: "حسابك موقوف مؤقتاً. لا يمكن تقديم طلب جديد؛ تواصل مع الأستاذ.",
      });
      return;
    }
    res.status(201).json({
      status: result.status,
      message:
        result.status === "ACCEPTED"
          ? "أنت مسجل بالفعل في المعهد."
          : "وصل طلبك إلى الأستاذ وبانتظار مراجعته.",
    });
  },
);

router.use(
  "/student/assignments",
  requireAuthenticatedUser,
  requireAcceptedStudent,
);

function getSubmissionStatus(
  assignmentStatus: string,
  deadlineAt: Date | null,
  submissionStatus: "SUBMITTED" | "REVIEWED" | null,
): "WAITING" | "SUBMITTED" | "REVIEWED" | "MISSING" | "CANCELLED" {
  if (assignmentStatus === "CANCELLED") return "CANCELLED";
  if (submissionStatus) return submissionStatus;
  if (
    assignmentStatus === "CLOSED" ||
    (deadlineAt !== null && deadlineAt.getTime() <= Date.now())
  ) {
    return "MISSING";
  }
  return "WAITING";
}

router.get("/student/assignments", async (req, res): Promise<void> => {
  const user = req.currentUser;
  if (!user) {
    res.status(401).json({ error: "سجّل الدخول للمتابعة." });
    return;
  }
  await closeExpiredAssignments();
  const rows = await db
    .select({
      id: assignmentsTable.id,
      title: assignmentsTable.title,
      chapter: assignmentsTable.chapter,
      instructions: assignmentsTable.instructions,
      status: assignmentsTable.status,
      publishedAt: assignmentsTable.publishedAt,
      deadlineAt: assignmentsTable.deadlineAt,
      submissionStatus: submissionsTable.status,
      submittedAt: submissionsTable.submittedAt,
    })
    .from(assignmentTargetsTable)
    .innerJoin(assignmentsTable, eq(assignmentsTable.id, assignmentTargetsTable.assignmentId))
    .leftJoin(
      submissionsTable,
      and(
        eq(submissionsTable.assignmentId, assignmentsTable.id),
        eq(submissionsTable.studentId, user.id),
      ),
    )
    .where(
      and(
        eq(assignmentTargetsTable.studentId, user.id),
        not(eq(assignmentsTable.status, "DRAFT")),
      ),
    )
    .orderBy(desc(assignmentsTable.publishedAt));

  res.json(
    rows.map((row) => ({
      id: row.id,
      title: row.title,
      chapter: row.chapter,
      instructions: row.instructions,
      status: row.status === "DRAFT" ? "CANCELLED" : row.status,
      publishedAt: row.publishedAt?.toISOString() ?? null,
      deadlineAt: row.deadlineAt?.toISOString() ?? null,
      submissionStatus: getSubmissionStatus(
        row.status,
        row.deadlineAt,
        row.submissionStatus,
      ),
      submittedAt: row.submittedAt?.toISOString() ?? null,
    })),
  );
});

router.get(
  "/student/assignments/:assignmentId",
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const assignmentId = req.params.assignmentId;
    if (!user || !/^[0-9a-f-]{36}$/i.test(assignmentId)) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }
    await closeExpiredAssignments();
    const [row] = await db
      .select({
        id: assignmentsTable.id,
        title: assignmentsTable.title,
        chapter: assignmentsTable.chapter,
        instructions: assignmentsTable.instructions,
        status: assignmentsTable.status,
        publishedAt: assignmentsTable.publishedAt,
        deadlineAt: assignmentsTable.deadlineAt,
        submissionId: submissionsTable.id,
        submissionStudentId: submissionsTable.studentId,
        submissionStatus: submissionsTable.status,
        submittedAt: submissionsTable.submittedAt,
        reviewNote: teacherFeedbackTable.note,
        reviewedAt: teacherFeedbackTable.reviewedAt,
      })
      .from(assignmentTargetsTable)
      .innerJoin(assignmentsTable, eq(assignmentsTable.id, assignmentTargetsTable.assignmentId))
      .leftJoin(
        submissionsTable,
        and(
          eq(submissionsTable.assignmentId, assignmentsTable.id),
          eq(submissionsTable.studentId, user.id),
        ),
      )
      .leftJoin(
        teacherFeedbackTable,
        eq(teacherFeedbackTable.submissionId, submissionsTable.id),
      )
      .where(
        and(
          eq(assignmentTargetsTable.assignmentId, assignmentId),
          eq(assignmentTargetsTable.studentId, user.id),
          not(eq(assignmentsTable.status, "DRAFT")),
        ),
      )
      .limit(1);

    if (!row) {
      res.status(404).json({ error: "الواجب غير موجود." });
      return;
    }

    const attachments = await db
      .select({
        objectPath: assignmentAttachmentsTable.objectPath,
        filename: assignmentAttachmentsTable.filename,
        contentType: assignmentAttachmentsTable.contentType,
        sizeBytes: assignmentAttachmentsTable.sizeBytes,
        sortOrder: assignmentAttachmentsTable.sortOrder,
      })
      .from(assignmentAttachmentsTable)
      .where(eq(assignmentAttachmentsTable.assignmentId, assignmentId))
      .orderBy(assignmentAttachmentsTable.sortOrder);

    const images = row.submissionId
      ? await db
          .select({
            objectPath: submissionImagesTable.objectPath,
            filename: submissionImagesTable.filename,
            contentType: submissionImagesTable.contentType,
            sizeBytes: submissionImagesTable.sizeBytes,
            sortOrder: submissionImagesTable.sortOrder,
          })
          .from(submissionImagesTable)
          .where(eq(submissionImagesTable.submissionId, row.submissionId))
          .orderBy(submissionImagesTable.sortOrder)
      : [];

    const assignmentStatus =
      row.status === "DRAFT" ? "CANCELLED" : row.status;
    res.json({
      id: row.id,
      title: row.title,
      chapter: row.chapter,
      instructions: row.instructions,
      status: assignmentStatus,
      publishedAt: row.publishedAt?.toISOString() ?? null,
      deadlineAt: row.deadlineAt?.toISOString() ?? null,
      submissionStatus: getSubmissionStatus(
        row.status,
        row.deadlineAt,
        row.submissionStatus,
      ),
      serverNow: new Date().toISOString(),
      submittedAt: row.submittedAt?.toISOString() ?? null,
      attachments: attachments.map((attachment) => ({
        ...attachment,
        viewUrl: privateFileUrl(attachment.objectPath),
      })),
      submission: row.submissionId
        ? {
            id: row.submissionId,
            assignmentId: row.id,
            studentId: user.id,
            studentName: user.displayName,
            assignmentTitle: row.title,
            submittedAt: row.submittedAt!.toISOString(),
            status: row.submissionStatus!,
            reviewNote: row.reviewNote ?? null,
            reviewedAt: row.reviewedAt?.toISOString() ?? null,
            attachments: images.map((image) => ({
              ...image,
              viewUrl: privateFileUrl(image.objectPath),
            })),
          }
        : null,
    });
  },
);

router.post(
  "/student/assignments/:assignmentId/submissions",
  async (req, res): Promise<void> => {
    const user = req.currentUser;
    const assignmentId = req.params.assignmentId;
    const parsed = SubmitAssignmentBody.safeParse(req.body);
    if (
      !user ||
      !/^[0-9a-f-]{36}$/i.test(assignmentId) ||
      !parsed.success
    ) {
      res.status(400).json({ error: "بيانات التسليم غير صالحة." });
      return;
    }

    let attachments;
    try {
      attachments = await verifyPendingAttachments({
        userId: user.id,
        purpose: "SUBMISSION",
        assignmentId,
        attachments: parsed.data.attachments,
      });
    } catch (error) {
      res.status(400).json({
        error:
          error instanceof Error
            ? error.message
            : "تعذر التحقق من الملفات المرفقة.",
      });
      return;
    }

    try {
      const submission = await db.transaction(async (tx) => {
        const [assignment] = await tx
          .select()
          .from(assignmentsTable)
          .where(eq(assignmentsTable.id, assignmentId))
          .for("update")
          .limit(1);
        const now = new Date();
        if (
          !assignment ||
          assignment.status !== "OPEN" ||
          !assignment.deadlineAt ||
          assignment.deadlineAt.getTime() <= now.getTime()
        ) {
          throw new Error("CLOSED");
        }

        const [target] = await tx
          .select({ id: assignmentTargetsTable.id })
          .from(assignmentTargetsTable)
          .innerJoin(
            studentEnrollmentRequestsTable,
            eq(studentEnrollmentRequestsTable.studentId, assignmentTargetsTable.studentId),
          )
          .where(
            and(
              eq(assignmentTargetsTable.assignmentId, assignmentId),
              eq(assignmentTargetsTable.studentId, user.id),
              eq(studentEnrollmentRequestsTable.status, "ACCEPTED"),
            ),
          )
          .limit(1);
        if (!target) throw new Error("NOT_TARGETED");

        const [alreadySubmitted] = await tx
          .select({ id: submissionsTable.id })
          .from(submissionsTable)
          .where(
            and(
              eq(submissionsTable.assignmentId, assignmentId),
              eq(submissionsTable.studentId, user.id),
            ),
          )
          .limit(1);
        if (alreadySubmitted) throw new Error("DUPLICATE");

        const idempotencyKey = createHash("sha256")
          .update(`${user.id}:${assignmentId}:${parsed.data.idempotencyKey}`)
          .digest("hex");
        const [created] = await tx
          .insert(submissionsTable)
          .values({
            assignmentId,
            studentId: user.id,
            idempotencyKey,
            submittedAt: now,
            status: "SUBMITTED",
          })
          .returning();

        await tx.insert(submissionImagesTable).values(
          attachments.map((attachment) => ({
            submissionId: created.id,
            objectPath: attachment.objectPath,
            filename: attachment.filename,
            contentType: attachment.contentType,
            sizeBytes: attachment.sizeBytes,
            sortOrder: attachment.sortOrder,
          })),
        );
        const consumed = await tx
          .update(pendingUploadsTable)
          .set({ consumedAt: now })
          .where(
            and(
              eq(pendingUploadsTable.userId, user.id),
              eq(pendingUploadsTable.purpose, "SUBMISSION"),
              eq(pendingUploadsTable.assignmentId, assignmentId),
              isNull(pendingUploadsTable.consumedAt),
              gt(pendingUploadsTable.expiresAt, now),
              sql`${pendingUploadsTable.id} IN (${sql.join(
                attachments.map((attachment) => sql`${attachment.intent.id}`),
                sql`, `,
              )})`,
            ),
          )
          .returning({ id: pendingUploadsTable.id });
        if (consumed.length !== attachments.length) {
          throw new Error("UPLOAD_INTENT_USED");
        }

        for (const attachment of attachments) {
          await applyObjectAcl(
            attachment.objectPath,
            teacherOnlyAcl(user.clerkUserId),
          );
        }
        await tx.insert(auditLogsTable).values({
          actorId: user.id,
          action: "submission.created",
          targetType: "submission",
          targetId: created.id,
          metadata: { assignmentId, attachmentCount: attachments.length },
        });

        // Persist the teacher notification in the same transaction as the submission.
        // The outbox worker delivers it asynchronously and retries safely if needed.
        await tx.insert(notificationOutboxTable).values({
          eventKey: `submission-received:${created.id}`,
          userId: assignment.createdBy,
          type: "SUBMISSION_RECEIVED",
          title: "وصل حل جديد",
          body: `وصل حل جديد من ${user.displayName} لواجب «${assignment.title}».`,
          assignmentId: assignment.id,
          status: "PENDING",
        }).onConflictDoNothing({ target: notificationOutboxTable.eventKey });

        return created;
      });

      res.status(201).json({
        id: submission.id,
        assignmentId,
        studentId: user.id,
        studentName: user.displayName,
        assignmentTitle: (
          await db
            .select({ title: assignmentsTable.title })
            .from(assignmentsTable)
            .where(eq(assignmentsTable.id, assignmentId))
            .limit(1)
        )[0]?.title ?? "",
        submittedAt: submission.submittedAt.toISOString(),
        status: submission.status,
        reviewNote: null,
        reviewedAt: null,
        attachments: attachments.map((attachment) => ({
          objectPath: attachment.objectPath,
          filename: attachment.filename,
          contentType: attachment.contentType,
          sizeBytes: attachment.sizeBytes,
          sortOrder: attachment.sortOrder,
          viewUrl: privateFileUrl(attachment.objectPath),
        })),
      });
    } catch (error) {
      if (error instanceof Error && error.message === "CLOSED") {
        res.status(409).json({
          error: "انتهى موعد التسليم. أغلق الخادم الواجب ولا يمكن استلام حل متأخر.",
        });
        return;
      }
      if (error instanceof Error && error.message === "DUPLICATE") {
        res.status(409).json({ error: "سبق أن أرسلت حلاً لهذا الواجب." });
        return;
      }
      if (error instanceof Error && error.message === "NOT_TARGETED") {
        res.status(403).json({ error: "هذا الواجب غير مخصص لحسابك." });
        return;
      }
      req.log.error("Could not finalize the assignment submission");
      res.status(503).json({
        error: "لم يتم تأكيد حفظ التسليم. تحقق من الحالة قبل إعادة المحاولة.",
      });
    }
  },
);

export default router;
