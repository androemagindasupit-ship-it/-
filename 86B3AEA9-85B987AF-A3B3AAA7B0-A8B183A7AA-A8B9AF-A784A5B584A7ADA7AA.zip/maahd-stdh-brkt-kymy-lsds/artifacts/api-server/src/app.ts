import express, { type Express } from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

const allowedOrigins = new Set<string>();
for (const candidate of [
  process.env.APP_BASE_URL,
  process.env.REPLIT_DEV_DOMAIN,
  ...(process.env.REPLIT_DOMAINS ?? "").split(","),
  "http://localhost:5173",
]) {
  const trimmed = candidate?.trim();
  if (!trimmed) continue;
  try {
    allowedOrigins.add(
      new URL(
        trimmed.startsWith("http://") || trimmed.startsWith("https://")
          ? trimmed
          : `https://${trimmed}`,
      ).origin,
    );
  } catch {
    // Ignore malformed optional origin settings.
  }
}

app.use(
  cors({
    credentials: true,
    origin(origin, callback) {
      callback(null, !origin || allowedOrigins.has(origin));
    },
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  clerkMiddleware((req) => {
    const publishableKey = process.env.CLERK_PUBLISHABLE_KEY;
    return {
      publishableKey: publishableKey
        ? publishableKeyFromHost(getClerkProxyHost(req) ?? "", publishableKey)
        : undefined,
    };
  }),
);

app.use("/api", router);

// In production, serve the built Vite app from the same origin as the API.
// This keeps Clerk sessions and relative /api requests on one deployment host.
const serverDirectory = path.dirname(fileURLToPath(import.meta.url));
const frontendDirectory = path.resolve(serverDirectory, "../../barakat-chemistry/dist/public");
app.use(express.static(frontendDirectory, { index: false, fallthrough: true }));
app.use((req, res, next) => {
  if (req.method !== "GET" && req.method !== "HEAD") {
    next();
    return;
  }
  if (req.path === "/api" || req.path.startsWith("/api/") || req.path.startsWith(CLERK_PROXY_PATH)) {
    next();
    return;
  }
  if (!(req.headers.accept ?? "").includes("text/html")) {
    next();
    return;
  }
  res.sendFile(path.join(frontendDirectory, "index.html"), (error) => {
    if (error) next(error);
  });
});

export default app;
