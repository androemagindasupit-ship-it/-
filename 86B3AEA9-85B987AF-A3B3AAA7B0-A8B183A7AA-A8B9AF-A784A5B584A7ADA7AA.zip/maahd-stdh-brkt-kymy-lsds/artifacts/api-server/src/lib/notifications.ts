import { randomUUID } from "node:crypto";
import { and, asc, eq, gt, inArray, isNull, isNotNull, lt, lte, or, sql } from "drizzle-orm";
import {
  assignmentTargetsTable,
  assignmentsTable,
  db,
  notificationsTable,
  notificationOutboxTable,
  pendingUploadsTable,
} from "@workspace/db";
import { ObjectNotFoundError } from "./objectStorage";
import { objectStorageService } from "./uploads";

export async function createNotifications(
  records: Array<{
    userId: string;
    type:
      | "ASSIGNMENT_NEW"
      | "DEADLINE_SOON"
      | "ASSIGNMENT_CLOSED"
      | "DEADLINE_CHANGED"
      | "REVIEW_AVAILABLE"
      | "SUBMISSION_RECEIVED";
    title: string;
    body: string;
    assignmentId: string | null;
    eventKey: string;
  }>,
): Promise<void> {
  if (!records.length) return;
  await db
    .insert(notificationsTable)
    .values(records)
    .onConflictDoNothing({
      target: [notificationsTable.userId, notificationsTable.eventKey],
    });
}

export async function notifyAssignmentTargets({
  assignmentId,
  type,
  title,
  body,
  eventKey,
}: {
  assignmentId: string;
  type:
    | "ASSIGNMENT_NEW"
    | "DEADLINE_SOON"
    | "ASSIGNMENT_CLOSED"
    | "DEADLINE_CHANGED";
  title: string;
  body: string;
  eventKey: string;
}): Promise<void> {
  const targets = await db
    .select({ userId: assignmentTargetsTable.studentId })
    .from(assignmentTargetsTable)
    .where(eq(assignmentTargetsTable.assignmentId, assignmentId));
  await createNotifications(
    targets.map(({ userId }) => ({
      userId,
      type,
      title,
      body,
      assignmentId,
      eventKey,
    })),
  );
}

export async function closeExpiredAssignments(): Promise<void> {
  const now = new Date();
  const closed = await db
    .update(assignmentsTable)
    .set({ status: "CLOSED" })
    .where(
      and(
        eq(assignmentsTable.status, "OPEN"),
        lte(assignmentsTable.deadlineAt, now),
      ),
    )
    .returning({
      id: assignmentsTable.id,
      title: assignmentsTable.title,
    });

  for (const assignment of closed) {
    await notifyAssignmentTargets({
      assignmentId: assignment.id,
      type: "ASSIGNMENT_CLOSED",
      title: "أُغلق الواجب",
      body: `انتهت مهلة تسليم «${assignment.title}».`,
      eventKey: `closed:${assignment.id}`,
    });
  }
}

export async function notifyUpcomingDeadlines(): Promise<void> {
  const now = new Date();
  const soon = new Date(now.getTime() + 10 * 60_000);
  const assignments = await db
    .select({
      id: assignmentsTable.id,
      title: assignmentsTable.title,
      deadlineAt: assignmentsTable.deadlineAt,
    })
    .from(assignmentsTable)
    .where(
      and(
        eq(assignmentsTable.status, "OPEN"),
        gt(assignmentsTable.deadlineAt, now),
        lte(assignmentsTable.deadlineAt, soon),
      ),
    );

  for (const assignment of assignments) {
    await notifyAssignmentTargets({
      assignmentId: assignment.id,
      type: "DEADLINE_SOON",
      title: "اقترب موعد التسليم",
      body: `بقي أقل من 10 دقائق على إغلاق «${assignment.title}».`,
      eventKey: `deadline-soon:${assignment.id}`,
    });
  }
}

export async function removeExpiredUploadIntents(): Promise<void> {
  const expired = await db
    .select({
      id: pendingUploadsTable.id,
      objectPath: pendingUploadsTable.objectPath,
    })
    .from(pendingUploadsTable)
    .where(
      and(
        lte(pendingUploadsTable.expiresAt, new Date()),
        isNull(pendingUploadsTable.consumedAt),
      ),
    )
    .limit(100);

  for (const upload of expired) {
    try {
      const file = await objectStorageService.getObjectEntityFile(upload.objectPath);
      await file.delete({ ignoreNotFound: true });
    } catch (error) {
      if (!(error instanceof ObjectNotFoundError)) {
        console.error("Could not remove an expired upload object; keeping its intent for retry");
        continue;
      }
    }
    await db
      .delete(pendingUploadsTable)
      .where(eq(pendingUploadsTable.id, upload.id));
  }
}

const OUTBOX_BATCH_SIZE = 25;
const OUTBOX_MAX_ATTEMPTS = 8;
const OUTBOX_LEASE_MS = 5 * 60_000;

/** Claims work transactionally so separate app instances do not claim the same row. */
async function claimOutboxBatch(): Promise<Array<typeof notificationOutboxTable.$inferSelect>> {
  const now = new Date();
  const expiredLease = new Date(now.getTime() - OUTBOX_LEASE_MS);
  return db.transaction(async (tx) => {
    const rows = await tx
      .select()
      .from(notificationOutboxTable)
      .where(or(
        and(inArray(notificationOutboxTable.status, ["PENDING", "RETRY"]), lte(notificationOutboxTable.nextAttemptAt, now)),
        and(eq(notificationOutboxTable.status, "PROCESSING"), isNotNull(notificationOutboxTable.lockedAt), lt(notificationOutboxTable.lockedAt, expiredLease)),
      ))
      .orderBy(asc(notificationOutboxTable.createdAt))
      .limit(OUTBOX_BATCH_SIZE)
      .for("update", { skipLocked: true });

    const claimed: Array<typeof notificationOutboxTable.$inferSelect> = [];
    for (const row of rows) {
      const lockToken = randomUUID();
      const [updated] = await tx
        .update(notificationOutboxTable)
        .set({
          status: "PROCESSING",
          lockedAt: now,
          lockToken,
          attempts: sql`${notificationOutboxTable.attempts} + 1`,
          lastError: null,
        })
        .where(eq(notificationOutboxTable.id, row.id))
        .returning();
      if (updated) claimed.push(updated);
    }
    return claimed;
  });
}

function safeFailureCode(error: unknown): string {
  if (typeof error === "object" && error !== null && "code" in error) {
    const code = (error as { code?: unknown }).code;
    if (typeof code === "string" && /^[A-Z0-9_]{1,32}$/.test(code)) return code;
  }
  return "DELIVERY_FAILED";
}

/** Delivers internal notification records. Unique event keys make retries idempotent. */
export async function processNotificationOutbox(): Promise<number> {
  const claimed = await claimOutboxBatch();
  let completed = 0;

  for (const row of claimed) {
    try {
      await createNotifications([{
        userId: row.userId,
        type: row.type,
        title: row.title,
        body: row.body,
        assignmentId: row.assignmentId,
        eventKey: row.eventKey,
      }]);
      const updated = await db
        .update(notificationOutboxTable)
        .set({ status: "COMPLETED", completedAt: new Date(), lockedAt: null, lockToken: null, lastError: null })
        .where(and(
          eq(notificationOutboxTable.id, row.id),
          eq(notificationOutboxTable.status, "PROCESSING"),
          eq(notificationOutboxTable.lockToken, row.lockToken!),
        ))
        .returning({ id: notificationOutboxTable.id });
      if (updated.length) completed++;
    } catch (error) {
      const exhausted = row.attempts >= OUTBOX_MAX_ATTEMPTS;
      const delayMs = exhausted
        ? 6 * 60 * 60_000
        : Math.min(30 * 60_000, 1_000 * 2 ** Math.max(0, row.attempts - 1));
      // Store only a sanitized code; provider/database messages can contain secrets.
      await db
        .update(notificationOutboxTable)
        .set({
          status: exhausted ? "DEAD_LETTER" : "RETRY",
          nextAttemptAt: new Date(Date.now() + delayMs),
          lockedAt: null,
          lockToken: null,
          lastError: safeFailureCode(error),
        })
        .where(and(
          eq(notificationOutboxTable.id, row.id),
          eq(notificationOutboxTable.status, "PROCESSING"),
          eq(notificationOutboxTable.lockToken, row.lockToken!),
        ));
      console.error("Notification outbox delivery failed", { outboxId: row.id, attempt: row.attempts, code: safeFailureCode(error) });
    }
  }
  return completed;
}

let maintenanceTimer: NodeJS.Timeout | undefined;
let running = false;

export function startMaintenanceJobs(): void {
  if (maintenanceTimer) return;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await processNotificationOutbox();
      await closeExpiredAssignments();
      await notifyUpcomingDeadlines();
      await removeExpiredUploadIntents();
    } catch {
      console.error("Background assignment maintenance failed");
    } finally {
      running = false;
    }
  };

  void tick();
  maintenanceTimer = setInterval(() => void tick(), 60_000);
  maintenanceTimer.unref();
}
