import { and, eq, gt, inArray, isNull } from "drizzle-orm";
import {
  db,
  pendingUploadsTable,
  type PendingUpload,
} from "@workspace/db";
import {
  ObjectAccessGroupType,
  ObjectPermission,
  type ObjectAclPolicy,
} from "./objectAcl";
import { ObjectStorageService } from "./objectStorage";

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
export const MAX_ATTACHMENTS = 20;
export const ALLOWED_CONTENT_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/pdf",
]);

export type AttachmentInput = {
  objectPath: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  sortOrder: number;
};

export type VerifiedAttachment = {
  intent: PendingUpload;
  objectPath: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  sortOrder: number;
};

const storage = new ObjectStorageService();

function sanitizeFilename(filename: string): string {
  return filename
    .replace(/[\\/\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 255);
}

async function readSignature(file: Awaited<ReturnType<ObjectStorageService["getObjectEntityFile"]>>): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const stream = file.createReadStream({ start: 0, end: 15 });
    stream.on("data", (chunk: Buffer | string) => {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    });
    stream.on("end", () => resolve(Buffer.concat(chunks).subarray(0, 16)));
    stream.on("error", reject);
  });
}

function signatureMatches(contentType: string, signature: Buffer): boolean {
  if (contentType === "image/jpeg") {
    return signature.length >= 3 && signature[0] === 0xff && signature[1] === 0xd8 && signature[2] === 0xff;
  }
  if (contentType === "image/png") {
    return signature.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  }
  if (contentType === "image/webp") {
    return (
      signature.length >= 12 &&
      signature.toString("ascii", 0, 4) === "RIFF" &&
      signature.toString("ascii", 8, 12) === "WEBP"
    );
  }
  if (contentType === "application/pdf") {
    return signature.toString("ascii", 0, 5) === "%PDF-";
  }
  return false;
}

export async function verifyPendingAttachments({
  userId,
  purpose,
  assignmentId,
  attachments,
}: {
  userId: string;
  purpose: "ASSIGNMENT" | "SUBMISSION";
  assignmentId: string | null;
  attachments: AttachmentInput[];
}): Promise<VerifiedAttachment[]> {
  if (attachments.length > MAX_ATTACHMENTS) {
    throw new Error("يمكن إرفاق 20 ملفاً كحد أقصى.");
  }
  if (new Set(attachments.map((attachment) => attachment.objectPath)).size !== attachments.length) {
    throw new Error("يوجد ملف مكرر في قائمة المرفقات.");
  }

  const verified: VerifiedAttachment[] = [];
  for (const attachment of attachments) {
    const objectPath = storage.normalizeObjectEntityPath(attachment.objectPath);
    const filename = sanitizeFilename(attachment.filename);
    const contentType = attachment.contentType.toLowerCase().split(";")[0].trim();

    if (
      !objectPath.startsWith("/objects/uploads/") ||
      !filename ||
      !ALLOWED_CONTENT_TYPES.has(contentType) ||
      attachment.sizeBytes < 1 ||
      attachment.sizeBytes > MAX_UPLOAD_BYTES
    ) {
      throw new Error("نوع الملف أو حجمه أو اسمه غير مسموح.");
    }

    const assignmentCondition =
      assignmentId === null
        ? isNull(pendingUploadsTable.assignmentId)
        : eq(pendingUploadsTable.assignmentId, assignmentId);
    const [intent] = await db
      .select()
      .from(pendingUploadsTable)
      .where(
        and(
          eq(pendingUploadsTable.objectPath, objectPath),
          eq(pendingUploadsTable.userId, userId),
          eq(pendingUploadsTable.purpose, purpose),
          assignmentCondition,
          isNull(pendingUploadsTable.consumedAt),
          gt(pendingUploadsTable.expiresAt, new Date()),
        ),
      )
      .limit(1);

    if (
      !intent ||
      intent.contentType !== contentType ||
      intent.sizeBytes !== attachment.sizeBytes
    ) {
      throw new Error("الملف غير مرتبط بطلب رفع صالح لهذا الحساب أو انتهت صلاحيته.");
    }

    const file = await storage.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    const actualSize = Number(metadata.size);
    const actualContentType = (metadata.contentType ?? "")
      .toLowerCase()
      .split(";")[0]
      .trim();
    if (
      !Number.isFinite(actualSize) ||
      actualSize !== intent.sizeBytes ||
      actualContentType !== intent.contentType ||
      actualSize > MAX_UPLOAD_BYTES
    ) {
      throw new Error("بيانات الملف المرفوع لا تطابق طلب الرفع.");
    }

    const signature = await readSignature(file);
    if (!signatureMatches(contentType, signature)) {
      throw new Error("محتوى الملف لا يطابق نوعه المعلن.");
    }

    const dispositionName = encodeURIComponent(filename).replace(/['()]/g, "");
    await file.setMetadata({
      contentType,
      contentDisposition: `inline; filename*=UTF-8''${dispositionName}`,
      metadata: {
        "cache-control": "private, no-store",
        "x-content-type-options": "nosniff",
      },
    });

    verified.push({
      intent,
      objectPath,
      filename,
      contentType,
      sizeBytes: actualSize,
      sortOrder: Math.max(0, Math.floor(attachment.sortOrder)),
    });
  }
  return verified;
}

export async function markAttachmentsConsumed(
  attachmentIds: string[],
): Promise<void> {
  if (!attachmentIds.length) return;
  await db
    .update(pendingUploadsTable)
    .set({ consumedAt: new Date() })
    .where(
      and(
        inArray(pendingUploadsTable.id, attachmentIds),
        isNull(pendingUploadsTable.consumedAt),
      ),
    );
}

export function teacherAndTargetsAcl(
  owner: string,
  assignmentId: string,
): ObjectAclPolicy {
  return {
    owner,
    visibility: "private",
    aclRules: [
      {
        group: { type: ObjectAccessGroupType.TEACHER, id: "academy-teachers" },
        permission: ObjectPermission.READ,
      },
      {
        group: {
          type: ObjectAccessGroupType.ASSIGNMENT_TARGETS,
          id: assignmentId,
        },
        permission: ObjectPermission.READ,
      },
    ],
  };
}

export function ownerOnlyAcl(owner: string): ObjectAclPolicy {
  return { owner, visibility: "private", aclRules: [] };
}

export function teacherOnlyAcl(owner: string): ObjectAclPolicy {
  return {
    owner,
    visibility: "private",
    aclRules: [
      {
        group: { type: ObjectAccessGroupType.TEACHER, id: "academy-teachers" },
        permission: ObjectPermission.READ,
      },
    ],
  };
}

export async function applyObjectAcl(
  objectPath: string,
  aclPolicy: ObjectAclPolicy,
): Promise<void> {
  await storage.trySetObjectEntityAclPolicy(objectPath, aclPolicy);
}

export { storage as objectStorageService };
