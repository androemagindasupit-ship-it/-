import { and, count, eq, sql } from "drizzle-orm";
import {
  assignmentAttachmentsTable,
  assignmentTargetsTable,
  assignmentsTable,
  db,
  submissionsTable,
  type Assignment,
} from "@workspace/db";

export function privateFileUrl(objectPath: string): string | null {
  const prefix = "/objects/";
  if (!objectPath.startsWith(prefix)) return null;
  return `/api/storage/objects/${objectPath.slice(prefix.length)}`;
}

export async function getAssignmentSummary(assignment: Assignment) {
  const [totals] = await db
    .select({
      targetCount: sql<number>`count(${assignmentTargetsTable.id})::int`,
      submittedCount: sql<number>`count(${submissionsTable.id})::int`,
    })
    .from(assignmentTargetsTable)
    .leftJoin(
      submissionsTable,
      and(
        eq(submissionsTable.assignmentId, assignment.id),
        eq(submissionsTable.studentId, assignmentTargetsTable.studentId),
      ),
    )
    .where(eq(assignmentTargetsTable.assignmentId, assignment.id));

  const attachments = await db
    .select({
      objectPath: assignmentAttachmentsTable.objectPath,
      filename: assignmentAttachmentsTable.filename,
      contentType: assignmentAttachmentsTable.contentType,
      sizeBytes: assignmentAttachmentsTable.sizeBytes,
      sortOrder: assignmentAttachmentsTable.sortOrder,
    })
    .from(assignmentAttachmentsTable)
    .where(eq(assignmentAttachmentsTable.assignmentId, assignment.id))
    .orderBy(assignmentAttachmentsTable.sortOrder);

  const targetCount = Number(totals?.targetCount ?? 0);
  const submittedCount = Number(totals?.submittedCount ?? 0);
  const stillOpen =
    assignment.status === "OPEN" &&
    assignment.deadlineAt !== null &&
    assignment.deadlineAt.getTime() > Date.now();
  const missing = assignment.status === "CANCELLED" ? 0 : targetCount - submittedCount;

  return {
    id: assignment.id,
    title: assignment.title,
    chapter: assignment.chapter,
    instructions: assignment.instructions,
    status: assignment.status,
    durationMinutes: assignment.durationMinutes,
    publishedAt: assignment.publishedAt?.toISOString() ?? null,
    deadlineAt: assignment.deadlineAt?.toISOString() ?? null,
    targetCount,
    submittedCount,
    waitingCount: stillOpen ? missing : 0,
    missingCount: stillOpen ? 0 : missing,
    attachments: attachments.map((attachment) => ({
      ...attachment,
      viewUrl: privateFileUrl(attachment.objectPath),
    })),
  };
}

export async function countAssignments(
  where: ReturnType<typeof eq> | ReturnType<typeof and>,
): Promise<number> {
  const [row] = await db
    .select({ value: count() })
    .from(assignmentsTable)
    .where(where);
  return Number(row?.value ?? 0);
}
