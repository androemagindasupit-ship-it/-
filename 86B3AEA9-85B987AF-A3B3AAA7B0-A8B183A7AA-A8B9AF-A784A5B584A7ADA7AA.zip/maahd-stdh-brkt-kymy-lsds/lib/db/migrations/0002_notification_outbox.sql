ALTER TYPE "public"."notification_type" ADD VALUE IF NOT EXISTS 'SUBMISSION_RECEIVED';--> statement-breakpoint
CREATE TABLE "notification_outbox" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "event_key" text NOT NULL,
  "user_id" uuid NOT NULL,
  "type" "notification_type" NOT NULL,
  "title" text NOT NULL,
  "body" text NOT NULL,
  "assignment_id" uuid,
  "status" text DEFAULT 'PENDING' NOT NULL,
  "attempts" integer DEFAULT 0 NOT NULL,
  "next_attempt_at" timestamp with time zone DEFAULT now() NOT NULL,
  "locked_at" timestamp with time zone,
  "lock_token" text,
  "last_error" text,
  "completed_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "notification_outbox_status_check" CHECK ("status" IN ('PENDING', 'PROCESSING', 'RETRY', 'COMPLETED', 'DEAD_LETTER')),
  CONSTRAINT "notification_outbox_attempts_check" CHECK ("attempts" >= 0)
);
--> statement-breakpoint
ALTER TABLE "notification_outbox" ADD CONSTRAINT "notification_outbox_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_outbox" ADD CONSTRAINT "notification_outbox_assignment_id_assignments_id_fk" FOREIGN KEY ("assignment_id") REFERENCES "public"."assignments"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "notification_outbox_event_key_unique" ON "notification_outbox" USING btree ("event_key");--> statement-breakpoint
CREATE INDEX "notification_outbox_status_due_idx" ON "notification_outbox" USING btree ("status", "next_attempt_at", "created_at");--> statement-breakpoint
CREATE INDEX "notification_outbox_locked_idx" ON "notification_outbox" USING btree ("status", "locked_at");
