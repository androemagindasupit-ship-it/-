CREATE TYPE "public"."upload_purpose" AS ENUM('ASSIGNMENT', 'SUBMISSION');--> statement-breakpoint
CREATE TABLE "pending_uploads" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"purpose" "upload_purpose" NOT NULL,
	"assignment_id" uuid,
	"object_path" text NOT NULL,
	"filename" text NOT NULL,
	"content_type" text NOT NULL,
	"size_bytes" integer NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"consumed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "pending_uploads" ADD CONSTRAINT "pending_uploads_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pending_uploads" ADD CONSTRAINT "pending_uploads_assignment_id_assignments_id_fk" FOREIGN KEY ("assignment_id") REFERENCES "public"."assignments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "pending_uploads_object_path_unique" ON "pending_uploads" USING btree ("object_path");--> statement-breakpoint
CREATE INDEX "pending_uploads_user_expiry_idx" ON "pending_uploads" USING btree ("user_id","expires_at","consumed_at");--> statement-breakpoint
CREATE INDEX "pending_uploads_assignment_idx" ON "pending_uploads" USING btree ("assignment_id","user_id");