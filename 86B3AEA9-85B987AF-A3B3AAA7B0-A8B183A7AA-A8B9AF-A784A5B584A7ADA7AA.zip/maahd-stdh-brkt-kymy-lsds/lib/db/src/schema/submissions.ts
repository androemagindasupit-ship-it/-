import { createInsertSchema } from "drizzle-zod";
import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { submissionStatusEnum } from "./enums";
import { assignmentsTable } from "./assignments";
import { usersTable } from "./users";

export const submissionsTable = pgTable(
  "submissions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    assignmentId: uuid("assignment_id")
      .notNull()
      .references(() => assignmentsTable.id, { onDelete: "restrict" }),
    studentId: uuid("student_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    idempotencyKey: text("idempotency_key").notNull(),
    submittedAt: timestamp("submitted_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    status: submissionStatusEnum("status").notNull().default("SUBMITTED"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("submissions_assignment_student_unique").on(
      table.assignmentId,
      table.studentId,
    ),
    uniqueIndex("submissions_idempotency_key_unique").on(table.idempotencyKey),
    index("submissions_assignment_submitted_idx").on(
      table.assignmentId,
      table.submittedAt,
    ),
    index("submissions_student_submitted_idx").on(
      table.studentId,
      table.submittedAt,
    ),
  ],
);

export const insertSubmissionSchema = createInsertSchema(submissionsTable).omit({
  id: true,
  submittedAt: true,
  createdAt: true,
  status: true,
});
export type Submission = typeof submissionsTable.$inferSelect;

export const submissionImagesTable = pgTable(
  "submission_images",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    submissionId: uuid("submission_id")
      .notNull()
      .references(() => submissionsTable.id, { onDelete: "cascade" }),
    objectPath: text("object_path").notNull(),
    filename: text("filename").notNull(),
    contentType: text("content_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("submission_images_path_unique").on(table.objectPath),
    index("submission_images_submission_order_idx").on(
      table.submissionId,
      table.sortOrder,
    ),
  ],
);

export const insertSubmissionImageSchema = createInsertSchema(
  submissionImagesTable,
).omit({ id: true, createdAt: true });
export type SubmissionImage = typeof submissionImagesTable.$inferSelect;

export const teacherFeedbackTable = pgTable(
  "teacher_feedback",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    submissionId: uuid("submission_id")
      .notNull()
      .references(() => submissionsTable.id, { onDelete: "restrict" }),
    teacherId: uuid("teacher_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    note: text("note").notNull().default(""),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("teacher_feedback_submission_unique").on(table.submissionId),
    index("teacher_feedback_teacher_reviewed_idx").on(
      table.teacherId,
      table.reviewedAt,
    ),
  ],
);

export const insertTeacherFeedbackSchema = createInsertSchema(
  teacherFeedbackTable,
).omit({ id: true, reviewedAt: true, updatedAt: true });
export type TeacherFeedback = typeof teacherFeedbackTable.$inferSelect;
