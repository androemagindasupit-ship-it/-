import { createInsertSchema } from "drizzle-zod";
import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { uploadPurposeEnum } from "./enums";
import { assignmentsTable } from "./assignments";
import { usersTable } from "./users";

export const pendingUploadsTable = pgTable(
  "pending_uploads",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    purpose: uploadPurposeEnum("purpose").notNull(),
    assignmentId: uuid("assignment_id").references(() => assignmentsTable.id, {
      onDelete: "cascade",
    }),
    objectPath: text("object_path").notNull(),
    filename: text("filename").notNull(),
    contentType: text("content_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("pending_uploads_object_path_unique").on(table.objectPath),
    index("pending_uploads_user_expiry_idx").on(
      table.userId,
      table.expiresAt,
      table.consumedAt,
    ),
    index("pending_uploads_assignment_idx").on(table.assignmentId, table.userId),
  ],
);

export const insertPendingUploadSchema = createInsertSchema(
  pendingUploadsTable,
).omit({ id: true, consumedAt: true, createdAt: true });
export type PendingUpload = typeof pendingUploadsTable.$inferSelect;
