import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import { check, index, integer, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { notificationTypeEnum } from "./enums";
import { assignmentsTable } from "./assignments";
import { usersTable } from "./users";

/** Durable, idempotent work queue for delivering internal notifications. */
export const notificationOutboxTable = pgTable(
  "notification_outbox",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventKey: text("event_key").notNull(),
    userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    type: notificationTypeEnum("type").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    assignmentId: uuid("assignment_id").references(() => assignmentsTable.id, { onDelete: "set null" }),
    status: text("status").notNull().default("PENDING"),
    attempts: integer("attempts").notNull().default(0),
    nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
    lockedAt: timestamp("locked_at", { withTimezone: true }),
    lockToken: text("lock_token"),
    lastError: text("last_error"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("notification_outbox_event_key_unique").on(table.eventKey),
    index("notification_outbox_status_due_idx").on(table.status, table.nextAttemptAt, table.createdAt),
    index("notification_outbox_locked_idx").on(table.status, table.lockedAt),
    check("notification_outbox_status_check", sql`${table.status} IN ('PENDING', 'PROCESSING', 'RETRY', 'COMPLETED', 'DEAD_LETTER')`),
    check("notification_outbox_attempts_check", sql`${table.attempts} >= 0`),
  ],
);

export const insertNotificationOutboxSchema = createInsertSchema(notificationOutboxTable).omit({
  id: true,
  attempts: true,
  nextAttemptAt: true,
  lockedAt: true,
  lockToken: true,
  lastError: true,
  completedAt: true,
  createdAt: true,
});
export type NotificationOutboxItem = typeof notificationOutboxTable.$inferSelect;
