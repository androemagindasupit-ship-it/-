import { pgEnum } from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", ["TEACHER", "STUDENT"]);
export const enrollmentStatusEnum = pgEnum("enrollment_status", [
  "PENDING",
  "ACCEPTED",
  "REJECTED",
  "SUSPENDED",
]);
export const assignmentStatusEnum = pgEnum("assignment_status", [
  "DRAFT",
  "OPEN",
  "CLOSED",
  "CANCELLED",
]);
export const submissionStatusEnum = pgEnum("submission_status", [
  "SUBMITTED",
  "REVIEWED",
]);
export const notificationTypeEnum = pgEnum("notification_type", [
  "ASSIGNMENT_NEW",
  "DEADLINE_SOON",
  "ASSIGNMENT_CLOSED",
  "DEADLINE_CHANGED",
  "REVIEW_AVAILABLE",
  "SUBMISSION_RECEIVED",
]);
export const uploadPurposeEnum = pgEnum("upload_purpose", [
  "ASSIGNMENT",
  "SUBMISSION",
]);
