import { createInsertSchema } from "drizzle-zod";
import { index, integer, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { enrollmentStatusEnum } from "./enums";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const studentEnrollmentRequestsTable = pgTable(
  "student_enrollment_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    studentId: uuid("student_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    status: enrollmentStatusEnum("status").notNull().default("PENDING"),
    requestedAt: timestamp("requested_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    joinedAt: timestamp("joined_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("student_enrollment_requests_student_unique").on(table.studentId),
    index("student_enrollment_requests_status_created_idx").on(
      table.status,
      table.requestedAt,
    ),
  ],
);

export const insertStudentEnrollmentRequestSchema = createInsertSchema(
  studentEnrollmentRequestsTable,
).omit({ id: true, requestedAt: true, updatedAt: true });
export type StudentEnrollmentRequest =
  typeof studentEnrollmentRequestsTable.$inferSelect;

export const enrollmentCodesTable = pgTable(
  "enrollment_codes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    codeHash: text("code_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    maxUses: integer("max_uses").notNull(),
    usedCount: integer("used_count").notNull().default(0),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    createdBy: uuid("created_by")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("enrollment_codes_hash_unique").on(table.codeHash),
    index("enrollment_codes_active_created_idx").on(table.revokedAt, table.createdAt),
  ],
);

export const insertEnrollmentCodeSchema = createInsertSchema(enrollmentCodesTable, {
  maxUses: z.number().int().min(1).max(500),
}).omit({ id: true, usedCount: true, revokedAt: true, createdAt: true });
export type EnrollmentCode = typeof enrollmentCodesTable.$inferSelect;
