import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import {
  check,
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { assignmentStatusEnum } from "./enums";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const assignmentsTable = pgTable(
  "assignments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    chapter: text("chapter").notNull(),
    instructions: text("instructions").notNull().default(""),
    status: assignmentStatusEnum("status").notNull().default("DRAFT"),
    durationMinutes: integer("duration_minutes").notNull().default(50),
    createdBy: uuid("created_by")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    deadlineAt: timestamp("deadline_at", { withTimezone: true }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    check(
      "assignments_duration_minutes_range",
      sql`${table.durationMinutes} >= 1 AND ${table.durationMinutes} <= 1440`,
    ),
    index("assignments_status_deadline_idx").on(table.status, table.deadlineAt),
    index("assignments_created_at_idx").on(table.createdAt),
  ],
);

export const insertAssignmentSchema = createInsertSchema(assignmentsTable, {
  title: z.string().trim().min(1).max(160),
  chapter: z.string().trim().min(1).max(160),
  instructions: z.string().max(10000),
  durationMinutes: z.number().int().min(1).max(1440),
}).omit({
  id: true,
  status: true,
  createdBy: true,
  publishedAt: true,
  deadlineAt: true,
  cancelledAt: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignmentsTable.$inferSelect;

export const assignmentTargetsTable = pgTable(
  "assignment_targets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    assignmentId: uuid("assignment_id")
      .notNull()
      .references(() => assignmentsTable.id, { onDelete: "cascade" }),
    studentId: uuid("student_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("assignment_targets_assignment_student_unique").on(
      table.assignmentId,
      table.studentId,
    ),
    index("assignment_targets_student_idx").on(table.studentId, table.assignmentId),
  ],
);

export const assignmentAttachmentsTable = pgTable(
  "assignment_attachments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    assignmentId: uuid("assignment_id")
      .notNull()
      .references(() => assignmentsTable.id, { onDelete: "cascade" }),
    uploadedBy: uuid("uploaded_by")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    objectPath: text("object_path").notNull(),
    filename: text("filename").notNull(),
    contentType: text("content_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("assignment_attachments_path_unique").on(table.objectPath),
    index("assignment_attachments_assignment_order_idx").on(
      table.assignmentId,
      table.sortOrder,
    ),
  ],
);

export const insertAssignmentAttachmentSchema = createInsertSchema(
  assignmentAttachmentsTable,
).omit({ id: true, createdAt: true });
export type AssignmentAttachment =
  typeof assignmentAttachmentsTable.$inferSelect;
