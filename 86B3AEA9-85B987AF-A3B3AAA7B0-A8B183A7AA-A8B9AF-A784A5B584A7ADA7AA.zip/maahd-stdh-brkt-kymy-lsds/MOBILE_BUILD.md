# بناء Android (APK)

يستخدم تطبيق Android واجهة React الحالية وAPI الحالي عبر Capacitor، دون استبدال المشروع أو إضافة بيانات وهمية.

## المتطلبات
- Node.js 22+ وpnpm 10 وJDK 21 وAndroid SDK API 36.
- تثبيت ناجح ومتوافق مع ملف القفل.
- خادم API عبر HTTPS مع PostgreSQL وClerk والتخزين الخاص المضبوطين.

## إعداد نسخة متصلة
اضبط VITE_API_BASE_URL على أصل الخادم، مثل https://api.example.com دون /api. اضبط VITE_CLERK_PUBLISHABLE_KEY وVITE_CLERK_PROXY_URL حسب إعداد Clerk. لا تضع CLERK_SECRET_KEY أو DATABASE_URL أو TEACHER_SETUP_TOKEN في التطبيق أو ملفات Vite.

## البناء
من مجلد artifacts/barakat-chemistry:
- pnpm run build
- pnpm exec cap add android (مرة واحدة فقط)
- pnpm exec cap sync android
- cd android && ./gradlew assembleDebug

المخرج android/app/build/outputs/apk/debug/app-debug.apk. نسخة Debug مخصصة للاختبار وليست موقعة للنشر بالمتجر. توقيع الإنتاج يحتاج مفتاحاً خاصاً خارج المستودع.

عند غياب أصل API أو مفتاح Clerk ينتج APK معاينة فقط: الصفحة العامة والملزمة تعملان محلياً، وتبقى المصادقة والواجبات معطلة برسالة واضحة. لا تدخل بيانات حسابك في تلك النسخة.
