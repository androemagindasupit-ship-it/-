# بناء Android (APK)

يستخدم تطبيق Android واجهة React الحالية وAPI الحالي عبر Capacitor، دون استبدال المشروع أو إضافة بيانات وهمية.

## المتطلبات
- Node.js 22+ وpnpm 10 وJDK 21 وAndroid SDK API 36.
- تثبيت ناجح ومتوافق مع ملف القفل.
- خادم API عبر HTTPS مع PostgreSQL وClerk والتخزين الخاص المضبوطين.

## إعداد نسخة متصلة
اضبط VITE_API_BASE_URL على أصل الخادم، مثل https://api.example.com دون /api. اضبط VITE_CLERK_PUBLISHABLE_KEY وVITE_CLERK_PROXY_URL حسب إعداد Clerk. لا تضع CLERK_SECRET_KEY أو DATABASE_URL أو TEACHER_SETUP_TOKEN في التطبيق أو ملفات Vite.

## البناء
من مجلد artifacts/barakat-chemistry:
- pnpm run build
- pnpm exec cap add android (مرة واحدة فقط)
- pnpm exec cap sync android
- cd android && ./gradlew assembleDebug

المخرج android/app/build/outputs/apk/debug/app-debug.apk. نسخة Debug مخصصة للاختبار وليست موقعة للنشر بالمتجر. توقيع الإنتاج يحتاج مفتاحاً خاصاً خارج المستودع.

عند غياب أصل API أو مفتاح Clerk ينتج APK معاينة فقط: الصفحة العامة والملزمة تعملان محلياً، وتبقى المصادقة والواجبات معطلة برسالة واضحة. لا تدخل بيانات حسابك في تلك النسخة.


## الصور وإشعارات Android

- يستخدم التطبيق منتقي صور Android الأصلي وزر الكاميرا، مع بديل لاختيار صور أو PDF؛ الحد الأقصى 20 ملفاً و10 ميغابايت لكل ملف.
- مصدر الشعار في مجلد assets ويُستخدم لأيقونة التطبيق وفي واجهة المعهد.
- يظهر طلب إذن إشعارات النظام بعد تثبيت التطبيق، ويختفي إذا كان الإذن ممنوحاً بالفعل.
- إذن الإشعارات المحلي لا يفعّل رسائل Push عند إغلاق التطبيق. يلزم إعداد Firebase Cloud Messaging وربط رموز الجهاز بخادم HTTPS لتسليم الإشعارات عن بعد.
- حفظ الصور في مساحة التخزين الخاصة يحتاج API منشوراً عبر HTTPS وإعداد Clerk وقاعدة البيانات والتخزين؛ اختيار الصورة ومعاينتها لا يعني أنها حُفظت على الخادم.
